/*
//============================================================================================
// COPYRIGHT (C)1997-2006 BSQUARE Corporation
//	ALL RIGHTS RESERVED
//
//	CONFIDENTIAL
//
//	This file is confidential and proprietary intellectual property
//	of BSQUARE Corporation.  No use, modification, duplication,
//	or distribution of any part of this file is permitted without
//	express written permission from BSQUARE Corporation.
//=============================================================================================
//=============================================================================================
    Module name : SC_SPI.lib
	File name   : SC16IS7XX_SPI.c 
	Description : The routines in this file configures the PXA270 SSP port , SC16IS7XX register
				  read and write function, FIFO read and FIFO write functions
	History	    :
		ver 0.1	  8th November 2006	
			      Initial
    Author: 
***********************************************************************************************
*/

/**********************************************************************************************
 *	Include Files
***********************************************************************************************/

#include <windows.h>
#include <types.h>
#include <memory.h>
#include <nkintr.h>
#include "ASIInclude.h"
#include "SPI_CPU_BUS.h"


/**********************************************************************************************
*	Function prototype
***********************************************************************************************/
BOOL VirtualAllocSPIMapMemory(PVOID * pvp, PVOID * pvpfree, PVOID address, DWORD size);
#define XXLP_SSSP_RFL_MASK              (0xf<<12)        //Receive FIFO Level is the number of valid entries.
#define XXLP_SSSP_TFL_MASK              (0xf<<8)         //The Transmit FIFO level the number of valid entries currently in the transmit FIFO

// ********************************************************************************************
// Function Name : VirtualAllocSPIMapMemory
// parameter : 
//		PVOID pvp		--> pvp stands for pointer to void pointer, so that we can store the 
//							results in the	caller's variables
//		PVOID pvpfree	--> pvSPIController0_MapBase address	
//		PVOID address	--> CPU_SSP1_BASE Address
//		DWORD size		--> size of SSP1 register set
//
// Return values : 	
//		This function returns the value 0 - FALSE	
//										1 - TRUE
// Description : 
//				This Function should allocate the Virtual memory and on Success it will return 
//				TRUE
// ********************************************************************************************
static BOOL VirtualAllocSPIMapMemory(PVOID * pvp, PVOID * pvpfree, PVOID address, DWORD size)
{
	SYSTEM_INFO SysInfo;
	DWORD PageSize;
	int error_flag = 0;

	/* Get the page size for the current CPU*/
	GetSystemInfo(&SysInfo);
	PageSize = SysInfo.dwPageSize;

	/* Alloc the Virtual Memory */
	if (!(*pvpfree = VirtualAlloc(NULL, size + PageSize, MEM_RESERVE, PAGE_NOACCESS)))
		goto fail;

	if (!VirtualCopy(*pvpfree, (PVOID)(((unsigned long) address) & ~(PageSize - 1)), size + PageSize, PAGE_READWRITE|PAGE_NOCACHE))
		goto fail;

	*pvp = (PVOID) (((PBYTE) *pvpfree) + (((unsigned long) address) & (PageSize - 1)));

	 return TRUE;

fail:
    /* Allocation Failed, Free the memory and return FALSE */
	 VirtualFree(*pvpfree, 0, MEM_RELEASE);
	*pvpfree = NULL;
	 return FALSE;
}
// *********************************************************************************************
// Function Name : SC_SpiBusInit
//
// parameter : 
//		BOOL InPowerHandler		/True or False
//
// Return values : 	
//		This function returns the value 0 - FALSE	
//										1 - TRUE
// Description : This function maps the processor SSP1 port on success returns TRUE
// ********************************************************************************************
DWORD SC_SpiBusInit(BOOL InPowerHandler){
	
	if (!InPowerHandler){
		DEBUGMSG(1, (TEXT("+SC_SpiBusInit\r\n")));

		/* MAP CPU SSP1 Register */
		if(!VirtualAllocSPIMapMemory(&pSPIController[0], &pvSPIController0_MapBase, (PVOID)CPU_SSP1_BASE, sizeof(CPU_SSPREGS))){
				goto cleanup;			    
		}
	}
	if (InPowerHandler){
		/* code to be written here */
	}
	/* Critical Section that we will use in register read and write */
	InitializeCriticalSection(&CSSpiTxRx);

	DEBUGMSG(1, (TEXT("-SC_SpiBusInit:success\r\n")));
	return TRUE;

cleanup:
	VirtualFree(pvSPIController0_MapBase, 0, MEM_RELEASE);
	DEBUGMSG(1, (TEXT("SC_SpiBusInit: VirtualAllocMapMemory failed \r\n")));		
	return FALSE;
}
// *******************************************************************************************
// Function Name : SC_SpiBusConfig
//
// parameter : 
//		PSPI_TRANSACTION	pSpiTransaction --> pointer to the PSPI_TRANSACTION structure
//		BOOL InPowerHandler	   TRUE
//
// Return values : 	
//
// Description :This function sets up the spi controller according to parameters in
//				pSpiTransaction and always returns TRUE.		
// *******************************************************************************************

DWORD SC_SpiBusConfig(PSPI_TRANSACTION pSpiTransaction, BOOL InPowerHandler)
{
	 int SCR = 0;

	 EnterCriticalSection(&CSSpiTxRx);

	/*Do not generate interrupts for FIFO under/over runs */
	 pSPIController[0]->sscr0 |= (CPU_SSP_SSCR0_TIM | CPU_SSP_SSCR0_RIM);

    /* Set DataSize */
	if (pSpiTransaction->DataSize >= 4 || pSpiTransaction->DataSize <= 16){
		pSPIController[0]->sscr0 &= ~(CPU_SSP_SSCR0_DSS);
		pSPIController[0]->sscr0 |= ((pSpiTransaction->DataSize)-1);
	}
	else{
		if (!InPowerHandler){
				DEBUGMSG(1, (TEXT("SPI: SC_SpiBusConfig DataSize is out of range\r\n")));
		}
		/* Set default datasize 8 bit */
		pSpiTransaction->DataSize = 8;
		pSPIController[0]->sscr0 &= ~(CPU_SSP_SSCR0_DSS);
		pSPIController[0]->sscr0 |= ((pSpiTransaction->DataSize)-1);
	}
	/* Set frame format SPI_FRAME_FORMAT_SPI (Motorola SPI)*/
	if (pSpiTransaction->FrameFormat >= 0 && pSpiTransaction->FrameFormat <= 2)
	{
		pSPIController[0]->sscr0 &= ~(CPU_SSP_SSCR0_FRF);
		pSPIController[0]->sscr0 |= (pSpiTransaction->FrameFormat) << 4;
	}
	else{
		if (!InPowerHandler){
				DEBUGMSG(1, (TEXT("SPI: SC_SpiBusConfig FrameFormat is out of range\r\n")));
		}
		/* Set default frame format SPI_FRAME_FORMAT_SPI */
		pSpiTransaction->FrameFormat	= SPI_FRAME_FORMAT_SPI;
		pSPIController[0]->sscr0 &= ~(CPU_SSP_SSCR0_FRF);
		pSPIController[0]->sscr0 |= (pSpiTransaction->FrameFormat) << 4;		
	}
	/* set SCR (serial clock rate)*/
	/* Bit rate = 13000000 / (SCR + 1)*/
    /* ClcokRate is possible upto 4 kHZ to 13 MBPS in PXA270 processor, but using SC16IS752 chip
	   Set clock rate to 590000 (550 KHZ around)*/

	if (pSpiTransaction->ClockRate >= 3174 && pSpiTransaction->ClockRate <= 13000000){
		SCR = ((13000000  / pSpiTransaction->ClockRate) - 1);
			pSPIController[0]->sscr0 &= ~(CPU_SSP_SSCR0_SCR);
			pSPIController[0]->sscr0 |= SCR << 8;
 	}
	else{
		if (!InPowerHandler){
				DEBUGMSG(1, (TEXT("SPI: CpuSpiBusConfig ClockRate is out of range Setting Defualt\r\n")));
		}
		/* set default SCR (serial clock rate) */
		pSpiTransaction->ClockRate = 590000; //Actual rate is 550 KHZ around

		SCR = 0;
		SCR = (13000000 / pSpiTransaction->ClockRate) - 1;
		pSPIController[0]->sscr0 &= ~(CPU_SSP_SSCR0_SCR);
		pSPIController[0]->sscr0 |= SCR << 8;
	}
	/* sscr1 register */
	pSPIController[0]->sscr1 = 0;			// reset register

	/* program SSCR1 values */
	/* IF Loopback mode is set Enable the Loopback mode */
	if (pSpiTransaction->Flags & SPI_LOOPBACK_MODE_ENABLE){
		pSPIController[0]->sscr1 |= CPU_SSP_SSCR1_LBM;
	}
	/* IF INVERT_CLOCK_MASK  is set Enable the INVERT_CLOCK_MASK */
	if (pSpiTransaction->Flags & SPI_FLAGS_INVERT_CLOCK_MASK){
		pSPIController[0]->sscr1 |= CPU_SSP_SSCR1_SPO;
	}
	/* IF PHASE_MASK  is set Enable the PHASE_MASK */
	if (pSpiTransaction->Flags & SPI_FLAGS_PHASE_MASK){
		pSPIController[0]->sscr1 |= CPU_SSP_SSCR1_SPH;
	}
	/* set receive FIFO threshold */
		pSPIController[0]->sscr1 &= ~0x3C00; // clear fifo levels
		pSPIController[0]->sscr1 |= ( (8 - 1) << 10);  

	/* Enable all SSP port operations */
	pSPIController[0]->sscr0 |= CPU_SSP_SSCR0_SSE;

	/* Leave the critical section */
	LeaveCriticalSection(&CSSpiTxRx);

	return TRUE;
}

// *******************************************************************************************
// Function Name : SPI_Write_Register
//
// parameter : 
//		UCHAR RegAddress : SC16IS7XX Chip register address where we want to write data
//		UCHAR data       : data we want to write at specified address
//		UCHAR Channel	 : PORT Number only channel 0 and channel 1 support
//
// Return values : TRUE/FALSE

// Description : This Function will write the data at specified address of SC16IS7XX chip.
// *******************************************************************************************

BOOL SPI_Write_Register(UCHAR RegAddress,UCHAR data,UCHAR Channel){

    BYTE AddressData;
	UINT32 count;
	UINT32 rxbyte;
	unsigned short RegAddData;
	unsigned short recv_data;

	//Enter the critical section 
    EnterCriticalSection(&CSSpiTxRx);

	// SC16IS7XX UART chip register Address where we want to write data 
	AddressData = (RegAddress << 3) |(Channel << 1);
	RegAddData =(AddressData << 8) | data;


	/*Make sure the RXFIFO is FREE  */
	count = (((pSPIController[0]->sssr & XXLP_SSSP_RFL_MASK) >> 12) & 0x0F) + 1;
	while((count <= 0x0F) &&  count--){
		rxbyte = pSPIController[0]->ssdr;			
	}
	/* Clear any ROR error condition */
	pSPIController[0]->sssr |= CPU_SSP_SSSR_ROR;

	count = (((pSPIController[0]->sssr & XXLP_SSSP_TFL_MASK) >> 8) & 0x0F);
	while(count){
		count = (((pSPIController[0]->sssr & XXLP_SSSP_TFL_MASK) >> 8) & 0x0F);
	}
	/* wait for transmit fifo to be not full */
	while (!(pSPIController[0]->sssr & CPU_SSP_SSSR_TNF));

	// Send the Address and data
	 pSPIController[0]->ssdr = (unsigned int)RegAddData;

     while ( ((pSPIController[0]->sssr & CPU_SSP_SSSR_BSY) | !(pSPIController[0]->sssr& CPU_SSP_SSSR_RNE)));
	 if(pSPIController[0]->sssr & CPU_SSP_SSSR_RNE)
	 {
				count = (((pSPIController[0]->sssr & XXLP_SSSP_RFL_MASK) >> 12) & 0x0F) + 1;
				while(count--)
				{
					recv_data =(WORD)pSPIController[0]->ssdr;
				}
	 }
 	  //Leave the critical section 
	  LeaveCriticalSection(&CSSpiTxRx);
	  return TRUE;
}
// ******************************************************************************************
// Function Name : SPI_FIFO_WRITE
//
// parameter : 
//		PBYTE lpDataSrc   :   Pointer to the DATA Buffer that we want to Transmit 
//		PBYTE lpbNrOfData :   [IN] No of Data we want to transmit
//							  [OUT]No of Data Transmitted
//		UCHAR Channel	  :	  PORT Number only channel 0 and channel 1 support
//
// Return values : TRUE/FALSE
//
// Description: The caller does not need to pass the register address.This function 
//				first sends the THR register address following the number of data.				
// ******************************************************************************************

BOOL SPI_FIFO_WRITE(PBYTE lpDataSrc,PBYTE lpbNrOfData,UCHAR Channel){

	UINT32	buffcount = 0;
	BYTE    DataUnitCount = *lpbNrOfData;
	UINT32	count = 0;
	UINT32	rxbyte;
	BYTE    AddressData;
	BYTE tx =0;
	unsigned short RegAddData;

	EnterCriticalSection(&CSSpiTxRx);

	AddressData = (Channel << 1) ;

	count = (((pSPIController[0]->sssr & XXLP_SSSP_RFL_MASK) >> 12) & 0x0F) + 1;
	while((count <= 0x0F) &&  count--){
		rxbyte = pSPIController[0]->ssdr;			
	}
	pSPIController[0]->sssr |= CPU_SSP_SSSR_ROR;

	count = (((pSPIController[0]->sssr & XXLP_SSSP_TFL_MASK) >> 8) & 0x0F);
	while(count){
		count = (((pSPIController[0]->sssr & XXLP_SSSP_TFL_MASK) >> 8) & 0x0F);
	}
	while (!(pSPIController[0]->sssr & CPU_SSP_SSSR_TNF));


	for(buffcount = 0; buffcount < DataUnitCount; buffcount++)
	{
	  while (!(pSPIController[0]->sssr & CPU_SSP_SSSR_TNF));

		RegAddData =(AddressData << 8) | lpDataSrc[tx++];
	    pSPIController[0]->ssdr = (unsigned int)RegAddData;

	    if (pSPIController[0]->sssr & CPU_SSP_SSSR_ROR){
			pSPIController[0]->sssr |= CPU_SSP_SSSR_ROR;
	    }
	    while ( ((pSPIController[0]->sssr & CPU_SSP_SSSR_BSY) | !(pSPIController[0]->sssr& CPU_SSP_SSSR_RNE)));
   	 
	    if(pSPIController[0]->sssr & CPU_SSP_SSSR_RNE)
	    {
			count = (((pSPIController[0]->sssr & XXLP_SSSP_RFL_MASK) >> 12) & 0x0F) + 1;
			while(count--){
				rxbyte = (unsigned int)pSPIController[0]->ssdr;
			}	
	    } 
		
	}	
	*lpbNrOfData = tx;
	LeaveCriticalSection(&CSSpiTxRx);
 	return TRUE; 
}

// ******************************************************************************************
// Function Name : SPI_Read_Register
//
// parameter : 
//		UCHAR RegAddress : SC16IS7XX Chip register address from where we want to read data
//		PUCHAR data      : Data we read from the specified address
//		UCHAR Channel	 : PORT Number only channel 0 and channel 1 support
//
// Return values : TRUE/FALSE
// Description: This routine reads the data from the specified register address of SC16IS7xx 
//				and it will copy the recieved data in Data pointer.
//				
// ******************************************************************************************
BOOL SPI_Read_Register(UCHAR RegAddress,PUCHAR Data,UCHAR Channel){

    BYTE AddressData[2];
	UINT32 count;
	UINT32 rxbyte;
	unsigned short RegAddData;
	unsigned short recv_data;

	EnterCriticalSection(&CSSpiTxRx);	

	// SC16IS7XX UART chip register Address where we want to write data 
	AddressData[0] = (RegAddress << 3) | 0x80;
	AddressData[0] |= (Channel << 1) ;

	AddressData[1] = 0x04;
	RegAddData =(AddressData[0] << 8) | AddressData[1];

retry:

	/*Make sure the RXFIFO is FREE  */
	count = (((pSPIController[0]->sssr & XXLP_SSSP_RFL_MASK) >> 12) & 0x0F) + 1;
	while((count <= 0x0F) &&  count--){
		rxbyte = pSPIController[0]->ssdr;			
	}
	// Clear any ROR error condition 
	pSPIController[0]->sssr |= CPU_SSP_SSSR_ROR;

	count = (((pSPIController[0]->sssr & XXLP_SSSP_TFL_MASK) >> 8) & 0x0F);
	while(count){
		count = (((pSPIController[0]->sssr & XXLP_SSSP_TFL_MASK) >> 8) & 0x0F);
	}
	/* wait for transmit fifo to be not full */
	while (!(pSPIController[0]->sssr & CPU_SSP_SSSR_TNF));

	// Send the Address and data
	 pSPIController[0]->ssdr = (unsigned int)RegAddData;

	 while ( ((pSPIController[0]->sssr & CPU_SSP_SSSR_BSY) | !(pSPIController[0]->sssr& CPU_SSP_SSSR_RNE)));

	 if(pSPIController[0]->sssr & CPU_SSP_SSSR_RNE){
			count = (((pSPIController[0]->sssr & XXLP_SSSP_RFL_MASK) >> 12) & 0x0F) + 1;
			while(count--){
				recv_data = (unsigned int)pSPIController[0]->ssdr;
				*Data = (BYTE)recv_data;
			}
	  }

	  //If Bad IIR read .. Try again
	  if(*Data == 0XFF && (AddressData[0] == 0x90 || AddressData[0] == 0x92)){
		  goto retry;
	  }	
  	  //Leave the critical section 
	  LeaveCriticalSection(&CSSpiTxRx);

	 return TRUE;
}
// *****************************************************************************************
// Function Name : SPI_FIFO_READ
//
// parameter : 
//		PBYTE lpDataSrc   : Pointer to DATA Buffer where we want to recieve the DATA.
//		PBYTE lpbNrOfData : [IN]  No of data we want to receieve
//						    [OUT] No of data we receieved 	
//      UCHAR Channel	  : PORT Number only channel 0 and channel 1 support
//
// Return values : TRUE/FALSE
// Description: The caller does not need to pass the register Address of RHR, this   
//				functions internally first sends the RHR address to read the FIFO 	
//				DATA.	
// ******************************************************************************************

BOOL SPI_FIFO_READ(PBYTE lpDataSrc,PBYTE lpbNrOfData,UCHAR Channel){
	
	UINT32	buffcount = 0;
	BYTE    DataUnitCount = *lpbNrOfData;
	UINT32	count = 0;
	UINT32	rxbyte;
	BYTE    AddressData[2];
	BYTE recv_i =0;
	unsigned short RegAddData;
	unsigned short recv_data;

	EnterCriticalSection(&CSSpiTxRx);	

	AddressData[0] = 0x80 |(Channel << 1) ;
	AddressData[1] = 0x04; 

	RegAddData =(AddressData[0] << 8) | AddressData[1];

	count = (((pSPIController[0]->sssr & XXLP_SSSP_RFL_MASK) >> 12) & 0x0F) + 1;
	while((count <= 0x0F) &&  count--){
		rxbyte = pSPIController[0]->ssdr;			
	}
	pSPIController[0]->sssr |= CPU_SSP_SSSR_ROR;

	count = (((pSPIController[0]->sssr & XXLP_SSSP_TFL_MASK) >> 8) & 0x0F);
	while(count){
		count = (((pSPIController[0]->sssr & XXLP_SSSP_TFL_MASK) >> 8) & 0x0F);
	}
	while (!(pSPIController[0]->sssr & CPU_SSP_SSSR_TNF));


	for(buffcount = 0; buffcount < DataUnitCount; buffcount++)
	{
	  while (!(pSPIController[0]->sssr & CPU_SSP_SSSR_TNF));

	  // Send the Address and data
	  pSPIController[0]->ssdr = (unsigned int)RegAddData;
	  if (pSPIController[0]->sssr & CPU_SSP_SSSR_ROR){
			pSPIController[0]->sssr |= CPU_SSP_SSSR_ROR;
	  }
	  while ( ((pSPIController[0]->sssr & CPU_SSP_SSSR_BSY) | !(pSPIController[0]->sssr& CPU_SSP_SSSR_RNE)));
   	 
	  if(pSPIController[0]->sssr & CPU_SSP_SSSR_RNE)
	  {
			count = (((pSPIController[0]->sssr & XXLP_SSSP_RFL_MASK) >> 12) & 0x0F) + 1;
			while(count--){
				recv_data = (unsigned int)pSPIController[0]->ssdr;
				lpDataSrc[buffcount] = (BYTE)recv_data;		
			}	
	  } 
	}
	
	*lpbNrOfData = DataUnitCount;

	LeaveCriticalSection(&CSSpiTxRx);
 	return TRUE; 
}

// ******************************************************************************************
// Function Name : SPI_deinit
//
// parameter : 
//					None
// Return values :  
//					None
// Description: This routine should be called from the SC_Deinit() function to delete the  
//				critical section.
// ******************************************************************************************
void SPI_deinit(void){	

	/* Delete the critical section we have allocated */
	  DeleteCriticalSection(&CSSpiTxRx);

	  if(pvSPIController0_MapBase != NULL){
	/* Free the Resources we have allocated */
		VirtualFree(pvSPIController0_MapBase, 0, MEM_RELEASE);
	  }	
}

