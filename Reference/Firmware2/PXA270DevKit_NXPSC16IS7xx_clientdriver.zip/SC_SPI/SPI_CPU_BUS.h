/*
//==============================================================================
// COPYRIGHT (C)1997-2006 BSQUARE Corporation
//	ALL RIGHTS RESERVED
//
//	CONFIDENTIAL
//
//	This file is confidential and proprietary intellectual property
//	of BSQUARE Corporation.  No use, modification, duplication,
//	or distribution of any part of this file is permitted without
//	express written permission from BSQUARE Corporation.
//===============================================================================
//===============================================================================
	Module name : SC_SPI.lib
	File name   : SPI_CPU_BUS.h 
	Description : This header file has the globle variable defination for SC_SPI.lib
				  module
	History	    :
		ver 0.1	  8th November 2006	
			      Initial
    Author:
	
*********************************************************************************
*/

#ifndef _SPI_CPU_BUS_H_
#define _SPI_CPU_BUS_H_

#ifdef __cplusplus
extern "C" {
#endif

/*Critical Section for spi data transaction*/
CRITICAL_SECTION CSSpiTxRx;

static PVOID pvSPIController0_MapBase;

/*Indexed by SPI driver bus number, currently SSP1 support only*/

static PCPU_SSPREGS pSPIController[] = {
	(PCPU_SSPREGS)CPU_SSP1_BASE,	
	#if SPI_BUS_CONTROLLER_CPU_BUS_1_ENABLE
		(PCPU_SSPREGS)CPU_SSP2_BASE,
	#endif
	#if SPI_BUS_CONTROLLER_CPU_BUS_2_ENABLE
		(PCPU_SSPREGS)CPU_SSP3_BASE,
	#endif
	0
};

/*SSP1 Support only */
#define SPI_BUS_CONTROLLER_CPU_BUS_0		0x01 

/********************************************************************************
 Structure used for configuring the SPI bus
*********************************************************************************/
typedef struct {
	unsigned int Bus;				// SPI Bus number - SSP1 support only
	unsigned int Device;			// Device Number  - One slave device only
	unsigned int DataSize;			// bits of data for each data unit (typically 8-16)
	unsigned int FrameFormat;		// Frame format -- SPI_FRAME_FORMAT_SPI only
	unsigned int ClockRate;			// desired clock rate in HZ -- actual clock rate <= requested
	unsigned int Flags;				// misc flags -- see definition below
	unsigned int TimeOutMs;			// timeout used for any operations that require a timeout
	unsigned int DataUnitCount;		// number of data units to send in this transaction
} SPI_TRANSACTION, * PSPI_TRANSACTION;


/********************************************************************************
 CPU specific defines
 FRAME format defines -
	 The following macros are used with the FrameFormat field in the
	 SPI_TRANSACTION data structure

*********************************************************************************/
#define SPI_FRAME_FORMAT_SPI		0

/********************************************************************************
 CPU independent transaction flags
*********************************************************************************/

// Note: when defining new flags make sure that they do not overlap
// the CPU dependent transaction flags

// When the SPI_FLAGS_8BIT_BUFFERS flag is set the transaction data buffers pointed to
// by pSendData and pRecvData to be treated as pointers to unsigned 8 bit data.
//
// Note: If this flag is set the transaction DataSize must be 8 or the transaction will fail.
// Note: When filling out the SPI_IOCTL_TRANSACTION and using pointers to 8 bit data 
//       you will need to cast the pointers as (unsigned short *) but the driver will 
//       cast them to (unsigned char *) before use.
#define SPI_FLAGS_8BIT_BUFFERS			(1 << 31)

/********************************************************************************
 CPU dependent transaction flags
*********************************************************************************/

#define SPI_FLAGS_INVERT_CLOCK_MASK		(1 << 0)	// set to 1 for active low clock
#define SPI_FLAGS_PHASE_MASK			(1 << 1)	// 0 -> SPI clock is inactive one
                                        	        //      cycle at start of frame and
													//      1/2 at end
													// 1 -> SPI clock is inactive 1/2 cycle
													//      at start of frame and one cycle
													//      at end
#define SPI_LOOPBACK_MODE_ENABLE    	(1 << 3)	// set to enable loopback mode -- for testing
#define SPI_POLLED_MODE_ONLY	    	(1 << 4)	// set to prevent driver from performing an 
													// interrupt driven transaction.  This flag 
													// has no effect if the driver is not 
													// configured to support SPI interrupts.

	
#ifdef __cplusplus
}
#endif 

#endif _SPI_CPU_BUS_H_


