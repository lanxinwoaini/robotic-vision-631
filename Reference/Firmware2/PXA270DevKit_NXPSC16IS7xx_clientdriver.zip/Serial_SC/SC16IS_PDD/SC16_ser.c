/*
//============================================================================================
// COPYRIGHT (C)1997-2006 BSQUARE Corporation
//	ALL RIGHTS RESERVED
//
//	CONFIDENTIAL
//
//	This file is confidential and proprietary intellectual property
//	of BSQUARE Corporation.  No use, modification, duplication,
//	or distribution of any part of this file is permitted without
//	express written permission from BSQUARE Corporation.
//=============================================================================================
//=============================================================================================
    Module name : SC16IS7XX.dll
	File name   : SC16_ser.c 
	Description : The Serial driver PDD layer functionality. All the functions in this file is 
				  called by MDD.	
	History	    :
		ver 0.1	  8th November 2006	
			      Initial
    Author: 
***********************************************************************************************
*/

/**********************************************************************************************
 *	Include Files
***********************************************************************************************/

#include <windows.h>
#include <types.h>
#include <ceddk.h>
#include <memory.h>
#include <serhw.h>
#include <serdbg.h>
#include "SC16IS7xx_16550.h"
#include "SC16IS7xx_UART.h"


#ifndef _PREFAST_
#pragma warning(disable: 4068) // Disable pragma warnings
#endif

#define EXCEPTION_ACCESS_VIOLATION STATUS_ACCESS_VIOLATION 

// Receive data ready , receive line status and modem status interrupt 
#define IER_NORMAL_INTS (SERIAL_IER_RDA | SERIAL_IER_RLS | SERIAL_IER_MS )

// Macro definitions for SPI interface function
#define INBSPI(Reg,pData) SPI_Read_Register((UCHAR)Reg,(PUCHAR)pData,(UCHAR)pHWHead->dwPortIndex)
#define OUTBSPI(Reg,Data) SPI_Write_Register((UCHAR)Reg,(UCHAR)Data,(UCHAR)pHWHead->dwPortIndex)

// Macro definitions for I2C interface functions
#define INB(Reg,pData) I2C_Read_Register((UCHAR)pHWHead->dwSlaveAddress,(UCHAR)Reg,(UCHAR)pHWHead->dwPortIndex,(PUCHAR)pData)
#define OUTB(Reg,Data) I2C_Write_Register((UCHAR)pHWHead->dwSlaveAddress,(UCHAR)Reg,(UCHAR)pHWHead->dwPortIndex,(UCHAR)Data)

// Static variable used to init SYSINTR only one time 
static DWORD IsrInitTrue = TRUE;
static DWORD I2cSpiInitTrue = TRUE;

// Globle ISR returened flags, for setting ISR read IIR value interrupt type. 

BYTE ReadFlag0 = TRUE;
BYTE ReadFlag1 = TRUE;

//Global variable 
DWORD  Interface;
DWORD  Sysintr;
DWORD  I2CSlaveAdd;
BOOL  PORTAFLAG;
BOOL  PORTBFLAG;
PUCHAR IIR0;
PUCHAR IIR1;


const
HW_VTBL SC16ISIoVTbl= {
	SC_Init,
    SC_PostInit,        
    SC_Deinit,
    SC_Open,
    SC_Close,
    SC_GetInterruptType,
    SC_RxIntr,
    SC_TxIntrEx,
    SC_ModemIntr,
    SC_LineIntr,
    SC_GetRxBufferSize,
    SC_PowerOff,
    SC_PowerOn,
    SC_ClearDTR,
    SC_SetDTR,
    SC_ClearRTS,
    SC_SetRTS,
    SC_EnableIR,
    SC_DisableIR,
    SC_ClearBreak,
    SC_SetBreak,
    SC_XmitComChar,
    SC_GetStatus,
    SC_Reset,
    SC_GetModemStatus,
    SC_GetCommProperties,
    SC_PurgeComm,
    SC_SetDCB,
    SC_SetCommTimeouts,
    SC_Ioctl
	};

HWOBJ   SerObj      = {
    THREAD_AT_INIT,
    0,
    (PHW_VTBL) &SC16ISIoVTbl
};

// Processing of LSR, After reading line status register,
// it process for errors occurred during reception
// And calls back MDD if line event occurs. 
//
__inline 
VOID ProcessLSR (PSER_SC16IS_INFO  pHWHead)
{
    ULONG LineEvents = 0;
    if ( pHWHead->LSR & (SERIAL_LSR_OE | SERIAL_LSR_PE | SERIAL_LSR_FE)) {
        // Note: Its not wise to do debug msgs in here since they will
        // pretty much guarantee that the FIFO gets overrun.
        if ( pHWHead->LSR & SERIAL_LSR_OE ) {
            pHWHead->DroppedBytes++;
			pHWHead->CommErrors |= CE_OVERRUN;
        }

        if ( pHWHead->LSR & SERIAL_LSR_PE ) {
            pHWHead->CommErrors |= CE_RXPARITY;
        }

        if ( pHWHead->LSR & SERIAL_LSR_FE ) {
            pHWHead->CommErrors |= CE_FRAME;
        }

        LineEvents |= EV_ERR;
    }

    if ( pHWHead->LSR & SERIAL_LSR_BI )
        LineEvents |= EV_BREAK;

    // Let WaitCommEvent know about this error
    if ( LineEvents )
        pHWHead->EventCallback( pHWHead->pMddHead, LineEvents );

}

// Reading of the LSR register.
// After reading LSR get current status and process it

__inline
VOID ReadLSR( PSER_SC16IS_INFO  pHWHead )
{

    try {
			if(!pHWHead->Interface){ 
				INB(SC_LSR,pHWHead->pLSR);
			}
			else{
				INBSPI(SC_LSR,pHWHead->pLSR);
			}

    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        pHWHead->LSR = SERIAL_LSR_THRE;
    }
	ProcessLSR (pHWHead);
}

// Reading the MSR clears many of its bits.  So, we provide this wrapper,
// which reads the register, records any interesting values, and
// stores the current MSR contents in the shadow register.
// Note that we always have DDCD and DCTS enabled, so if someone
// wants to keep an eye on these lines, its OK to simply read the
// shadow register, since if the value changes, the interrupt
// will cause the shadow to be updated.

__inline 
VOID ProcessMSR (PSER_SC16IS_INFO  pHWHead)
{

    ULONG        Events = 0;
    // For changes, we use callback to evaluate the event
    if (pHWHead->MSR  & SERIAL_MSR_DCTS)
        Events |= EV_CTS;

    if ( pHWHead->MSR  & SERIAL_MSR_DDSR )
        Events |= EV_DSR;

    if ( pHWHead->MSR  & SERIAL_MSR_TERI )
        Events |= EV_RING;

    if ( pHWHead->MSR  & SERIAL_MSR_DDCD )
        Events |= EV_RLSD;

    if ( Events )
        pHWHead->EventCallback( pHWHead->pMddHead, Events );
}

// Reading of the MSR register.
// After reading MSR get current status and process it

__inline
VOID ReadMSR( PSER_SC16IS_INFO  pHWHead )
{
    UCHAR       msr;
    try {
		if(!pHWHead->Interface){ 
			INB(SC_MCR,pHWHead->pMCR);
			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)
			OUTB(SC_MCR,pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE);

			INB(SC_MSR,pHWHead->pMSR);

			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)
				OUTB(SC_MCR,pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE);
		}
		else{
			INBSPI(SC_MCR,pHWHead->pMCR);
			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)
			OUTBSPI(SC_MCR,pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE);

			INBSPI(SC_MSR,pHWHead->pMSR);

			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)
				OUTBSPI(SC_MCR,pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE);
		}
        msr = pHWHead->MSR;
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        msr = 0;
    }
    // Save the MSR value in a shadow
    pHWHead->MSR = msr;
    ProcessMSR (pHWHead);
}

// Helper routine to search through a lookup table for a designated
// key.
ULONG
LookUpValue(
           ULONG    Key,
           PLOOKUP_TBL pTbl,
           PULONG    pErrorCode
           )
{
    ULONG   index = 0;

    *pErrorCode = 0;

    while ( index < pTbl->Size ) {
        if ( Key == pTbl->Table[index].Key )
            return(pTbl->Table[index].AssociatedValue);

        ++index;
    }

    *pErrorCode = (ULONG)-1;

    return(0);
}

#ifdef STANDARD_BAUDTABLE

#define BAUD_TABLE_SIZE 23
#define CRYSTAL_MULTIPLIER 32 // Standard crystal value 1.8432MHz
static const
PAIRS    BaudPairs[BAUD_TABLE_SIZE] = {
    {50,	    2307 * CRYSTAL_MULTIPLIER},
    {75,	    1538 * CRYSTAL_MULTIPLIER},
    {110,	    1049 * CRYSTAL_MULTIPLIER},
    {135,	    858  * CRYSTAL_MULTIPLIER},
    {150,	    769  * CRYSTAL_MULTIPLIER},
    {300,	    384  * CRYSTAL_MULTIPLIER},
    {600,	    192  * CRYSTAL_MULTIPLIER},
    {1200,	    96   * CRYSTAL_MULTIPLIER},
    {1800,	    64	 * CRYSTAL_MULTIPLIER},
    {2000,	    58	 * CRYSTAL_MULTIPLIER},
    {2400,	    48	 * CRYSTAL_MULTIPLIER},
    {3600,	    32	 * CRYSTAL_MULTIPLIER},
    {4800,	    24	 * CRYSTAL_MULTIPLIER},
    {7200,	    16	 * CRYSTAL_MULTIPLIER},
    {9600,	    12	 * CRYSTAL_MULTIPLIER},
    {12800,	    9	 * CRYSTAL_MULTIPLIER},
    {14400,	    8	 * CRYSTAL_MULTIPLIER},
    {19200,     6	 * CRYSTAL_MULTIPLIER},
    {23040,     5	 * CRYSTAL_MULTIPLIER},
    {28800,     4	 * CRYSTAL_MULTIPLIER},
    {38400,     3	 * CRYSTAL_MULTIPLIER},
    {57600,     2	 * CRYSTAL_MULTIPLIER},
    {115200,    1	 * CRYSTAL_MULTIPLIER}
};

#else

#define BAUD_TABLE_SIZE 28
// Standard crystal value 14.7456MHz, Use Crystal multiplier equal to one.
#define CRYSTAL_MULTIPLIER 4 // With - 60MHZ

static const
PAIRS    BaudPairs[BAUD_TABLE_SIZE] = {
    {50,	    18432 * CRYSTAL_MULTIPLIER},
    {75,	    12288 * CRYSTAL_MULTIPLIER},
    {110,	    8378  * CRYSTAL_MULTIPLIER},
    {135,	    6827  * CRYSTAL_MULTIPLIER},
    {150,	    6144  * CRYSTAL_MULTIPLIER},
    {300,	    3072  * CRYSTAL_MULTIPLIER},
    {600,	    1536  * CRYSTAL_MULTIPLIER},
    {1200,	    768   * CRYSTAL_MULTIPLIER},
    {1800,	    512	  * CRYSTAL_MULTIPLIER},
    {2000,	    461	  * CRYSTAL_MULTIPLIER},
    {2400,	    384	  * CRYSTAL_MULTIPLIER},
    {3600,	    256	  * CRYSTAL_MULTIPLIER},
    {4800,	    192	  * CRYSTAL_MULTIPLIER},
    {7200,	    128	  * CRYSTAL_MULTIPLIER},
    {9600,	    96	  * CRYSTAL_MULTIPLIER},
    {12800,	    72	  * CRYSTAL_MULTIPLIER},
    {14400,	    64	  * CRYSTAL_MULTIPLIER},
    {19200,     48	  * CRYSTAL_MULTIPLIER},
    {23040,     40	  * CRYSTAL_MULTIPLIER},
    {28800,     32	  * CRYSTAL_MULTIPLIER},
    {38400,     24	  * CRYSTAL_MULTIPLIER},
    {57600,     16	  * CRYSTAL_MULTIPLIER},
    {115200,    8	  * CRYSTAL_MULTIPLIER},
	{230400,    4	  * CRYSTAL_MULTIPLIER},
	{460800,    2	  * CRYSTAL_MULTIPLIER},
	{921600,    1	  * CRYSTAL_MULTIPLIER},
	{1843200,   2						  }, //At 60Mhz 1875000
	{3686400,   1						  }  //At 60Mhz 3750000
};
#endif

static const
LOOKUP_TBL  BaudTable = {BAUD_TABLE_SIZE, (PAIRS *) BaudPairs};

// Helper function.  Pass in a baudrate, and the corresponding divisor
// (from the baudtable) is returned.  If no matching baudrate is found
// in baudtable, then return 0.
USHORT
DivisorOfRate(
             PVOID   pHead,      // @parm PVOID returned by HWinit.
             ULONG   BaudRate    // @parm     ULONG representing decimal baud rate.    
             )
{
    ULONG   errorcode = 0;
    USHORT  divisor;    

    divisor = (USHORT)LookUpValue(BaudRate,
                                  ((PSER_SC16IS_INFO) pHead)->pBaudTable, &errorcode);
    if ( errorcode )
        divisor = 0;

    return(divisor);
}

// @doc OEM
// @func   BOOL | SC_GetRegistryData | Perform registry read
// @parm   LPCTSTR regKeyPath,the registry path passed in to COM_Init.
// @rdesc  TRUE if successful, -1 if there is an error.

BOOL SC_GetRegistryData(PSER_SC16IS_INFO pHWHead, LPCTSTR regKeyPath)
{

#define GCI_BUFFER_SIZE 256   

    LONG    regError;
    HKEY    hKey;
    DWORD   dwDataSize = GCI_BUFFER_SIZE;

    DEBUGMSG(ZONE_INIT, (TEXT("Try to open %s\r\n"), regKeyPath));

    hKey = OpenDeviceKey(regKeyPath);
 	if ( hKey == NULL ) {
        DEBUGMSG(ZONE_INIT | ZONE_ERROR,
                 (TEXT("Failed to open device key\r\n")));
        return ( FALSE );        
    }
    dwDataSize = PC_REG_SYSINTR_VAL_LEN;
    regError = RegQueryValueEx(
                              hKey, 
                              PC_REG_SYSINTR_VAL_NAME, 
                              NULL, 
                              NULL,
                              (LPBYTE)(&pHWHead->dwSysIntr), 
                              &dwDataSize);
    if ( regError != ERROR_SUCCESS ) {
		RegCloseKey (hKey);
        DEBUGMSG(ZONE_INIT | ZONE_ERROR,
                 (TEXT("Failed to get serial registry values, Error 0x%X\r\n"),
                  regError));
        return ( FALSE );
    }
	dwDataSize = PC_REG_I2CSLAVE_VAL_LEN;
	regError = RegQueryValueEx(
                              hKey, 
                              PC_REG_I2CSLAVE_VAL_NAME, 
                              NULL, 
                              NULL,
                              (LPBYTE)(&pHWHead->dwSlaveAddress), 
                              &dwDataSize);
    if ( regError != ERROR_SUCCESS ) {
		RegCloseKey (hKey);
        DEBUGMSG(ZONE_INIT | ZONE_ERROR,
                 (TEXT("Failed to get serial Interface values, Error 0x%X\r\n"),
                  regError));
        return ( FALSE );
    }
	//Check the Registry Key "Interface" [I2C or SPI]
	dwDataSize = PC_REG_INTERFACE_VAL_LEN;
	regError = RegQueryValueEx(
                              hKey, 
                              PC_REG_INTERFACE_VAL_NAME, 
                              NULL, 
                              NULL,
                              (LPBYTE)(&pHWHead->Interface), 
                              &dwDataSize);
    if ( regError != ERROR_SUCCESS ) {
		RegCloseKey (hKey);
        DEBUGMSG(ZONE_INIT | ZONE_ERROR,
                 (TEXT("Failed to get serial registry values, Error 0x%X\r\n"),
                  regError));
        return ( FALSE );
    }
    //Check the Registry Key "FIFOMode" [Enable or Disable]
	dwDataSize = PC_REG_FIFOMODE_VAL_LEN;
	regError = RegQueryValueEx(
                              hKey, 
                              PC_REG_FIFOMODE_VAL_NAME, 
                              NULL, 
                              NULL,
                              (LPBYTE)(&pHWHead->FIFOMode), 
                              &dwDataSize);
    if ( regError != ERROR_SUCCESS ) {
		RegCloseKey (hKey);
        DEBUGMSG(ZONE_INIT | ZONE_ERROR,
                 (TEXT("Failed to get serial registry values, Error 0x%X\r\n"),
                  regError));
        return ( FALSE );
    }

	dwDataSize = PC_REG_PORTINDEX_VAL_LEN;
	regError = RegQueryValueEx(
                              hKey, 
                              PC_REG_PORTINDEX_VAL_NAME,
                              NULL,
                              NULL,
                              (LPBYTE)(&pHWHead->dwPortIndex),
                              &dwDataSize);
    if ( regError != ERROR_SUCCESS ) {
		RegCloseKey (hKey);
        DEBUGMSG(ZONE_INIT | ZONE_ERROR,
                 (TEXT("Failed to get serial registry values, Error 0x%X\r\n"),
                  regError));
        return ( FALSE );
    }
	dwDataSize = PC_REG_IO_NAMED_EVENT_VAL_LEN;
	regError = RegQueryValueEx(
                              hKey, 
                              PC_REG_IO_NAMED_EVENT_VAL_NAME,
                              NULL,
                              NULL,
                              (LPBYTE)(pHWHead->IoEventName),
                              &dwDataSize);
    if ( regError != ERROR_SUCCESS ) {
		RegCloseKey (hKey);
        DEBUGMSG(ZONE_INIT | ZONE_ERROR,
                 (TEXT("Failed to get serial registry values, Error 0x%X\r\n"),
                  regError));
        return ( FALSE );
    }
	dwDataSize = PC_REG_CHIPID_VAL_LEN;
	regError = RegQueryValueEx(
                              hKey, 
                              PC_REG_CHIPID_VAL_NAME,
                              NULL,
                              NULL,
                              (LPBYTE)(pHWHead->ChipID),
                              &dwDataSize);
    if ( regError != ERROR_SUCCESS ) {
		RegCloseKey (hKey);
        DEBUGMSG(ZONE_INIT | ZONE_ERROR,
                 (TEXT("Failed to get serial registry values, Error 0x%X\r\n"),
                  regError));
        return ( FALSE );
    }
    
    DEBUGMSG ( ZONE_INIT,
              (TEXT("SC16ISInit - SysIntr %d, SC16IS UART base addr %X \r\n"),
               pHWHead->dwSysIntr, pHWHead->dwIOBase));

    return ( TRUE ); 
}

//
/////////////////// Start of exported entrypoints ////////////////
//

// @doc OEM 
// @func PVOID | SC_Open | Configures default behavior.
// @parm PVOID returned by HWinit.

static BOOL SC_Open(PVOID   pHead )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BYTE TLRData;
    DEBUGMSG (ZONE_OPEN,
              (TEXT("+SC_Open 0x%X\r\n"), pHead));


	// Disallow multiple simultaneous opens
    if( pHWHead->cOpenCount )
        return FALSE;

    pHWHead->cOpenCount++;

	//Check port index
	if(pHWHead->dwPortIndex == 0){
		PORTAFLAG	= 1;
	}
	if(pHWHead->dwPortIndex == 1){
		PORTBFLAG	= 1;
	}
	if(IsrInitTrue == TRUE){
		ISRInit();
		IsrInitTrue = FALSE;
	}


    pHWHead->fIRMode  = FALSE;   // Select wired by default
    SC_SetOutputMode(pHWHead, pHWHead->fIRMode, !pHWHead->fIRMode );  

    // If the device is already open, all we do is increment count
    if ( pHWHead->OpenCount++ ) {
        DEBUGMSG (ZONE_OPEN,
                  (TEXT("-SC_Open 0x%X (%d opens)\r\n"),
                   pHead, pHWHead->OpenCount));
        return TRUE ;
    }

	pHWHead->FCR = 0;
    pHWHead->IER = 0;
    pHWHead->IIR = 0;
	pHWHead->LCR = 0;
    pHWHead->LSR = 0;
    pHWHead->MSR = 0;
    pHWHead->DroppedBytes = 0;
    pHWHead->CTSFlowOff = FALSE;  // Not flowed off yet
    pHWHead->DSRFlowOff = FALSE;  // Not flowed off yet
    pHWHead->CommErrors   = 0;
    pHWHead->ModemStatus  = 0;

    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
		if(!pHWHead->Interface){ 
		    OUTB(SC_IER, (UCHAR)IER_NORMAL_INTS);
			pHWHead->LCR |= +(SERIAL_8_DATA | SERIAL_1_STOP | SERIAL_NONE_PARITY);
			OUTB(SC_LCR, pHWHead->LCR);
		}
		else{
		    OUTBSPI(SC_IER, (UCHAR)IER_NORMAL_INTS);
			pHWHead->LCR |= +(SERIAL_8_DATA | SERIAL_1_STOP | SERIAL_NONE_PARITY);
			OUTBSPI(SC_LCR, pHWHead->LCR);
		}
        // Get defaults from the DCB structure
        SC_SetBaudRate( pHead, pHWHead->dcb.BaudRate );
        SC_SetByteSize( pHead, pHWHead->dcb.ByteSize );
        SC_SetStopBits( pHead, pHWHead->dcb.StopBits );
        SC_SetParity(   pHead, pHWHead->dcb.Parity );

		if(!pHWHead->Interface){ 
			pHWHead->FCR |= (SERIAL_FCR_RCVR_RESET | SERIAL_FCR_TXMT_RESET);
			OUTB(SC_FCR,pHWHead->FCR);
			pHWHead->FCR &= ~(SERIAL_FCR_RCVR_RESET | SERIAL_FCR_TXMT_RESET);
		}
		else{
			pHWHead->FCR |= (SERIAL_FCR_RCVR_RESET | SERIAL_FCR_TXMT_RESET);
			OUTBSPI(SC_FCR,pHWHead->FCR);
			pHWHead->FCR &= ~(SERIAL_FCR_RCVR_RESET | SERIAL_FCR_TXMT_RESET);
		}
		//IF FIFOMode is Enable we have to Enable the CHIP FIFO Mode
		if(pHWHead->FIFOMode){
			pHWHead->FCR |= SERIAL_FCR_ENABLE;
			if(!pHWHead->Interface){
				OUTB(SC_FCR, pHWHead->FCR);
			}
			else{
				OUTBSPI(SC_FCR, pHWHead->FCR);
			}

			//Set the default TX trigger level if FIFO mode is enabled
			TLRData = 32;
			Set_TX_Trigger_level(pHWHead ,&TLRData);

			//set the default RX trigger level if FIFO mode is enable
			TLRData = 32;
			Set_RX_Trigger_level(pHWHead,&TLRData);
		}

        ReadMSR(pHWHead);
        ReadLSR(pHWHead);
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Just get out of here.
    }
#pragma prefast(pop)

    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_OPEN,
              (TEXT("-SC_Open 0x%X, IIR 0x%X\r\n"), pHead, pHWHead->IIR));

	pHWHead->IoInterrupt = CreateEvent( NULL, FALSE, TRUE, (LPCWSTR)(TEXT("%s"),(TCHAR*)pHWHead->IoEventName));
	if(!pHWHead->IoInterrupt ){
		return FALSE;
	}
	else{
	return TRUE;
	}
	return TRUE;
}
//
// @doc OEM 
// @func PVOID | SC_Close | Does nothing except keep track of the
// open count so that other routines know what to do.
// @parm PVOID returned by HWinit.

static ULONG SC_Close( PVOID   pHead )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	ULONG  uTries;

    DEBUGMSG (ZONE_CLOSE,(TEXT("+SC_Close 0x%X\r\n"), pHead));

    if( pHWHead->cOpenCount )
    {
        pHWHead->cOpenCount--;
        
		if(pHWHead->dwPortIndex == 0){
			PORTAFLAG	= 0;
		}
		if(pHWHead->dwPortIndex == 1){
			PORTBFLAG	= 0;
		}

        // while we are still transmitting, sleep.
        uTries = 0;
        while ( (uTries++ < 100) &&
                !(pHWHead->LSR & SERIAL_LSR_TEMT) )
        {
            DEBUGMSG (ZONE_CLOSE, 
			(TEXT("SerClose, TX in progress, LSR 0x%X\r\n"),
                       pHWHead->LSR));
            Sleep(10);
        }
        pHWHead->fIRMode  = FALSE;  
        SC_SetOutputMode(pHWHead, FALSE, FALSE );
    }
    if ( pHWHead->OpenCount )
        pHWHead->OpenCount--;
	// If both ports are closed so we will close ISR thread handle
	if(PORTAFLAG == 0 && PORTBFLAG == 0){
		IsrCloseHandles();
		IsrInitTrue = TRUE;
	}
    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
		if(!pHWHead->Interface){ 
			// Disable all interrupts and clear MCR.
			OUTB(SC_IER, (UCHAR)0); 
			OUTB(SC_MCR, (UCHAR)0);
			INB(SC_IIR,pHWHead->pIIR); 
		}
		else{
			// Disable all interrupts and clear MCR.
			OUTBSPI(SC_IER, (UCHAR)0); 
			OUTBSPI(SC_MCR, (UCHAR)0);
			INBSPI(SC_IIR,pHWHead->pIIR); 
		}
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
    }
	LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_CLOSE,(TEXT("-SC_Close\r\n")));
    return 0;
}

//
// @doc OEM 
// @func PVOID | SC_Init | Initializes device head.  
//

static PVOID SC_Init(ULONG Identifier, PVOID pMddHead, PHWOBJ pHWObj)
{
    PSER_SC16IS_INFO   pHWHead;

	EVENT_FUNC EventCallback;
	SPI_SERIAL_TRANSACTION SpiTransaction;

    DEBUGMSG (ZONE_INIT, (TEXT(" +SC_Init - %X\r\n"), pMddHead ));

    // Allocate for our main data structure and one of it's fields.
    pHWHead = (PSER_SC16IS_INFO)LocalAlloc( LMEM_ZEROINIT|LMEM_FIXED,sizeof(SER_SC16IS_INFO) );
    if (!pHWHead)
        goto ALLOCFAILED;
    if ( ! SC_GetRegistryData(pHWHead, (LPCTSTR)Identifier) ) {
        DEBUGMSG (ZONE_INIT|ZONE_ERROR,
                  (TEXT("SC_Init - Unable to read registry data.  Failing Init !!! \r\n")));
        goto ALLOCFAILED;
    }
    pHWObj->dwIntID = pHWHead->dwSysIntr;

    pHWHead->pMddHead	  = pMddHead;
    pHWHead->pHWObj = pHWObj;
    pHWHead->cOpenCount   = 0;

     // Set up our Comm Properties data    
    pHWHead->CommProp.wPacketLength		 = 0xffff;
    pHWHead->CommProp.wPacketVersion     = 0xffff;
    pHWHead->CommProp.dwServiceMask      = SP_SERIALCOMM;
    pHWHead->CommProp.dwReserved1	     = 0;
    pHWHead->CommProp.dwMaxTxQueue	     = 64;
    pHWHead->CommProp.dwMaxRxQueue	     = 64;
    pHWHead->CommProp.dwMaxBaud			 = BAUD_115200;
    pHWHead->CommProp.dwProvSubType      = PST_RS232;
    pHWHead->CommProp.dwProvCapabilities =
        PCF_DTRDSR | PCF_RLSD | PCF_RTSCTS |
        PCF_SETXCHAR |
        PCF_INTTIMEOUTS |
        PCF_PARITY_CHECK |
        PCF_SPECIALCHARS |
        PCF_TOTALTIMEOUTS |
        PCF_XONXOFF;
    pHWHead->CommProp.dwSettableBaud      =
		BAUD_075 | BAUD_110 | BAUD_150 | BAUD_300 | BAUD_600 |
		BAUD_1200 | BAUD_1800 |	BAUD_2400 | BAUD_4800 |
		BAUD_7200 | BAUD_9600 | BAUD_14400 |
		BAUD_19200 | BAUD_38400 | BAUD_56K | BAUD_128K |
		BAUD_115200 | BAUD_57600 | BAUD_USER;
    pHWHead->CommProp.dwSettableParams    =
        SP_BAUD | SP_DATABITS | SP_HANDSHAKING | SP_PARITY |
        SP_PARITY_CHECK | SP_RLSD | SP_STOPBITS;
    pHWHead->CommProp.wSettableData       =
        DATABITS_5 | DATABITS_6 | DATABITS_7 | DATABITS_8;
    pHWHead->CommProp.wSettableStopParity =
        STOPBITS_10 | STOPBITS_20 |STOPBITS_15 |
        PARITY_NONE | PARITY_ODD | PARITY_EVEN | PARITY_SPACE |
        PARITY_MARK;
	//Initilize bus interface, only one time
	if(I2cSpiInitTrue == TRUE){ 
	if(!pHWHead->Interface){ 
		I2C_Bus_Init();
	}
	else{
		//Initialize the SPI bus
		 SC_SpiBusInit(FALSE);

		// setup up data structure for SPI device
		SpiTransaction.Device = 0;
		SpiTransaction.DataSize = 16;
		SpiTransaction.FrameFormat = SPI_FRAME_FORMAT_SPI;
		SpiTransaction.ClockRate = 13000000;//3000000;//1100000;//590000;	
		SpiTransaction.TimeOutMs = 100;
		SpiTransaction.Flags = SPI_FLAGS_8BIT_BUFFERS;

		//Configure the SPIBUS
		 SC_SpiBusConfig(&SpiTransaction, FALSE);
	}
		I2cSpiInitTrue = FALSE;
	}

    // Set up pointers of registers
    pHWHead->pData     = &pHWHead->Data;
    pHWHead->pIER      = &pHWHead->IER;
    pHWHead->pIIR	   = &pHWHead->IIR;
	pHWHead->pFCR	   = &pHWHead->FCR;
    pHWHead->pLCR      = &pHWHead->LCR;
    pHWHead->pMCR      = &pHWHead->MCR;
    pHWHead->pLSR      = &pHWHead->LSR;
    pHWHead->pMSR      = &pHWHead->MSR;
    pHWHead->pScratch  = &pHWHead->Scratch;
    pHWHead->pTCR	   = &pHWHead->TCR;
    pHWHead->pTLR	   = &pHWHead->TLR;
    pHWHead->pTXLVL	   = &pHWHead->TXLVL;
    pHWHead->pRXLVL    = &pHWHead->RXLVL;
    pHWHead->pIODIR    = &pHWHead->IODIR;
    pHWHead->pIOSTATE  = &pHWHead->IOSTATE;
    pHWHead->pIOINTENA = &pHWHead->IOINTENA;
    pHWHead->pIOCTRL   = &pHWHead->IOCTRL;
	pHWHead->pEFCR     = &pHWHead->EFCR;
	pHWHead->pEFR      = &pHWHead->EFR;
	pHWHead->pXON1     = &pHWHead->XON1;
	pHWHead->pXON2     = &pHWHead->XON2;
	pHWHead->pXOFF1    = &pHWHead->XOFF1;
	pHWHead->pXOFF2    = &pHWHead->XOFF2;

    // Store info for callback function
	EventCallback = EvaluateEventFlag;
    pHWHead->EventCallback = EventCallback;
    pHWHead->pMddHead = pMddHead;

    // Now set up remaining fields
    pHWHead->pBaudTable = (LOOKUP_TBL *) &BaudTable;

    pHWHead->FlushDone      = CreateEvent(0, FALSE, FALSE, NULL);

    pHWHead->OpenCount = 0;

	if(!pHWHead->Interface){ 
	    //Don't allow any interrupts till PostInit.
		OUTB(SC_IER, (UCHAR)0);
	}
	else{
		OUTBSPI(SC_IER, (UCHAR)0);
	}
	
	InitializeCriticalSection(&(pHWHead->TransmitCritSec));
    InitializeCriticalSection(&(pHWHead->RegCritSec));

    pHWHead->PowerDown = FALSE;
    pHWHead->bSuspendResume = FALSE;

	// Clear any interrupts which may be pending
    ClearPendingInts( pHWHead );

    DEBUGMSG (ZONE_CLOSE,(TEXT("-SC_INIT, 0x%X\r\n"), pHWHead));
	
    pHWHead->fIRMode  = FALSE;   // Select wired by default
    SC_SetOutputMode(pHWHead, FALSE, FALSE );    
    
	Interface   = pHWHead->Interface;
	Sysintr	    = pHWHead->dwSysIntr;
	I2CSlaveAdd	= pHWHead->dwSlaveAddress;
	PORTAFLAG	= 0;
	PORTBFLAG	= 0;

	if( pHWHead->dwPortIndex == 0 ){
		IIR0 = &pHWHead->IIR;
	}
	if( pHWHead->dwPortIndex == 1 ){
		IIR1 = &pHWHead->IIR;
	}

    return pHWHead;
 
ALLOCFAILED:
    if (pHWHead) {
        if ( pHWHead->pBaseAddress )
            VirtualFree(pHWHead->pBaseAddress, 0, MEM_RELEASE);
    
        LocalFree(pHWHead);
    }
    return NULL;
}

// @doc OEM
// @func void | SC_PostInit | This routine takes care of final initialization.
//
// @rdesc None.

BOOL
SC_PostInit( PVOID   pHead )
{
    PSER_SC16IS_INFO   pHWHead   = (PSER_SC16IS_INFO)pHead;

	// Cancel any pending interrupts
    ClearPendingInts( pHWHead );
    
    DEBUGMSG (ZONE_INIT,(TEXT("-SC_PostInit, 0x%X\r\n"), pHWHead));
    return(TRUE);
}

// @doc OEM 
// @func PVOID | SC_Deinit | De-initializes device head.  
//
// @rdesc None.

static BOOL SC_Deinit( PVOID   pHead )
{
    PSER_SC16IS_INFO   pHWHead   = (PSER_SC16IS_INFO)pHead;

    if ( !pHWHead )
        return FALSE;
    DEBUGMSG (ZONE_CLOSE,(TEXT("+SC_DEINIT, 0x%X\r\n"), pHWHead));
     // Make sure device is closed before doing DeInit
    if( pHWHead->cOpenCount )
        SC_Close( pHead );

    DeleteCriticalSection(&(pHWHead->TransmitCritSec));
    DeleteCriticalSection(&(pHWHead->RegCritSec));

	if(!pHWHead->Interface){ 
		I2C_Bus_Deinit(); //Free occupied memory and delete critical section
	}
	else{
		SPI_deinit();	  // Free occupied memory and delete critical section
	}    
    // Free the flushdone event
    if ( pHWHead->FlushDone )
        CloseHandle( pHWHead->FlushDone );
    // Free the HWObj
    LocalFree(pHWHead->pHWObj);
	// And now free the SER_INFO structure.    
    LocalFree(pHWHead);

    DEBUGMSG (ZONE_CLOSE,(TEXT("-SC_DEINIT, 0x%X\r\n"), pHWHead));

    return TRUE;
}

// @doc OEM
// @func void | SC_ClearDtr | This routine clears DTR.
//
// @rdesc None.

VOID SC_ClearDTR( PVOID   pHead )
{
    PSER_SC16IS_INFO   pHWHead   = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION, (TEXT("+SC_ClearDTR, 0x%X\r\n"), pHead));
    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {

		if(!pHWHead->Interface){ 
			INB(SC_MCR,pHWHead->pMCR); 
			OUTB(SC_MCR, (pHWHead->MCR  & ~SERIAL_MCR_DTR));
		}
		else{
			INBSPI(SC_MCR,pHWHead->pMCR); 
			OUTBSPI(SC_MCR, (pHWHead->MCR  & ~SERIAL_MCR_DTR));
		}
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Just exit
    }
#pragma prefast(pop)
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION, (TEXT("-SC_ClearDTR, 0x%X\r\n"), pHead));
}

//
// @doc OEM
// @func VOID | SC_SetDTR | This routine sets DTR.
// 
// @rdesc None.
//
VOID SC_SetDTR( PVOID   pHead )
{    
    PSER_SC16IS_INFO   pHWHead   = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION, (TEXT("+SC_SetDTR, 0x%X\r\n"), pHead));
    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
		if(!pHWHead->Interface){ 
			INB(SC_MCR,pHWHead->pMCR); 
			OUTB(SC_MCR,(pHWHead->MCR | SERIAL_MCR_DTR));
		}
		else{
			INBSPI(SC_MCR,pHWHead->pMCR); 
			OUTBSPI(SC_MCR,(pHWHead->MCR | SERIAL_MCR_DTR));
		}
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
    }
#pragma prefast(pop)
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION, (TEXT("-SC_SetDTR, 0x%X\r\n"), pHead));
}

// @doc OEM
// @func VOID | SC_ClearRTS | This routine clears RTS.
// 
// @rdesc None.

VOID SC_ClearRTS( PVOID   pHead )
{
    PSER_SC16IS_INFO   pHWHead   = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION, (TEXT("+SC_ClearRTS, 0x%X\r\n"), pHead));
    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
		if(!pHWHead->Interface){ 
			INB(SC_MCR,pHWHead->pMCR); 
			OUTB(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_RTS));
		}
		else{
			INBSPI(SC_MCR,pHWHead->pMCR); 
			OUTBSPI(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_RTS));
		}
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Just exit
    }
#pragma prefast(pop)
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION, (TEXT("-SC_ClearRTS, 0x%X\r\n"), pHead));
}

// @doc OEM
// @func VOID | SC_SetRTS | This routine sets RTS.
// 
// @rdesc None.

VOID SC_SetRTS( PVOID   pHead )
{
    PSER_SC16IS_INFO   pHWHead   = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION, (TEXT("+SC_SetRTS, 0x%X\r\n"), pHead));

    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
		if(!pHWHead->Interface){ 
			INB(SC_MCR,pHWHead->pMCR); 
			OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_RTS));
		}
		else{
			INBSPI(SC_MCR,pHWHead->pMCR); 
			OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_RTS));
		}
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Just exit
    }
#pragma prefast(pop)
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION, (TEXT("-SC_SetRTS, 0x%X\r\n"), pHead));
}

// @doc OEM
// @func BOOL | SC_EnableIR | This routine enables ir.
// Not exported to users, only to driver.
//
// @rdesc Returns TRUE if successful, FALSEotherwise.

static BOOL SC_EnableIR( PVOID pHead, ULONG   BaudRate )
{
    PSER_SC16IS_INFO	pHWHead = (PSER_SC16IS_INFO)pHead;

	if(!pHWHead->Interface){ 
		if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode

			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

			INB(SC_EFR,pHWHead->pEFR);	
			OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
			pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;

			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}

		INB(SC_MCR,pHWHead->pMCR);
		OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_IRDA_MODE_ENABLE));
	}
	else{
		if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode

			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

			INBSPI(SC_EFR,pHWHead->pEFR);	
			OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
			pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;

			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}
		INBSPI(SC_MCR,pHWHead->pMCR);
		OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_IRDA_MODE_ENABLE));
	}
    pHWHead->MCR |= SERIAL_MCR_IRDA_MODE_ENABLE;

     // Not sure why he passes baudRate when its already in our
     // pHWHead.  So I'll ignore it and use the one in our struct.
    pHWHead->fIRMode  = TRUE;
    SC_SetOutputMode( pHWHead, pHWHead->fIRMode, !pHWHead->fIRMode );
    return TRUE;
}

// @doc OEM
// @func BOOL | SC_DisableIR | This routine disable the ir.
//  Not exported to users, only to driver.
//
// @rdesc Returns TRUE if successful, FALSEotherwise.

static BOOL SC_DisableIR( PVOID pHead )
{
    PSER_SC16IS_INFO	pHWHead = (PSER_SC16IS_INFO)pHead;

	if(!pHWHead->Interface){ 
		if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode

			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

			INB(SC_EFR,pHWHead->pEFR);	
			OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
			pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;

			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}

		INB(SC_MCR,pHWHead->pMCR);
		OUTB(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_IRDA_MODE_ENABLE));
	}
	else{
		if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode

			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

			INBSPI(SC_EFR,pHWHead->pEFR);	
			OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
			pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;

			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}

		INBSPI(SC_MCR,pHWHead->pMCR);
		OUTBSPI(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_IRDA_MODE_ENABLE));
	}
    pHWHead->MCR &= ~SERIAL_MCR_IRDA_MODE_ENABLE;

    pHWHead->fIRMode  = FALSE;
    SC_SetOutputMode( pHWHead, pHWHead->fIRMode, !pHWHead->fIRMode );
    return TRUE;
}

// @doc OEM
// @func VOID | SC_ClearBreak | This routine clears break.
// 
// @rdesc None.

VOID SC_ClearBreak( PVOID   pHead )
{
    PSER_SC16IS_INFO   pHWHead   = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION, (TEXT("+SC_ClearBreak, 0x%X\r\n"), pHead));

    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
		if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR); 
			OUTB(SC_LCR, (pHWHead->LCR & ~SERIAL_LCR_BREAK));
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR); 
			OUTBSPI(SC_LCR, (pHWHead->LCR & ~SERIAL_LCR_BREAK));
		}
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Just exit
    }
#pragma prefast(pop)
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION, (TEXT("-SC_ClearBreak, 0x%X\r\n"), pHead));
}

// @doc OEM
// @func VOID | SC_SetBreak | This routine sets break.
// @parm PVOID returned by HWinit.
// @rdesc None.

VOID SC_SetBreak( PVOID pHead )
{
    PSER_SC16IS_INFO   pHWHead   = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION, (TEXT("+SC_SetBreak, 0x%X\r\n"), pHead));

    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
		if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR); 
			OUTB(SC_LCR, (pHWHead->LCR | SERIAL_LCR_BREAK));
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR); 
			OUTBSPI(SC_LCR, (pHWHead->LCR | SERIAL_LCR_BREAK));
		}
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Just exit
    }
#pragma prefast(pop)
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION, (TEXT("-SC_SetBreak, 0x%X\r\n"), pHead));
}

// SetBaudRate
//
// Internal function.  The only real reason for splitting this out
// is so that we can call it from PowerOn and still allow SC_SetBaud
// to do debug messages, acquire critical sections, etc.

BOOL SetBaudRate( PVOID   pHead, ULONG   BaudRate )
{
    PSER_SC16IS_INFO    pHWHead = (PSER_SC16IS_INFO)pHead;
    USHORT        divisor;
	
	if(!pHWHead->Interface) 
		INB(SC_IER,pHWHead->pIER); // Check if device is in sleep mode, disable sleep mode
	else
		INBSPI(SC_IER,pHWHead->pIER);
		
	if(pHWHead->IER & SERIAL_IER_SLEEP_MODE){// when we want to set baudrate
		if(!pHWHead->Interface){ 
			INB(SC_IER,pHWHead->pIER);
			OUTB(SC_IER, (pHWHead->IER & ~SERIAL_IER_SLEEP_MODE));
		}
		else{
			INBSPI(SC_IER,pHWHead->pIER);
			OUTBSPI(SC_IER, (pHWHead->IER & ~SERIAL_IER_SLEEP_MODE));
		}
	}

    // **** Warning ***** Make no system calls, called in power context
    divisor = DivisorOfRate(pHead, BaudRate);

    if ( divisor ) {
		if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR); 
			OUTB(SC_LCR, (pHWHead->LCR | SERIAL_LCR_DLAB));
			OUTB(SC_THR, (divisor & 0xff)); //pData is DivLatch Lo
			OUTB(SC_IER, ((divisor >> 8) & 0xff)); //pIER is DivLatch Hi
			OUTB(SC_LCR, pHWHead->LCR);
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR); 
			OUTBSPI(SC_LCR, (pHWHead->LCR | SERIAL_LCR_DLAB));
			OUTBSPI(SC_THR, (divisor & 0xff)); //pData is DivLatch Lo
			OUTBSPI(SC_IER, ((divisor >> 8) & 0xff)); //pIER is DivLatch Hi
			OUTBSPI(SC_LCR, pHWHead->LCR);
		}
		if(pHWHead->IER & SERIAL_IER_SLEEP_MODE){ // Enable sleep mode if we have disable it 
			if(!pHWHead->Interface){			  // for baud rate setting
				INB(SC_IER,pHWHead->pIER);
				OUTB(SC_IER, (pHWHead->IER | SERIAL_IER_SLEEP_MODE));
			}
			else{
				INBSPI(SC_IER,pHWHead->pIER);
				OUTBSPI(SC_IER, (pHWHead->IER | SERIAL_IER_SLEEP_MODE));
			}
		}
		return TRUE;
    
    }
    else
        return FALSE;
}

//
// @doc OEM
// @func BOOL | SC_SetBaudRate |
//  This routine sets the baud rate of the device.
// @parm ULONG representing decimal baud rate.
// @rdesc None.
//
BOOL
SC_SetBaudRate( PVOID   pHead, ULONG   BaudRate )
{
    BOOL fRet;
    PSER_SC16IS_INFO    pHWHead = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION,(TEXT("+SC_SetbaudRate 0x%X, x%X\r\n"), pHead, BaudRate));

     // If we are running in IR mode, try to set the IR baud
     // first, since it supports a subset of the rates supported
     // by the UART.  If we fail setting the IR rate, then
     // return an error and leave the UART alone.
    if( pHWHead->fIRMode )
    {
        if( ! SC_SetIRBaudRate( pHWHead, BaudRate ) )
        {
            // We should return an error, but vtbl doesn't expect one
            return FALSE; 
        }
    }

    try {
        // Enter critical section before calling function, since
        // we can't make sys calls inside SetBaudRate
        EnterCriticalSection(&(pHWHead->RegCritSec));
        fRet = SetBaudRate(pHead, BaudRate);
        LeaveCriticalSection(&(pHWHead->RegCritSec));
    }except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
             EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        return( FALSE );
    }

    if ( fRet ) {
        pHWHead->dcb.BaudRate = BaudRate;

        DEBUGMSG (ZONE_FUNCTION,
                  (TEXT("-SC_SetbaudRate 0x%X (%d Baud)\r\n"),
                   pHead, BaudRate));
        return( TRUE );
    } else {
        DEBUGMSG (ZONE_FUNCTION | ZONE_ERROR,
                  (TEXT("-SC_SetbaudRate - Error setting %d, failing to %d\r\n"),
                   BaudRate, pHWHead->dcb.BaudRate) );
        return( FALSE );
	}

}

// @doc OEM
// @func BOOL | SC_SetByteSize |
// This routine sets the WordSize of the device.
// @parm     PVOID returned by HWInit
// @parm     ULONG ByteSize field from DCB.
// @rdesc None.

BOOL SC_SetByteSize( PVOID   pHead, ULONG   ByteSize )
{
    PSER_SC16IS_INFO    pHWHead = (PSER_SC16IS_INFO)pHead;
    UINT8 lcr;
    BOOL bRet;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_SetByteSize 0x%X, x%X\r\n"), pHead, ByteSize));

    bRet = TRUE;

    EnterCriticalSection(&(pHWHead->RegCritSec));
    try {

		if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR); 
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR); 	
		}
        lcr = pHWHead->LCR;		

        lcr &= ~SERIAL_DATA_MASK;
        switch ( ByteSize ) {
        case 5:
            lcr |= SERIAL_5_DATA;
            break;
        case 6:
            lcr |= SERIAL_6_DATA;
            break;
        case 7:
            lcr |= SERIAL_7_DATA;
            break;
        case 8:
            lcr |= SERIAL_8_DATA;
            break;
        default:
            bRet = FALSE;
            break;
        }
        if (bRet) {

			if(!pHWHead->Interface){ 
				OUTB(SC_LCR, lcr);
			}
			else{
				OUTBSPI(SC_LCR, lcr);
			}
        }
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        bRet = FALSE;
    }
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_SetByteSize 0x%X\r\n"), pHead));

    return(bRet);
}

// @doc OEM
// @func BOOL | SC_SetParity |
//  This routine sets the parity of the device.
// @parm     PVOID returned by HWInit
// @parm     ULONG parity field from DCB.
// @rdesc None.

BOOL SC_SetParity( PVOID   pHead, ULONG   Parity )
{
    PSER_SC16IS_INFO    pHWHead = (PSER_SC16IS_INFO)pHead;
    UINT8 lcr;
    BOOL bRet;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_SetParity 0x%X, x%X\r\n"), pHead, Parity));

    bRet = TRUE;

    EnterCriticalSection(&(pHWHead->RegCritSec));
    try {
		if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR); 
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR); 	
		}
        lcr = pHWHead->LCR;
        
		lcr &= ~SERIAL_PARITY_MASK;
        switch ( Parity ) {
        case ODDPARITY:
            lcr |= SERIAL_ODD_PARITY;
            break;

        case EVENPARITY:
            lcr |= SERIAL_EVEN_PARITY;
            break;

        case MARKPARITY:
            lcr |= SERIAL_MARK_PARITY;
            break;

        case SPACEPARITY:
            lcr |= SERIAL_SPACE_PARITY;
            break;

        case NOPARITY:
            lcr |= SERIAL_NONE_PARITY;
            break;
        default:
            bRet = FALSE;
            break;
        }
        if (bRet) {
			if(!pHWHead->Interface){ 
				OUTB(SC_LCR, lcr);
			}
			else{
				OUTBSPI(SC_LCR, lcr);
			}
        }
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        bRet = FALSE;
    }
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_SetParity 0x%X\r\n"), pHead));

    return(bRet);
}

// @doc OEM
// @func VOID | SC_SetStopBits |
//  This routine sets the Stop Bits for the device.
// @parm     ULONG StopBits field from DCB.
// @rdesc None.

BOOL SC_SetStopBits( PVOID   pHead, ULONG   StopBits )
{
    PSER_SC16IS_INFO    pHWHead = (PSER_SC16IS_INFO)pHead;
    UINT8 lcr;
    BOOL bRet;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_SetStopBits 0x%X, x%X\r\n"), pHead, StopBits));

    bRet = TRUE;

    EnterCriticalSection(&(pHWHead->RegCritSec));

	if(!pHWHead->Interface){ 
		INB(SC_LCR,pHWHead->pLCR); 
	}
	else{
		INBSPI(SC_LCR,pHWHead->pLCR); 
	}
    lcr = pHWHead->LCR;
    lcr &= ~SERIAL_STOP_MASK;

    try {
        // Note that 1.5 stop bits only works if the word size
        // is 5 bits.  Any other xmit word size will cause the
        // 1.5 stop bit setting to generate 2 stop bits.
        switch ( StopBits ) {
        case ONESTOPBIT :
            lcr |= SERIAL_1_STOP ;
            break;
        case ONE5STOPBITS :
            lcr |= SERIAL_1_5_STOP ;
            break;
        case TWOSTOPBITS :
            lcr |= SERIAL_2_STOP ;
            break;
        default:
            bRet = FALSE;
            break;
        }
        if (bRet) {
			if(!pHWHead->Interface){ 
				OUTB(SC_LCR, lcr);
			}
			else{
				OUTBSPI(SC_LCR, lcr);
			}
        }
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        bRet = FALSE;
    }

    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_SetStopBits 0x%X\r\n"), pHead));

    return(bRet);
}

// @doc OEM
// @func ULONG | SC_GetRxBufferSize | This function returns
// the size of the hardware buffer passed to the interrupt
// initialize function.  It would be used only for devices
// which share a buffer between the MDD/PDD and an ISR.
// 
// @rdesc This routine always returns 0 
ULONG SC_GetRxBufferSize( PVOID pHead )
{
    return(0);
}

// @doc OEM
// @func PVOID | SC_GetRxStart | This routine returns the start of the hardware
// receive buffer.  See SC_GetRxBufferSize.
// 
// @rdesc The return value is a pointer to the start of the device receive buffer.

PVOID SC_GetRxStart( PVOID   pHead )
{
    return(NULL);
}

// @doc OEM
// @func ULONG | SC_GetGetInterruptType | This function is called
//   by the MDD whenever an interrupt occurs.  The return code
//   is then checked by the MDD to determine which of the four
//   interrupt handling routines are to be called.
// 
// @rdesc This routine returns a bitmask indicating which interrupts
//   are currently pending.

INTERRUPT_TYPE SC_GetInterruptType( PVOID pHead )
{
    PSER_SC16IS_INFO    pHWHead = (PSER_SC16IS_INFO)pHead;
    INTERRUPT_TYPE interrupts=INTR_NONE;
   
    DEBUGMSG (ZONE_THREAD,
              (TEXT("+SC_GetInterruptType 0x%X\r\n"), pHead));
    
		try {
			if(!pHWHead->Interface){ 
				if(!pHWHead->dwPortIndex){
					if(ReadFlag0 == TRUE)
				INB(SC_IIR,pHWHead->pIIR);
					else{
						ReadFlag0 = TRUE;
					}
				}else{
					if(ReadFlag1 == TRUE)
						INB(SC_IIR,pHWHead->pIIR); 
					else{
						ReadFlag1 = TRUE;
					}
				}
			}
			else{
				if(!pHWHead->dwPortIndex){
					if(ReadFlag0 == TRUE){
				INBSPI(SC_IIR,pHWHead->pIIR); 
					}
					else{
						ReadFlag0 = TRUE;
					}

				}else{
					if(ReadFlag1 == TRUE)
						INBSPI(SC_IIR,pHWHead->pIIR); 
					else{
						ReadFlag1 = TRUE;
					}
				}
			}
		}
        except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
                EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
            pHWHead->IIR = SERIAL_IIR_NO_INTERRUPT_PENDING; // simulate no interrupt
        }

		if ( pHWHead->IIR & SERIAL_IIR_NO_INTERRUPT_PENDING ) {
            // No interrupts pending, vector is useless
            interrupts = INTR_NONE;
        } else {

            // The interrupt value is valid
            switch ( pHWHead->IIR & SERIAL_IIR_INT_MASK ) {
            case SERIAL_IIR_RLS:
                    interrupts |= INTR_LINE;
	                break;
            case SERIAL_IIR_CTI:
            case SERIAL_IIR_RDA:
                interrupts = INTR_RX;
                break;

            case SERIAL_IIR_THRE :
                interrupts = INTR_TX;
                break;
            case SERIAL_IIR_MS :
                interrupts = INTR_MODEM;
                break;
            case SERIAL_IIR_XOFF :
                interrupts = INTR_MODEM;
                break;
            case SERIAL_IIR_RTS_CTS :
                interrupts = INTR_MODEM;
                break;
            case SERIAL_IIR_CIP :
                interrupts = INTR_MODEM;
                break;

            default:
                interrupts = INTR_NONE;
                break;
            }
        }
        if (pHWHead->AddTXIntr) {
            interrupts |= INTR_TX;
            pHWHead->AddTXIntr = FALSE;
        }

        DEBUGMSG (ZONE_THREAD,
              (TEXT("-SC_GetInterruptType 0x%X, 0x%X\r\n"),
               pHead, interrupts));

    return(interrupts);
}

// @doc OEM
// @func ULONG | SC_RxIntr | This routine gets several characters from the hardware
//   receive buffer and puts them in a buffer provided via the second argument.
//   It returns the number of bytes lost to overrun.
// @parm Pointer to receive buffer
// @parm In = max bytes to read, out = bytes read
// @rdesc The return value indicates the number of overruns detected.
//   The actual number of dropped characters may be higher.

ULONG SC_RxIntr( PVOID pHead, PUCHAR pRxBuffer, ULONG *pBufflen )
{
    PSER_SC16IS_INFO   pHWHead    = (PSER_SC16IS_INFO)pHead;
    ULONG        RetVal    = 0;
    ULONG        TargetRoom    = *pBufflen;
    BOOL        fRXFlag = FALSE;
    BOOL        fReplaceparityErrors = FALSE;
    BOOL        fNull;
    UCHAR       cEvtChar, cRXChar;
	BOOL		transfer_complete = FALSE;

    *pBufflen = 0;

	//Make local copies to avoid dereferencing
    cEvtChar = pHWHead->dcb.EvtChar;
    fNull = pHWHead->dcb.fNull;
    if ( pHWHead->dcb.fErrorChar && pHWHead->dcb.fParity )
        fReplaceparityErrors = TRUE;
    
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
        while ( TargetRoom ){

				if(pHWHead->FIFOMode && (pHWHead->Interface == 1)){
				//FIFO Mode is Enable and Interface Is SPI	
				do
				{
					while (pHWHead->ucRxRemain && TargetRoom )
					{
						cRXChar = *(pHWHead->lpbRemainBufPtr++);

						if (fNull && !cRXChar )
						{
					   	   DEBUGMSG( ZONE_FLOW | ZONE_WARN, (_T("Dropping NULL byte due to fNull\r\n")));
						}
						else
						{
							*pRxBuffer++ = cRXChar;
							(*pBufflen)++;
							--TargetRoom;
						}
						// See if we need to generate an EV_RXFLAG for the received char.
	           			if( cRXChar == cEvtChar )
	           			{
	               			fRXFlag = TRUE;
						}
						(pHWHead->ucRxRemain)--;	
						transfer_complete = TRUE;
					}
					if (!(pHWHead->ucRxRemain) && (transfer_complete == FALSE))
					{
						//Read the FIFO Counter Register to check how many bytes are there
						do{
							INBSPI(SC_RXLVL,pHWHead->pRXLVL); 
							pHWHead->ucRxRemain = pHWHead->RXLVL;
						}while(pHWHead->RXLVL > 64);

						if(pHWHead->ucRxRemain == 0){
								DEBUGMSG (0,(TEXT("RXINTR = %x\r\n"),pHWHead->ucRxRemain));
								break;
						}

						if(pHWHead->ucRxRemain > TargetRoom){
							pHWHead->ucRxRemain = (BYTE)TargetRoom;
						}
						//Read the FIFO Data
						SPI_FIFO_READ(&(pHWHead->bRemainBuffer[0]),&pHWHead->ucRxRemain,(UCHAR)pHWHead->dwPortIndex);
						pHWHead->lpbRemainBufPtr = &(pHWHead->bRemainBuffer[0]);
					}
				}while( pHWHead->ucRxRemain && TargetRoom );
				
				break;
			}
			else if(pHWHead->FIFOMode && (pHWHead->Interface == 0)){
			//FIFO Mode is Enable and Interface Is I2C	, in I2C case we still have to read Byte by Byte
			// Read the FIFO Counter register to check how many bytes are available
				INB(SC_RXLVL,pHWHead->pRXLVL);
				pHWHead->ucRxRemain = pHWHead->RXLVL;

			    while(pHWHead->ucRxRemain && TargetRoom){
						// Read the Data from the RHR 
						INB(SC_RHR,pHWHead->pData); 
						cRXChar = pHWHead->Data;
						*pRxBuffer++ = cRXChar;
						(*pBufflen)++;
						--TargetRoom;
						pHWHead->ucRxRemain -- ;
				}
				break;
			}
			else{
				//FIFO Mode is disabled and Single Read and write mode of operations
				   // See if there is another byte to be read
					 ReadLSR( pHWHead );
					 if ( pHWHead->LSR & SERIAL_LSR_DR ) {

						if(!pHWHead->Interface){ 
							// Read the byte
							INB(SC_RHR,pHWHead->pData); 
						}
						else{
							// Read the byte
							INBSPI(SC_RHR,pHWHead->pData); 
						}
					   cRXChar = pHWHead->Data;
 					   DEBUGMSG (ZONE_READ | ZONE_THREAD,
						   (TEXT("SC_RxIntr - Char Read %c\r\n"),
							  cRXChar));

						// But we may want to discard it
						if ( pHWHead->dcb.fDsrSensitivity &&
							(! (pHWHead->MSR & SERIAL_MSR_DSR)) ) {
			            
						} else if (!cRXChar && fNull) {

						} else {
							// Do character replacement if parity error detected.
							if ( fReplaceparityErrors && (pHWHead->LSR & SERIAL_LSR_PE) ) {
								cRXChar = pHWHead->dcb.ErrorChar;
							} else {
								// See if we need to generate an EV_RXFLAG for the received char.
								if ( cRXChar == cEvtChar )
									fRXFlag = TRUE;
							}

							// Finally, we can get byte, update status and save.
							*pRxBuffer++ = cRXChar;
							(*pBufflen)++;
							--TargetRoom;

							}
						 }
						 else {
								break;            					                
						 }
				}
			}
		}
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
    }
#pragma prefast(pop)

    // if we saw one (or more) EVT chars, then generate an event
    if ( fRXFlag )
        pHWHead->EventCallback( pHWHead->pMddHead, EV_RXFLAG );

    RetVal = pHWHead->DroppedBytes;
    pHWHead->DroppedBytes = 0;
    return(RetVal);
}

// @doc OEM
// @func ULONG | 0 | This routine is called from the new MDD
//   whenever INTR_TX is returned by SC_GetInterruptType
// @parm Pointer to receive buffer
// @parm In = max bytes to transmit, out = bytes transmitted
// @rdesc None

VOID SC_TxIntrEx(PVOID pHead, PUCHAR pTxBuffer, ULONG *pBufflen )
{
    PSER_SC16IS_INFO   pHWHead    = (PSER_SC16IS_INFO)pHead;
    ULONG NumberOfBytes = *pBufflen;
	BYTE ucLen;
    UCHAR    byteCount;
	static int i = 0;
    DEBUGMSG (ZONE_WRITE,
              (TEXT("+SC_TxIntrEx 0x%X, Len %d\r\n"), pHead, *pBufflen));


    // We may be done sending.  If so, just disable the TX interrupts
    // and return to the MDD.  
    if( ! *pBufflen ) {
        DEBUGMSG (ZONE_WRITE, (TEXT("SC_TxIntrEx: Disable INTR_TX.\r\n")));
		if(!pHWHead->Interface){ 
			OUTB(SC_IER, IER_NORMAL_INTS);
		}
		else{
			OUTBSPI(SC_IER, IER_NORMAL_INTS);
		}
        return;
    }

    *pBufflen = 0;  // In case we don't send anything below.
    
    // Disable xmit intr.  Most 16550s will keep hammering
    // us with xmit interrupts if we don't turn them off
    // Whoever gets the FlushDone will then need to turn
    // TX Ints back on if needed.
    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
        // Need to signal FlushDone for XmitComChar
        PulseEvent(pHWHead->FlushDone);

        pHWHead->CommErrors &= ~CE_TXFULL;

        // If CTS flow control is desired, check cts. If clear, don't send,
        // but loop.  When CTS comes back on, the OtherInt routine will
        // detect this and re-enable TX interrupts (causing Flushdone).
        // For finest granularity, we would check this in the loop below,
        // but for speed, I check it here (up to 8 xmit characters before
        // we actually flow off.
        if ( pHWHead->dcb.fOutxCtsFlow ) {
            // ReadMSR( pHWHead );
            // We don't need to explicitly read the MSR, since we always enable
            // IER_MS, which ensures that we will get an interrupt and read
            // the MSR whenever CTS, DSR, TERI, or DCD change.

            if (! (pHWHead->MSR & SERIAL_MSR_CTS) ) {
                unsigned char byte;

                pHWHead->CTSFlowOff = TRUE;  // Record flowed off state
				if(!pHWHead->Interface){ 
					INB(SC_IER,pHWHead->pIER); 
				}
				else{
					INBSPI(SC_IER,pHWHead->pIER); 
				}
                byte = pHWHead->IER;
				if(!pHWHead->Interface){ 
					OUTB(SC_IER, (byte & ~SERIAL_IER_THR)); // disable TX interrupts while flowed off
				}
				else{
					OUTBSPI(SC_IER, (byte & ~SERIAL_IER_THR)); // disable TX interrupts while flowed off
				}

                // We could return a positive value here, which would
                // cause the MDD to periodically check the flow control
                // status.  However, we don't need to since we know that
                // the DCTS interrupt will cause the MDD to call us, and we
                // will subsequently fake a TX interrupt to the MDD, causing
                // him to call back into PutBytes.

                LeaveCriticalSection(&(pHWHead->RegCritSec));
                return;
            }
        }

        // Same thing applies for DSR
        if ( pHWHead->dcb.fOutxDsrFlow ) {
            // ReadMSR( pHWHead );
            // We don't need to explicitly read the MSR, since we always enable
            // IER_MS, which ensures that we will get an interrupt and read
            // the MSR whenever CTS, DSR, TERI, or DCD change.

            if (! (pHWHead->MSR & SERIAL_MSR_DSR) ) {
                
				pHWHead->DSRFlowOff = TRUE;  // Record flowed off state
				if(!pHWHead->Interface){ 
					OUTB(SC_IER, IER_NORMAL_INTS); // disable TX interrupts while flowed off
				}
				else{
					OUTBSPI(SC_IER, IER_NORMAL_INTS); // disable TX interrupts while flowed off
				}          
      
                // See the comment above above positive return codes.

                LeaveCriticalSection(&(pHWHead->RegCritSec));
                return;
            }
        }
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Do nothing.  The worst case is that this was a fluke,
        // and a TX Intr will come right back at us and we will
        // resume transmission.
    }
#pragma prefast(pop)

    LeaveCriticalSection(&(pHWHead->RegCritSec));


    EnterCriticalSection(&(pHWHead->TransmitCritSec));

    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
                DEBUGMSG (ZONE_WRITE | ZONE_THREAD,
                    (TEXT("SC_TxIntrEx - Write max of %d bytes\r\n"),
                    byteCount));

				if(pHWHead->FIFOMode){

					do{
						//FIFO Mode is enabled , Read the TXLVL register to check how many space is there
						if(!pHWHead->Interface){
							INB(SC_TXLVL,pHWHead->pTXLVL); 
						}
						else{
							INBSPI(SC_TXLVL,pHWHead->pTXLVL); 
							DEBUGMSG (ZONE_WRITE,(TEXT("FIFo:TXLVL = %x\r\n"),pHWHead->TXLVL));
						}
					}while(pHWHead->TXLVL >64);

					byteCount = pHWHead->TXLVL;
					if( NumberOfBytes > byteCount ){
						ucLen = byteCount;
					}
					else{
						ucLen = (UCHAR)NumberOfBytes;
						byteCount = ucLen; 
					}
				}
				if((pHWHead->FIFOMode) && (pHWHead->Interface == 1)){
						
					if(ucLen == 0){
						InterruptDone(pHWHead->dwSysIntr);
					}		
					else{//FIFO Enable and SPI interface
						SPI_FIFO_WRITE(pTxBuffer,&ucLen,(UCHAR)pHWHead->dwPortIndex);
						(*pBufflen) = ucLen;
						InterruptDone(pHWHead->dwSysIntr);

						DEBUGMSG (ZONE_WRITE,(TEXT("Byte Transmitted = %x\r\n"),ucLen));
					}
				}
				else{

					ReadLSR( pHWHead );
					if ( pHWHead->LSR & SERIAL_LSR_THRE ) {
						if ( pHWHead->IIR & SERIAL_IIR_FIFOS_ENABLED ){
							 byteCount = SERIAL_FIFO_DEPTH;
						}
						else{
							 byteCount = 1;
						}

						//Either FIFO is disable or Enabled but I2C interface
					   for( *pBufflen=0; NumberOfBytes && byteCount; NumberOfBytes--, byteCount-- ) {

							if(!pHWHead->Interface){ 
								OUTB(SC_THR, *pTxBuffer);
							}
							else{
								OUTBSPI(SC_THR, *pTxBuffer);
							}  
							++pTxBuffer;
						   (*pBufflen)++;
						}
				   		InterruptDone(pHWHead->dwSysIntr);
					}
                }
        
        // Enable xmit intr. We need to do this no matter what, 
        // since the MDD relies on one final interrupt before
        // returning to the application. 
        DEBUGMSG (ZONE_WRITE, (TEXT("SC_TxIntrEx: Enable INTR_TX.\r\n")));
			if(!pHWHead->Interface){ 
				OUTB(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR));
			}
			else{
				OUTBSPI(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR));
			}  
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Hmm, not sure what would cause this.  Lets just tell
        // the MDD to go away until we get another TX
        // interrupt.
    }
#pragma prefast(pop)

    LeaveCriticalSection(&(pHWHead->RegCritSec));

    LeaveCriticalSection(&(pHWHead->TransmitCritSec));
    DEBUGMSG (ZONE_WRITE, (TEXT("SC_TxIntrEx released CritSec %x.\r\n"),
                           &(pHWHead->TransmitCritSec)));

    DEBUGMSG (ZONE_WRITE, (TEXT("-SC_TxIntrEx - sent %d.\r\n"),
                           *pBufflen));
    return;

}

// @doc OEM
// @func ULONG | SC_LineIntr | This routine is called from the MDD
//   whenever INTR_LINE is returned by SC_GetInterruptType.
// 
// @rdesc None

VOID SC_LineIntr( PVOID pHead )
{
    PSER_SC16IS_INFO   pHWHead    = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_READ,
              (TEXT("+SC_LineIntr 0x%X\r\n"), pHead));
    ReadLSR( pHWHead );
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
        pHWHead->FCR |= SERIAL_FCR_RCVR_RESET; 
		if(!pHWHead->Interface){ 
			
			OUTB(SC_FCR, pHWHead->FCR ); // We have to reset Receive FIFO because it is error.
			INB(SC_LSR,pHWHead->pLSR); 
			pHWHead->FCR &= ~(SERIAL_FCR_RCVR_RESET);
		}
		else{
			OUTBSPI(SC_FCR, pHWHead->FCR); // We have to reset Receive FIFO because it is error.
			INBSPI(SC_LSR,pHWHead->pLSR); 
			pHWHead->FCR &= ~(SERIAL_FCR_RCVR_RESET);
		}
		while (pHWHead->LSR & SERIAL_LSR_DR ) {
			if(!pHWHead->Interface){ 
				INB(SC_LSR,pHWHead->pLSR); 
				INB(SC_RHR,pHWHead->pData); 
			}
			else{
				INBSPI(SC_LSR,pHWHead->pLSR); 
				INBSPI(SC_RHR,pHWHead->pData); 
			}
        }
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        ;
    };
#pragma prefast(pop)
    DEBUGMSG (ZONE_READ,
              (TEXT("-SC_LineIntr 0x%X\r\n"), pHead));
}

// @doc OEM
// @func ULONG | SC_OtherIntr | This routine is called from the MDD
//   whenever INTR_MODEM is returned by SC_GetInterruptType.
// 
// @rdesc None
VOID SC_OtherIntr( PVOID pHead )
{
    PSER_SC16IS_INFO   pHWHead    = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_READ,
              (TEXT("+SC_OtherIntr 0x%X\r\n"), pHead));

	// The interrupt value is valid
	switch ( pHWHead->IIR & SERIAL_IIR_INT_MASK ) {
	
	case SERIAL_IIR_MS :

		ReadMSR( pHWHead );

    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
        // If we are currently flowed off via CTS or DSR, then
        // we better signal the TX thread when one of them changes
        // so that TX can resume sending.
        if ( pHWHead->DSRFlowOff && (pHWHead->MSR & SERIAL_MSR_DSR) ) {
            DEBUGMSG (ZONE_WRITE|ZONE_FLOW,
                      (TEXT("PutBytes, flowed on via DSR\n") ) );
            pHWHead->DSRFlowOff = FALSE;

			if(!pHWHead->Interface){ 
				// DSR is set, so go ahead and resume sending
				OUTB(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR)); // Enable xmit intr.
			}
			else{
				// DSR is set, so go ahead and resume sending
				OUTBSPI(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR)); // Enable xmit intr.
			}  
            // Then simulate a TX intr to get things moving
            pHWHead->AddTXIntr = TRUE;
        }
        if ( pHWHead->CTSFlowOff && (pHWHead->MSR & SERIAL_MSR_CTS) ) {
            DEBUGMSG (ZONE_WRITE|ZONE_FLOW,
                      (TEXT("PutBytes, flowed on via CTS\n") ) );
            pHWHead->CTSFlowOff = FALSE;
			if(!pHWHead->Interface){ 
				// CTS is set, so go ahead and resume sending
				OUTB(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR)); // Enable xmit intr.
			}
			else{
				// CTS is set, so go ahead and resume sending
				OUTBSPI(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR)); // Enable xmit intr.
			}  
            // Then simulate a TX intr to get things moving
            pHWHead->AddTXIntr = TRUE;
        }
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Just exit
    }
#pragma prefast(pop)

    LeaveCriticalSection(&(pHWHead->RegCritSec));
        break;
    
	case SERIAL_IIR_XOFF : // We have received XOFF break character
		if(!pHWHead->Interface)
			INB(SC_IIR,pHWHead->pIIR);
		else
			INBSPI(SC_IIR,pHWHead->pIIR);
        break;
    
	case SERIAL_IIR_RTS_CTS : // LOW to HIGH transition in state of RTS/CTS bar 

        break;
    
	case SERIAL_IIR_CIP : //GPIO state has changed 
		if(!pHWHead->Interface)
			INB(SC_IOSTATE,pHWHead->pIOSTATE);
		else
			INBSPI(SC_IOSTATE,pHWHead->pIOSTATE);

        SetEvent(pHWHead->IoInterrupt); //Setting same named event, 
										// application is being informed for GPIO interrupt
        break;
	}

    DEBUGMSG (ZONE_READ,
              (TEXT("-SC_OtherIntr 0x%X\r\n"), pHead));
}

// @doc OEM
// @func ULONG | SC_OtherIntr | This routine is called from the MDD
//   whenever INTR_MODEM is returned by SC_GetInterruptType.
// 
// @rdesc None

VOID SC_ModemIntr( PVOID pHead )
{
    SC_OtherIntr(pHead);
}

// @doc OEM
// @func    ULONG | SC_GetStatus | This structure is called by the MDD
//   to retrieve the contents of a COMSTAT structure.
//
// @rdesc    The return is a ULONG, representing success (0) or failure (-1).

ULONG SC_GetStatus( PVOID    pHead, LPCOMSTAT lpStat )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
    ULONG      RetVal  = pHWHead->CommErrors;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_GetStatus 0x%X\r\n"), pHead));

    pHWHead->CommErrors = 0; // Clear old errors each time

    if ( lpStat ) {
        try {
            if (pHWHead->CTSFlowOff){
                pHWHead->Status.fCtsHold = 1;
			}
            else
                pHWHead->Status.fCtsHold = 0;

            if (pHWHead->DSRFlowOff){
                pHWHead->Status.fDsrHold = 1;
			}
            else
                pHWHead->Status.fDsrHold = 0;

            // NOTE - I think what they really want to know here is
            // the amount of data in the MDD buffer, not the amount
            // in the UART itself.  Just set to 0 for now since the
            // MDD doesn't take care of this.
            pHWHead->Status.cbInQue  = 0;
            pHWHead->Status.cbOutQue = 0;

            memcpy(lpStat, &(pHWHead->Status), sizeof(COMSTAT));
        }
        except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
                EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
            RetVal = (ULONG)-1;
        }        
    } else
        RetVal = (ULONG)-1;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_GetStatus 0x%X\r\n"), pHead));
    return(RetVal);
}

// @doc OEM
// @func    BOOL | SC_XmitComChar | Transmit a char immediately
// 
// @rdesc    TRUE if succesful

BOOL SC_XmitComChar( PVOID pHead,UCHAR ComChar )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_XmitComChar 0x%X\r\n"), pHead));

    // Get critical section, then transmit when buffer empties
    DEBUGMSG (ZONE_WRITE, (TEXT("XmitComChar wait for CritSec %x.\r\n"),
                           &(pHWHead->TransmitCritSec)));
    EnterCriticalSection(&(pHWHead->TransmitCritSec));
    DEBUGMSG (ZONE_WRITE, (TEXT("XmitComChar got CritSec %x.\r\n"),
                           &(pHWHead->TransmitCritSec)));
    try {
        while ( TRUE ) {  // We know THR will eventually empty
            EnterCriticalSection(&(pHWHead->RegCritSec));
            // Write the character if we can
           
                ReadLSR( pHWHead );

                if ( pHWHead->LSR & SERIAL_LSR_THRE ) {
					if(!pHWHead->Interface){ 
						// FIFO is empty, send this character
						OUTB(SC_THR, ComChar);
						// Make sure we release the register critical section
						OUTB(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR));
					}
					else{
						// FIFO is empty, send this character
						OUTBSPI(SC_THR, ComChar);
						// Make sure we release the register critical section
						OUTBSPI(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR));
					}  
                    LeaveCriticalSection(&(pHWHead->RegCritSec));
                   
                    DEBUGMSG (ZONE_WRITE, (TEXT("XmitComChar wrote x%X\r\n"),
                        ComChar));
                    break;
                }
           

            // If we couldn't write the data yet, then wait for a
            // TXINTR to come in and try it again.
			if(!pHWHead->Interface){ 
				// Enable xmit intr.
				OUTB(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR));
			}
			else{
				// Enable xmit intr.
				OUTBSPI(SC_IER, (IER_NORMAL_INTS | SERIAL_IER_THR));
			}  
            LeaveCriticalSection(&(pHWHead->RegCritSec));

            // Wait until the txintr has signaled.
            DEBUGMSG (ZONE_WRITE, (TEXT("XmitComChar WaitIntr x%X\r\n"),
                                   pHWHead->FlushDone));
            WaitForSingleObject(pHWHead->FlushDone, (ULONG)1000);
        }
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Make sure we release the register critical section
        LeaveCriticalSection(&(pHWHead->RegCritSec));
    }

    LeaveCriticalSection(&(pHWHead->TransmitCritSec));
    DEBUGMSG (ZONE_WRITE, (TEXT("XmitComChar released CritSec %x.\r\n"),
                           &(pHWHead->TransmitCritSec)));

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_XmitComChar 0x%X\r\n"), pHead));

    return(TRUE);
}

// @doc OEM
// @func    BOOL | SC_PowerOff | Perform powerdown sequence.
// 
// @rdesc    TRUE if succesful

BOOL SC_PowerOff( PVOID   pHead )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;

	// Current FCR is already saved in a shadow

	if(!pHWHead->Interface){ 
			// Current IER is not normally shadowed, save it
			INB(SC_IER,pHWHead->pIER); 
			// Current LCR is not normally shadowed, save it
			INB(SC_LCR,pHWHead->pLCR); 
			// Current MCR is not normally shadowed, save it
			INB(SC_MCR,pHWHead->pMCR); 
			// Current Scratch is not normally shadowed, save it
			INB(SC_Scratch,pHWHead->pScratch); 
	}
	else{
			// Current IER is not normally shadowed, save it
			INBSPI(SC_IER,pHWHead->pIER); 
			// Current LCR is not normally shadowed, save it
			INBSPI(SC_LCR,pHWHead->pLCR); 
			// Current MCR is not normally shadowed, save it
			INBSPI(SC_MCR,pHWHead->pMCR); 
			// Current Scratch is not normally shadowed, save it
			INBSPI(SC_Scratch,pHWHead->pScratch); 
	}
	if(!pHWHead->Interface){ 
		if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
			INB(SC_EFR,pHWHead->pEFR);	
			OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
			pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}

		INB(SC_IER,pHWHead->pIER);
		OUTB(SC_IER, (pHWHead->IER | SERIAL_IER_SLEEP_MODE));
		pHWHead->IER |= SERIAL_IER_SLEEP_MODE;
	}
	else{
		if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
			INBSPI(SC_EFR,pHWHead->pEFR);	
			OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
			pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}
	
		INBSPI(SC_IER,pHWHead->pIER);
		OUTBSPI(SC_IER, (pHWHead->IER | SERIAL_IER_SLEEP_MODE));
			pHWHead->IER |= SERIAL_IER_SLEEP_MODE;
	}
    pHWHead->PowerDown = TRUE;
	// And then disable our IR and 9 Pin interface
    SC_SetOutputMode( pHWHead, FALSE, FALSE );

	return TRUE;
   
}

// @doc OEM
// @func    BOOL | SC_PowerOn | Perform poweron sequence.
// 
// @rdesc    TRUE if succesful

BOOL SC_PowerOn( PVOID   pHead )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;

    if (pHWHead->PowerDown) {
        // Restore any registers that we need

		if(!pHWHead->Interface){ 
			INB(SC_IER,pHWHead->pIER);
			OUTB(SC_IER, (pHWHead->IER & ~SERIAL_IER_SLEEP_MODE));
			pHWHead->IER &= ~SERIAL_IER_SLEEP_MODE;
		}
		else{
			INBSPI(SC_IER,pHWHead->pIER);
			OUTBSPI(SC_IER, (pHWHead->IER & ~SERIAL_IER_SLEEP_MODE));
			pHWHead->IER &= ~SERIAL_IER_SLEEP_MODE;
		}

		if(!pHWHead->Interface){ 
			// In power handler context, so don't try to do a critical section
			if(pHWHead->FIFOMode){
				pHWHead->FCR |= SERIAL_FCR_ENABLE;				
				OUTB(SC_FCR, pHWHead->FCR);
			}
			OUTB(SC_FCR, pHWHead->FCR);
			OUTB(SC_IER, pHWHead->IER);
			OUTB(SC_LCR, pHWHead->LCR);
			OUTB(SC_MCR, pHWHead->MCR);
			OUTB(SC_Scratch, pHWHead->Scratch);
		}
		else{
			// In power handler context, so don't try to do a critical section
			if(pHWHead->FIFOMode){
				pHWHead->FCR |= SERIAL_FCR_ENABLE;				
				OUTBSPI(SC_FCR, pHWHead->FCR);
			}
			OUTBSPI(SC_FCR, pHWHead->FCR);
			OUTBSPI(SC_IER, pHWHead->IER);
			OUTBSPI(SC_LCR, pHWHead->LCR);
			OUTBSPI(SC_MCR, pHWHead->MCR);
			OUTBSPI(SC_Scratch, pHWHead->Scratch);
		}  
        pHWHead->PowerDown = FALSE;

        // And we didn't save the Divisor Reg, so set baud rate
        // But don't call SC_SetBaud, since it does DebugMsg.
        // Call our internal function instead.  Can't acquire
        // the RegCritSec, but shouldn't really need to since
        // we are in power context.
        SetBaudRate( pHWHead, pHWHead->dcb.BaudRate );
        pHWHead->bSuspendResume = TRUE;

		// And then enable our IR interface (if needed)
		SC_SetOutputMode( pHWHead, pHWHead->fIRMode, !pHWHead->fIRMode );

		return TRUE;
        
    }
	    return FALSE;
}

// @doc OEM
// @func    ULONG | SC_Reset | Perform any operations associated
//   with a device reset
// @rdesc    None.

VOID SC_Reset( PVOID   pHead )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_Reset 0x%X\r\n"), pHead));

    memset(&pHWHead->Status, 0, sizeof(COMSTAT));

    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
		if(!pHWHead->Interface){ 
			INB(SC_IOCTRL,pHWHead->pIOCTRL);
			OUTB(SC_IOCTRL, (pHWHead->IOCTRL  | SERIAL_IOCTL_UART_SOFT_RESET));
		}
		else{
			INBSPI(SC_IOCTRL,pHWHead->pIOCTRL);
			OUTBSPI(SC_IOCTRL, (pHWHead->IOCTRL  | SERIAL_IOCTL_UART_SOFT_RESET));
		}
		if(!pHWHead->Interface){ 
			OUTB(SC_IER, IER_NORMAL_INTS);
		}
		else{
			OUTBSPI(SC_IER, IER_NORMAL_INTS);
		}  
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Do nothing
    }
#pragma prefast(pop)

    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_Reset 0x%X\r\n"), pHead));
}

// @doc OEM
// @func    VOID | SC_GetModemStatus | Retrieves modem status.
//
// @rdesc    None.

VOID SC_GetModemStatus(PVOID   pHead, PULONG  pModemStatus )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
    UINT8 ubModemStatus;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_GetModemStatus 0x%X\r\n"), pHead));

    ReadMSR( pHWHead );
    ubModemStatus = pHWHead->MSR;

    if ( ubModemStatus & SERIAL_MSR_CTS )
        *pModemStatus |= MS_CTS_ON;

    if ( ubModemStatus & SERIAL_MSR_DSR )
        *pModemStatus |= MS_DSR_ON;

    if ( ubModemStatus & SERIAL_MSR_RI )
        *pModemStatus |= MS_RING_ON;

    if ( ubModemStatus & SERIAL_MSR_DCD )
        *pModemStatus |= MS_RLSD_ON;

    DEBUGMSG (ZONE_FUNCTION | ZONE_EVENTS,
              (TEXT("-SC_GetModemStatus 0x%X (stat x%X) \r\n"), pHead, *pModemStatus));
    return;
}

// @doc OEM
// @func	VOID | SC_GetCommProperties | Retrieves Comm Properties.
//
// @rdesc	None.

static VOID SC_GetCommProperties( PVOID	pHead, LPCOMMPROP pCommProp )
{
    PSER_SC16IS_INFO	pHWHead = (PSER_SC16IS_INFO)pHead;
    *pCommProp = pHWHead->CommProp;
    return;
}

// @doc OEM
// @func    VOID | SC_PurgeComm | Purge RX and/or TX
// @parm Action to take. 
// @rdesc    None.

VOID SC_PurgeComm( PVOID pHead, DWORD fdwAction )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_PurgeComm 0x%X\r\n"), pHead));

    EnterCriticalSection(&(pHWHead->RegCritSec));
#pragma prefast(disable: 322, "Recover gracefully from hardware failure")
    try {
#ifdef TODO
        // REVIEW THIS - I don't see how this could have terminated a pending read,
        // nor how RX interrupts would ever get turned back on.  I suspect that
        // RXABORT and TXABORT would both be better implemented in the MDD.
		if ( fdwAction & PURGE_RXABORT ){
			if(!pHWHead->Interface){ 
				OUTB(SC_IER, (IER_NORMAL_INTS & ~SERIAL_IER_RDA));
			}
			else{
				OUTBSPI(SC_IER, (IER_NORMAL_INTS & ~SERIAL_IER_RDA));
			}  
		}
#endif    
        if ( fdwAction & PURGE_TXCLEAR ) {
			if(!pHWHead->Interface){ 
				// Write the TX reset bit.  It is self clearing
				pHWHead->FCR |= SERIAL_FCR_TXMT_RESET;
				OUTB(SC_FCR, pHWHead->FCR);
				pHWHead->FCR &= ~(SERIAL_FCR_TXMT_RESET);
			}
			else{
				// Write the TX reset bit.  It is self clearing
				pHWHead->FCR |= SERIAL_FCR_TXMT_RESET;
				OUTBSPI(SC_FCR, pHWHead->FCR);
				pHWHead->FCR &= ~(SERIAL_FCR_TXMT_RESET);
			}
		}
        if ( fdwAction & PURGE_RXCLEAR ) {
			if(!pHWHead->Interface){ 
				// Write the RX reset bit.  It is self clearing
				pHWHead->FCR |= SERIAL_FCR_RCVR_RESET;
				OUTB(SC_FCR, pHWHead->FCR);
				pHWHead->FCR &= ~(SERIAL_FCR_RCVR_RESET);
			}
			else{
				// Write the TX reset bit.  It is self clearing
				pHWHead->FCR |= SERIAL_FCR_RCVR_RESET;
				OUTBSPI(SC_FCR, pHWHead->FCR);
				pHWHead->FCR &= ~(SERIAL_FCR_RCVR_RESET);
			}
	   }
	}
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        // Just exit
    }
#pragma prefast(pop)
    LeaveCriticalSection(&(pHWHead->RegCritSec));

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_PurgeComm 0x%X\r\n"), pHead));
    return;
}

// @doc OEM
// @func    BOOL | SC_SetDCB | Sets new values for DCB.  This
// routine gets a DCB from the MDD.  It must then compare
// this to the current DCB, and if any fields have changed take
// appropriate action.
// @rdesc    BOOL

BOOL SC_SetDCB( PVOID pHead,LPDCB lpDCB )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BYTE ByteOUT;
    BOOL bRet;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_SetDCB 0x%X\r\n"), pHead));

    bRet = TRUE;

    // If the device is open, scan for changes and do whatever
    // is needed for the changed fields.  if the device isn't
    // open yet, just save the DCB for later use by the open.
    if ( pHWHead->OpenCount ) {
        // Note, fparity just says whether we should check
        // receive parity.  And the 16550 won't let us NOT
        // check parity if we generate it.  So this field
        // has no effect on the hardware.

        if ( lpDCB->BaudRate != pHWHead->dcb.BaudRate ) {
            bRet = SC_SetBaudRate( pHWHead, lpDCB->BaudRate );
        }

        if ( bRet && (lpDCB->ByteSize != pHWHead->dcb.ByteSize )) {
            bRet = SC_SetByteSize( pHWHead, lpDCB->ByteSize );
        }

        if ( bRet && (lpDCB->Parity != pHWHead->dcb.Parity )) {
            bRet = SC_SetParity( pHWHead, lpDCB->Parity );
        }

        if ( bRet && (lpDCB->StopBits != pHWHead->dcb.StopBits )) {
            bRet = SC_SetStopBits( pHWHead, lpDCB->StopBits );
        }
		//Enable Software Flow Control	
		if ( lpDCB->fOutX || lpDCB->fInX )
		{
				// Disable Hardware Flow control				
				CLR_AUTO_RTS(pHWHead);
				CLR_AUTO_CTS(pHWHead);

			    // Set XON1 character
				ByteOUT = lpDCB->XonChar;
				Set_XON1(pHWHead,&ByteOUT);

				// Set XOFF1 character
				ByteOUT = lpDCB->XoffChar;
				Set_XOFF1(pHWHead,&ByteOUT);

				ByteOUT = (16/4 << 4) | 20/4  ; // Resume | Halt level
			    Set_TLR_FC(pHWHead,&ByteOUT);

				if ( lpDCB->fOutX){
						ByteOUT = 0x02;
						Set_Software_FC(pHWHead ,&ByteOUT);
				}
				if ( lpDCB->fInX){
						ByteOUT = 0x08;
						Set_Software_FC(pHWHead ,&ByteOUT);
				}
		}
		else {

			if((lpDCB->fRtsControl == RTS_CONTROL_HANDSHAKE)){

				ByteOUT = (16/4 << 4) | 20/4  ; // Resume | Halt level
			    Set_TLR_FC(pHWHead,&ByteOUT);

				//Enable Auto RTS Flow control mode
				Set_AUTO_RTS(pHWHead);
				//Enable Auto CTS Flow control mode
				Set_AUTO_CTS(pHWHead);
			}
			else{
				CLR_AUTO_RTS(pHWHead);
				CLR_AUTO_CTS(pHWHead);
			}
			//Disable software Flow control
			ByteOUT = 0x00;
			Set_Software_FC(pHWHead ,&ByteOUT);
		}

        // Don't worry about fOutxCtsFlow.  It is a flag which
        // will be examined every time we load the TX buffer.
        // No special action required here.
    }

    if (bRet) {
        // Now that we have done the right thing, store this DCB
        pHWHead->dcb = *lpDCB;
    }

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_SetDCB 0x%X\r\n"), pHead));

    return(bRet);
}

// @doc OEM
// @func    BOOL | SC_SetCommTimeouts | Sets new values for the
// CommTimeouts structure. routine gets a DCB from the MDD.  It
// must then compare this to the current DCB, and if any fields
// have changed take appropriate action.
// @rdesc    ULONG

ULONG SC_SetCommTimeouts( PVOID pHead,LPCOMMTIMEOUTS lpCommTimeouts )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
    ULONG retval = 0;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("+SC_SetCommTimeout 0x%X\r\n"), pHead));

    // OK, first check for any changes and act upon them
    if ( lpCommTimeouts->WriteTotalTimeoutMultiplier !=
         pHWHead->CommTimeouts.WriteTotalTimeoutMultiplier ) {
    }

    // Now that we have done the right thing, store this DCB
    pHWHead->CommTimeouts = *lpCommTimeouts;

    DEBUGMSG (ZONE_FUNCTION,
              (TEXT("-SC_SetCommTimeout 0x%X\r\n"), pHead));

    return(retval);
}

//  @doc OEM
//  @func    BOOL | SC_Ioctl | Device IO control routine.  
//  @parm DWORD | dwOpenData | value returned from COM_Open call
//  @parm DWORD | dwCode | io control code to be performed
//  @parm PBYTE | pBufIn | input data to the device
//  @parm DWORD | dwLenIn | number of bytes being passed in
//  @parm PBYTE | pBufOut | output data from the device
//  @parm DWORD | dwLenOut |maximum number of bytes to receive from device
//  @parm PDWORD | pdwActualOut | actual number of bytes received from device
//  @rdesc        Returns TRUE for success, FALSE for failure
//
//  @remark  The MDD will pass any unrecognized IOCTLs through to this function.
//
static BOOL SC_Ioctl(PVOID pHead, DWORD dwCode,PBYTE pBufIn,DWORD dwLenIn,
         PBYTE pBufOut,DWORD dwLenOut,PDWORD pdwActualOut)
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;

    DEBUGMSG (ZONE_FUNCTION, (TEXT("+SC_Ioctl 0x%X\r\n"), pHead));
	
    switch (dwCode) {

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_IODIR |
        //				Device IO control routine to set IO pin directions
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_IODIR
        //	@parm PBYTE  | pBufIn | Byte of data, 1 for output & 0 for input
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_IODIR :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_IODIR\r\n")));
        
        if ( NULL == pBufIn ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }
		if(!pHWHead->Interface){ 
			if (OUTB(SC_IODIR, (UCHAR)*pBufIn)) { //Physical
				pHWHead->IODIR = (UCHAR)*pBufIn; // shadowed
			} else {
				SetLastError (ERROR_TIMEOUT); // Failed to WRITE or SET
				RetVal = FALSE;
			}
		}else{
			if (OUTBSPI(SC_IODIR, (UCHAR)*pBufIn)) { //Physical
				pHWHead->IODIR = (UCHAR)*pBufIn; // shadowed
			} else {
				SetLastError (ERROR_TIMEOUT); // Failed to WRITE or SET
				RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_IOINTENA  |
        //				Device IO control routine to set IO pin interrupt on change
        //				Interrupt is not generated if GPIO are in Modem configurations
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_IOINTENA 
        //	@parm PBYTE  | pBufIn | Byte of data, 0 for disable and 1 for enable
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_IOINTENA  :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_IOINTENA \r\n")));

        if ( NULL == pBufIn ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }
		if(!pHWHead->Interface){ 
			if ( OUTB(SC_IOINTENA, (UCHAR)*pBufIn)) { //Physical 
				pHWHead->IOINTENA = (UCHAR)*pBufIn; // shadowed
			} else {
				SetLastError (ERROR_TIMEOUT); // Failed to WRITE or SET
				RetVal = FALSE;
			}
		}else{
			if ( OUTBSPI(SC_IOINTENA, (UCHAR)*pBufIn)) { //Physical 
				pHWHead->IOINTENA = (UCHAR)*pBufIn; // shadowed
			} else {
				SetLastError (ERROR_TIMEOUT); // Failed to WRITE or SET
				RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_READ_IOSTATE |
        //				Device IO control routine to read GPIO status
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_READ_IOSTATE
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Data read from GPIO line
        //	@parm DWORD  | dwLenOut | One
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
        //	@xref		<f IOCTL_SERIAL_WRITE_IOSTATE>
        //
    case IOCTL_SERIAL_READ_IOSTATE :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_READ_IOSTATE\r\n")));

		if ( (NULL == pBufOut) ||
             (NULL == pdwActualOut) ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }
		if(!pHWHead->Interface){ 
			if (INB(SC_IOSTATE,pHWHead->pIOSTATE)) { // shadowed
				*pBufOut= (BYTE)pHWHead->IOSTATE; 

			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			if (INBSPI(SC_IOSTATE,pHWHead->pIOSTATE)) { // shadowed
				*pBufOut= (BYTE)pHWHead->IOSTATE; 

			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}

        // Return the size
        *pdwActualOut = sizeof(BYTE);
        
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_WRITE_IOSTATE |
        //				Device IO control routine to set GPIO pins
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_WRITE_IOSTATE
        //	@parm PBYTE  | pBufIn | Byte to write on GPIO line
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
        //	@xref		<f IOCTL_SERIAL_READ_IOSTATE>
        //
    case IOCTL_SERIAL_WRITE_IOSTATE :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_WRITE_IOSTATE\r\n")));

        if ( NULL == pBufIn ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }
		if(!pHWHead->Interface){ 
			if ( OUTB(SC_IOSTATE, (UCHAR)*pBufIn)) {	//Physical
				pHWHead->IOSTATE = (UCHAR)*pBufIn; // shadowed            
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else
		{
			if ( OUTBSPI(SC_IOSTATE, (UCHAR)*pBufIn)) {	//Physical
				 pHWHead->IOSTATE = (UCHAR)*pBufIn; // shadowed            
			} else {
				 SetLastError (ERROR_TIMEOUT);
				 RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_IOLATCH |
        //				Device IO control routine to set IO pin controls latching of GPIO
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_IOLATCH
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
        //	@xref		<f IOCTL_SERIAL_CLR_IOLATCH>
        //
    case IOCTL_SERIAL_SET_IOLATCH :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_IOLATCH\r\n")));

		if(!pHWHead->Interface){ 
			INB(SC_IOCTRL,pHWHead->pIOCTRL);
			if ( OUTB(SC_IOCTRL,(pHWHead->IOCTRL | SERIAL_IOCTL_LATCH))) {	//Physical
				pHWHead->IOCTRL |= SERIAL_IOCTL_LATCH; 
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			INBSPI(SC_IOCTRL,pHWHead->pIOCTRL);
			if ( OUTBSPI(SC_IOCTRL,(pHWHead->IOCTRL | SERIAL_IOCTL_LATCH))) {	//Physical
				pHWHead->IOCTRL |= SERIAL_IOCTL_LATCH; 
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_CLR_IOLATCH |
        //				Device IO control routine to clear IO latch
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_CLR_IOLATCH
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
        //	@xref		<f IOCTL_SERIAL_SET_IOLATCH>
        //
    case IOCTL_SERIAL_CLR_IOLATCH :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_CLR_IOLATCH\r\n")));

		if(!pHWHead->Interface){ 
			INB(SC_IOCTRL,pHWHead->pIOCTRL);
			if ( OUTB(SC_IOCTRL, (pHWHead->IOCTRL & ~SERIAL_IOCTL_LATCH))) {	//Physical
				pHWHead->IOCTRL &= ~SERIAL_IOCTL_LATCH; // Virtual
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			INBSPI(SC_IOCTRL,pHWHead->pIOCTRL);
			if ( OUTBSPI(SC_IOCTRL, (pHWHead->IOCTRL & ~SERIAL_IOCTL_LATCH))) {	//Physical
				pHWHead->IOCTRL &= ~SERIAL_IOCTL_LATCH; // Virtual
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
	   }
       break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_MODEM_IO_PORTA |
        //				Device IO control routine to set GPIO pins as either Modem or IO
        //				For Channel 0 or Port A
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_MODEM_IO_PORTA
        //	@parm PBYTE  | pBufIn | Byte of data, ZERO for IO and NONZERO for modem
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_MODEM_IO_PORTA :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_MODEM_IO_PORTA\r\n")));

        if ( NULL == pBufIn ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }

		if(!pHWHead->Interface){ 
			INB(SC_IOCTRL,pHWHead->pIOCTRL);
			if(*pBufIn){	//Pins are configured as MODEM lines
				if ( OUTB(SC_IOCTRL, (pHWHead->IOCTRL  | SERIAL_IOCTL_MODEM_IO_PORTA))) {	//Physical
					pHWHead->IOCTRL |= SERIAL_IOCTL_MODEM_IO_PORTA; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			else {	//Pins are configured as IO lines
				if ( OUTB(SC_IOCTRL, (pHWHead->IOCTRL & ~SERIAL_IOCTL_MODEM_IO_PORTA))) {	//Physical
					pHWHead->IOCTRL &=  ~SERIAL_IOCTL_MODEM_IO_PORTA; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
		}
		else{
			INBSPI(SC_IOCTRL,pHWHead->pIOCTRL);
			if(*pBufIn){	//Pins are configured as MODEM lines
				if ( OUTBSPI(SC_IOCTRL, (pHWHead->IOCTRL  | SERIAL_IOCTL_MODEM_IO_PORTA))) {	//Physical
					pHWHead->IOCTRL |= SERIAL_IOCTL_MODEM_IO_PORTA; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			else {	//Pins are configured as IO lines
				if ( OUTBSPI(SC_IOCTRL, (pHWHead->IOCTRL & ~SERIAL_IOCTL_MODEM_IO_PORTA))) {	//Physical
					pHWHead->IOCTRL &=  ~SERIAL_IOCTL_MODEM_IO_PORTA; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_MODEM_IO_PORTB |
        //				Device IO control routine to set GPIO pins as either Modem or IO
        //				For Channel 1 or Port B
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_MODEM_IO_PORTB
        //	@parm PBYTE  | pBufIn | Byte of data, ZERO for IO and NONZERO for modem
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_MODEM_IO_PORTB :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_MODEM_IO_PORTB\r\n")));

        if ( NULL == pBufIn ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }

		if(!pHWHead->Interface){ 
			INB(SC_IOCTRL,pHWHead->pIOCTRL);
			if(*pBufIn){ //Pins are configured as MODEM lines
				if ( OUTB(SC_IOCTRL, (pHWHead->IOCTRL  | SERIAL_IOCTL_MODEM_IO_PORTB))) {	//Physical
					pHWHead->IOCTRL |= SERIAL_IOCTL_MODEM_IO_PORTB; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			else {	//Pins are configured as IO lines
				if ( OUTB(SC_IOCTRL, (pHWHead->IOCTRL & ~SERIAL_IOCTL_MODEM_IO_PORTB))) {	//Physical
					pHWHead->IOCTRL &=  ~SERIAL_IOCTL_MODEM_IO_PORTB; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
		}
		else{
			INBSPI(SC_IOCTRL,pHWHead->pIOCTRL);
			if(*pBufIn){ //Pins are configured as MODEM lines
				if ( OUTBSPI(SC_IOCTRL, (pHWHead->IOCTRL  | SERIAL_IOCTL_MODEM_IO_PORTB))) {	//Physical
					pHWHead->IOCTRL |= SERIAL_IOCTL_MODEM_IO_PORTB; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			else {	//Pins are configured as IO lines
				if ( OUTBSPI(SC_IOCTRL, (pHWHead->IOCTRL & ~SERIAL_IOCTL_MODEM_IO_PORTB))) {	//Physical
					pHWHead->IOCTRL &=  ~SERIAL_IOCTL_MODEM_IO_PORTB; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
		}

        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_TXITL |
        //				Device IO control routine to set Transmitter interrupt trigger level
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_TXITL
        //	@parm PBYTE  | pBufIn | Data byte value between 4-60,Sets with granularity of 4
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure 
        //
    case IOCTL_SERIAL_SET_TXITL :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_TXITL\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		if(*pBufIn < 4 || *pBufIn > 60){
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}

		 Set_TX_Trigger_level(pHWHead,pBufIn);

        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_RXITL |
        //				Device IO control routine to set receiver trigger level
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_RXITL
        //	@parm PBYTE  | pBufIn | Data byte value between 4-60,Sets with granularity of 4
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_RXITL :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_RXITL\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		if(*pBufIn < 4 || *pBufIn > 60){
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		Set_RX_Trigger_level(pHWHead,pBufIn);

        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_HFCTL / IOCTL_SERIAL_SET_SFCTL |
        //				Device IO control routine to set software flow control level
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_HFCTL / IOCTL_SERIAL_SET_SFCTL
        //	@parm PBYTE  | pBufIn | Data byte value between 0 - 60,Sets with granularity of 4
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure
        //
    case IOCTL_SERIAL_SET_HFCTL	:
    case IOCTL_SERIAL_SET_SFCTL :
		
        if ( NULL == pBufIn ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }

		RetVal = Set_TLR_FC(pHWHead, pBufIn);

		DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET _HFCTL / _SFCTL\r\n")));
         break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_RESET |
        //				Device IO control routine to reset UART chip
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_RESET
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_RESET :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_RESET\r\n")));

		if(!pHWHead->Interface){ 
			INB(SC_IOCTRL,pHWHead->pIOCTRL);
			OUTB(SC_IOCTRL, (pHWHead->IOCTRL  | SERIAL_IOCTL_UART_SOFT_RESET));
		}												
		else{
			INBSPI(SC_IOCTRL,pHWHead->pIOCTRL);
			if ( OUTBSPI(SC_IOCTRL, (pHWHead->IOCTRL  | SERIAL_IOCTL_UART_SOFT_RESET))) {
			} 
			else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_SLEEP |
        //				Device IO control routine to put UART device in to sleep mode
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_SLEEP
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_SLEEP :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_SLEEP\r\n")));

		if(!pHWHead->Interface){ 

			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INB(SC_LCR,pHWHead->pLCR);
				OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INB(SC_EFR,pHWHead->pEFR);	
				OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}

			INB(SC_IER,pHWHead->pIER);
			if (OUTB(SC_IER, (pHWHead->IER | SERIAL_IER_SLEEP_MODE))){
				pHWHead->IER |= SERIAL_IER_SLEEP_MODE;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INBSPI(SC_LCR,pHWHead->pLCR);
				OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INBSPI(SC_EFR,pHWHead->pEFR);	
				OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}
		
			INBSPI(SC_IER,pHWHead->pIER);
			if (OUTBSPI(SC_IER, (pHWHead->IER | SERIAL_IER_SLEEP_MODE))){
				pHWHead->IER |= SERIAL_IER_SLEEP_MODE;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_ENABLE_TX | 
        //				Device IO control routine to enable TRANSMITTER
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_ENABLE_TX
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_ENABLE_TX :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_ENABLE_TX\r\n")));
		if(!pHWHead->Interface){ 
			INB(SC_EFCR, pHWHead->pEFCR);
			if (OUTB(SC_EFCR, (pHWHead->EFCR & ~SERIAL_EFCR_TRANSMITTER_DISABLE))){
				pHWHead->EFCR &= ~SERIAL_EFCR_TRANSMITTER_DISABLE ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			INBSPI(SC_EFCR, pHWHead->pEFCR);
			if (OUTBSPI(SC_EFCR, (pHWHead->EFCR & ~SERIAL_EFCR_TRANSMITTER_DISABLE))){
				pHWHead->EFCR &= ~SERIAL_EFCR_TRANSMITTER_DISABLE ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}

        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_DISABLE_TX | 
        //				Device IO control routine to disable TRANSMITTER 
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_DISABLE_TX
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_DISABLE_TX :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_DISABLE_TX\r\n")));

		if(!pHWHead->Interface){ 
			INB(SC_EFCR, pHWHead->pEFCR);
			if (OUTB(SC_EFCR, (pHWHead->EFCR  | SERIAL_EFCR_TRANSMITTER_DISABLE))){
				pHWHead->EFCR |= SERIAL_EFCR_TRANSMITTER_DISABLE ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			INBSPI(SC_EFCR, pHWHead->pEFCR);
			if (OUTBSPI(SC_EFCR, (pHWHead->EFCR  | SERIAL_EFCR_TRANSMITTER_DISABLE))){
				pHWHead->EFCR |= SERIAL_EFCR_TRANSMITTER_DISABLE ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_ENABLE_RX | 
        //				Device IO control routine to enable RECEIVER 
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_ENABLE_RX
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_ENABLE_RX :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_ENABLE_RX\r\n")));

		if(!pHWHead->Interface){ 
			INB(SC_EFCR, pHWHead->pEFCR);
			if (OUTB(SC_EFCR, (pHWHead->EFCR & ~SERIAL_EFCR_RECEIVER_DISABLE))){
				pHWHead->EFCR &= ~SERIAL_EFCR_RECEIVER_DISABLE ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			INBSPI(SC_EFCR, pHWHead->pEFCR);
			if (OUTBSPI(SC_EFCR, (pHWHead->EFCR & ~SERIAL_EFCR_RECEIVER_DISABLE))){
				pHWHead->EFCR &= ~SERIAL_EFCR_RECEIVER_DISABLE ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}

        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_DISABLE_RX | 
        //				Device IO control routine to disable RECEIVER
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_DISABLE_RX
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_DISABLE_RX :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_DISABLE_RX\r\n")));
		if(!pHWHead->Interface){ 
			INB(SC_EFCR, pHWHead->pEFCR);
			if (OUTB(SC_EFCR, (pHWHead->EFCR | SERIAL_EFCR_RECEIVER_DISABLE))){
				pHWHead->EFCR |= SERIAL_EFCR_RECEIVER_DISABLE ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			INBSPI(SC_EFCR, pHWHead->pEFCR);
			if (OUTBSPI(SC_EFCR, (pHWHead->EFCR | SERIAL_EFCR_RECEIVER_DISABLE))){
				pHWHead->EFCR |= SERIAL_EFCR_RECEIVER_DISABLE ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
        break;
        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_IRDAMODE_SLOW_OR_FAST | 
        //				Device IO control routine to set IRDA mode FAST
        //				IrDA SIR, 1/4 pulse ratio, data rate up to 1.152 Mbit/s
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_IRDAMODE_FAST
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_IRDAMODE_FAST :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_IRDAMODE_FAST\r\n")));

		if(!pHWHead->ChipID){
			// FAST MODE is not supported in SC16IS572 Chip.
			SetLastError(ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			break;
		}

		if(!pHWHead->Interface){ 
			INB(SC_EFCR, pHWHead->pEFCR);
			if (OUTB(SC_EFCR, (pHWHead->EFCR | SERIAL_EFCR_IRDA_SLOW_FAST))){
				pHWHead->EFCR |= SERIAL_EFCR_IRDA_SLOW_FAST ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			INBSPI(SC_EFCR, pHWHead->pEFCR);
			if (OUTBSPI(SC_EFCR, (pHWHead->EFCR | SERIAL_EFCR_IRDA_SLOW_FAST))){
				pHWHead->EFCR |= SERIAL_EFCR_IRDA_SLOW_FAST ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
        break;
        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_IRDAMODE_SLOW_OR_FAST | 
        //				Device IO control routine to set IRDA mode FAST
        //				IrDA SIR, 1/4 pulse ratio, data rate up to 1.152 Mbit/s
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_IRDAMODE_FAST
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_IRDAMODE_SLOW :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_IRDAMODE_SLOW\r\n")));
		if(!pHWHead->Interface){ 
			INB(SC_EFCR, pHWHead->pEFCR);
			if (OUTB(SC_EFCR, (pHWHead->EFCR & ~SERIAL_EFCR_IRDA_SLOW_FAST))){
				pHWHead->EFCR &= ~SERIAL_EFCR_IRDA_SLOW_FAST ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			INBSPI(SC_EFCR, pHWHead->pEFCR);
			if (OUTBSPI(SC_EFCR, (pHWHead->EFCR & ~SERIAL_EFCR_IRDA_SLOW_FAST))){
				pHWHead->EFCR &= ~SERIAL_EFCR_IRDA_SLOW_FAST ;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_XONANY | 
        //				Device IO control routine to enable XON any function
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_XONANY
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_XONANY :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_XONANY\r\n")));
		if(!pHWHead->Interface){ 
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INB(SC_LCR,pHWHead->pLCR);
				OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INB(SC_EFR,pHWHead->pEFR);	
				OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}

			INB(SC_MCR,pHWHead->pMCR);
			if (OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_XONANY_ENABLE))){
				pHWHead->MCR |= SERIAL_MCR_XONANY_ENABLE;

			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}else {
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INBSPI(SC_LCR,pHWHead->pLCR);
				OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INBSPI(SC_EFR,pHWHead->pEFR);	
				OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}

			INBSPI(SC_MCR,pHWHead->pMCR);
			if (OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_XONANY_ENABLE))){
				pHWHead->MCR |= SERIAL_MCR_XONANY_ENABLE;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_CLR_XONANY | 
        //				Device IO control routine to disable XON any function.
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_CLR_XONANY
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_CLR_XONANY :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_CLR_XONANY\r\n")));

		if(!pHWHead->Interface){ 
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INB(SC_LCR,pHWHead->pLCR);
				OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INB(SC_EFR,pHWHead->pEFR);	
				OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}
			INB(SC_MCR,pHWHead->pMCR);
			if (OUTB(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_XONANY_ENABLE))){
				pHWHead->MCR &= ~SERIAL_MCR_XONANY_ENABLE;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INBSPI(SC_LCR,pHWHead->pLCR);
				OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INBSPI(SC_EFR,pHWHead->pEFR);	
				OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}

			INBSPI(SC_MCR,pHWHead->pMCR);
			if (OUTBSPI(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_XONANY_ENABLE))){
				pHWHead->MCR &= ~SERIAL_MCR_XONANY_ENABLE;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}

        break;

        // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_XON1 | 
        //				Device IO control routine to set XON1 resume character
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_XON1
        //	@parm PBYTE  | pBufIn | One data byte for break character
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_XON1 :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_XON1\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		RetVal = Set_XON1(pHWHead,pBufIn);

		break;
        
		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_XON2 | 
        //				Device IO control routine to set Xon2 resume character
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_XON2 break character
        //	@parm PBYTE  | pBufIn | One data byte for break character
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_XON2 :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_XON2\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}

		if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access Xon2 
			
			if (OUTB(SC_XON2, *pBufIn)){
				pHWHead->XON2 = *pBufIn;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access Xon2 
			
			if (OUTBSPI(SC_XON2, *pBufIn)){
				pHWHead->XON2 = *pBufIn;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}      
        break;        
		
		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_XOFF1 | 
        //				Device IO control routine to set XOFF1 break character
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_XOFF1
        //	@parm PBYTE  | pBufIn | One data byte for break character
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_XOFF1 :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_XOFF1\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}

		RetVal = Set_XOFF1(pHWHead,pBufIn);
			
		break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_XOFF2 | 
        //				Device IO control routine to set XOFF2 break character
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_XOFF21
        //	@parm PBYTE  | pBufIn | One data byte for break character
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_XOFF2 :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_XOFF2\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}

		if(!pHWHead->Interface){ 

			INB(SC_MCR,pHWHead->pMCR);
			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE){
				OUTB(SC_MCR,pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE);
			}
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access Xoff2 
			
			if (OUTB(SC_XOFF2, *pBufIn)){
				pHWHead->XOFF2 = *pBufIn;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value

			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE){
				OUTB(SC_MCR,pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE);
			}
		}
		else{
			INBSPI(SC_MCR,pHWHead->pMCR);
			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE){
				OUTBSPI(SC_MCR,pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE);
			}

			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access Xoff2 
			
			if (OUTBSPI(SC_XOFF2, *pBufIn)){
				pHWHead->XOFF2 = *pBufIn;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value

			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE){
				OUTBSPI(SC_MCR,pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE);
			}
		}      
        break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_AUTORTS | 
        //				Device IO control routine to set AUTO RTS control feature
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_AUTORTS
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_AUTORTS :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_AUTORTS\r\n")));

		RetVal = Set_AUTO_RTS(pHWHead);
        break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_AUTOCTS | 
        //				Device IO control routine to set AUTO CTS control feature
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_AUTOCTS
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_AUTOCTS :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_AUTOCTS\r\n")));

		RetVal = Set_AUTO_CTS(pHWHead);

       break;
		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_CLR_AUTORTS | 
        //				Device IO control routine to clear AUTO RTS control feature
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_AUTORTS
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_CLR_AUTORTS :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_CLR_AUTORTS\r\n")));

		RetVal = CLR_AUTO_RTS(pHWHead);

        break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_CLR_AUTOCTS | 
        //				Device IO control routine to clear AUTO CTS control feature
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_CLR_AUTOCTS
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_CLR_AUTOCTS :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_CLR_AUTOCTS\r\n")));

		RetVal = CLR_AUTO_CTS(pHWHead);

       break;

  	    // ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SPECIAL_CHAR | 
        //				Device IO control routine to set AUTO RTS control feature
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SPECIAL_CHAR
        //	@parm PBYTE  | pBufIn | Non-Zero to set Zero to clear flag and interrupt
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SPECIAL_CHAR :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SPECIAL_CHAR\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		
		if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

			INB(SC_EFR,pHWHead->pEFR);
			if(*pBufIn){
				if (OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_SPECIAL_CHARACTER_DETECT))){
					pHWHead->EFR |= SERIAL_EFR_SPECIAL_CHARACTER_DETECT;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}else{
				if (OUTB(SC_EFR,(pHWHead->EFR & ~SERIAL_EFR_SPECIAL_CHARACTER_DETECT))){
					pHWHead->EFR &= ~SERIAL_EFR_SPECIAL_CHARACTER_DETECT;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
			INB(SC_IER,pHWHead->pIER);
			if(*pBufIn){
				OUTB(SC_IER,pHWHead->IER |SERIAL_IER_XOFF_ENABLE); // Enable interrupt 
				pHWHead->IER |= SERIAL_IER_XOFF_ENABLE;
			}else{
				OUTB(SC_IER,pHWHead->IER & ~SERIAL_IER_XOFF_ENABLE); // Disable interrupt 
				pHWHead->IER &= ~SERIAL_IER_XOFF_ENABLE;
			}
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

			INBSPI(SC_EFR,pHWHead->pEFR);
			if(*pBufIn){
				if (OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_SPECIAL_CHARACTER_DETECT))){
					pHWHead->EFR |= SERIAL_EFR_SPECIAL_CHARACTER_DETECT;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}else{
				if (OUTBSPI(SC_EFR,(pHWHead->EFR & ~SERIAL_EFR_SPECIAL_CHARACTER_DETECT))){
					pHWHead->EFR &= ~SERIAL_EFR_SPECIAL_CHARACTER_DETECT;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
			INBSPI(SC_IER,pHWHead->pIER);
			if(*pBufIn){
				OUTBSPI(SC_IER,pHWHead->IER |SERIAL_IER_XOFF_ENABLE); // Enable interrupt 
				pHWHead->IER |= SERIAL_IER_XOFF_ENABLE;
			}else{
				OUTBSPI(SC_IER,pHWHead->IER & ~SERIAL_IER_XOFF_ENABLE); // Disable interrupt 
				pHWHead->IER &= ~SERIAL_IER_XOFF_ENABLE;
			}
		}      
        break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_SFCTRL_MODE | 
        //				Device IO control routine to set mode of software flow control 
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_SFCTRL_MODE
        //	@parm PBYTE  | pBufIn | One data byte lower nibble considered only 
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_SET_SFCTRL_MODE :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_SFCTRL_MODE\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		RetVal = Set_Software_FC(pHWHead , pBufIn);

       break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_FCR_TXTL | 
        //				Device IO control routine to set Transmission trigger level in FCR
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_FCR_TXTL
        //	@parm PBYTE  | pBufIn | One data byte only 8,16,32,56 values valid
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //  Note : This bits are automatically ignored by chip if trigger level set in 
	    //			TLR register.
    case IOCTL_SERIAL_SET_FCR_TXTL :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_FCR_TXTL\r\n")));
		
		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		
		if(*pBufIn == 8 || *pBufIn == 16 || *pBufIn == 32 || *pBufIn == 56){
			if(*pBufIn == 56)
				*pBufIn = 3 << SERIAL_FCR_PLACE_TX_BITS;	// Value 8,16,32 and 56 converted to
			else					// 0,1,2 and 3 respectively and stored in bit no.5 and 4
				*pBufIn =  (*pBufIn/8 - 1) << SERIAL_FCR_PLACE_TX_BITS; 
			if(!pHWHead->Interface){ 
				if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
					INB(SC_LCR,pHWHead->pLCR);
					OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
					INB(SC_EFR,pHWHead->pEFR);	
					OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
					pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
					OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
				}
				INB(SC_FCR,pHWHead->pFCR);
				pHWHead->FCR &=  0xFC << SERIAL_FCR_PLACE_TX_BITS; // Clear bit no. 5 and 4
				if (OUTB(SC_FCR, (pHWHead->FCR | *pBufIn ))){
					pHWHead->FCR |= *pBufIn;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			else{
				if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
					INBSPI(SC_LCR,pHWHead->pLCR);
					OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
					INBSPI(SC_EFR,pHWHead->pEFR);	
					OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
					pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
					OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
				}
				INBSPI(SC_FCR,pHWHead->pFCR);
				pHWHead->FCR &=  0xFC << SERIAL_FCR_PLACE_TX_BITS; // Clear bit no. 5 and 4
				if (OUTBSPI(SC_FCR, (pHWHead->FCR | *pBufIn ))){
					pHWHead->FCR |= *pBufIn;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
		}
		else {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
		}

       break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_SET_FCR_RXTL | 
        //				Device IO control routine to set Receive trigger level in FCR 
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_SET_FCR_RXTL
        //	@parm PBYTE  | pBufIn | One data byte only 8,16,32,56 values valid
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //  Note : This bits are automatically ignored by chip if trigger level set in 
	    //			TLR register.
    case IOCTL_SERIAL_SET_FCR_RXTL :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_SET_FCR_RXTL\r\n")));
		
		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		
		if(*pBufIn == 8 || *pBufIn == 16 || *pBufIn == 32 || *pBufIn == 56){
			if(*pBufIn == 56)
				*pBufIn = 3 << SERIAL_FCR_PLACE_RX_BITS;	// Value 8,16,32 and 56 converted to
			else					// 0,1,2 and 3 respectively and stored in bit no.7 and 6
				*pBufIn =  (*pBufIn/8 - 1) << SERIAL_FCR_PLACE_RX_BITS; 
			if(!pHWHead->Interface){ 
				if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
					INB(SC_LCR,pHWHead->pLCR);
					OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
					INB(SC_EFR,pHWHead->pEFR);	
					OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
					pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
					OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
				}
				INB(SC_FCR,pHWHead->pFCR);
				pHWHead->FCR &=  0xFC << SERIAL_FCR_PLACE_RX_BITS; // Clear bit no. 7 and 6
				if (OUTB(SC_FCR, (pHWHead->FCR | *pBufIn ))){
					pHWHead->FCR |= *pBufIn;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			else{
				if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
					INBSPI(SC_LCR,pHWHead->pLCR);
					OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
					INBSPI(SC_EFR,pHWHead->pEFR);	
					OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
					pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
					OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
				}
				INBSPI(SC_FCR,pHWHead->pFCR);
				pHWHead->FCR &=  0xFC << SERIAL_FCR_PLACE_RX_BITS; // Clear bit no. 7 and 6
				if (OUTBSPI(SC_FCR, (pHWHead->FCR | *pBufIn ))){
					pHWHead->FCR |= *pBufIn;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
		}
		else {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
		}

        break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_MODEM_LOOPBACK |
        //				Device IO control routine to set LOOPBACK mode
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_MODEM_LOOPBACK
        //	@parm PBYTE  | pBufIn | Byte of data, ZERO for normal mode and NONZERO for loopback mode
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_MODEM_LOOPBACK :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_MODEM_LOOPBACK\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}
		
		if(!pHWHead->Interface){ 
			INB(SC_MCR,pHWHead->pMCR);
			if(*pBufIn){ //Loop back mode initialized
				if ( OUTB(SC_MCR, (pHWHead->MCR  | SERIAL_MCR_LOOP))) {	//Physical
					pHWHead->MCR |= SERIAL_MCR_LOOP; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			else {	//Normal mode initialized
				if ( OUTB(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_LOOP))) {	//Physical
					pHWHead->MCR &=  ~SERIAL_MCR_LOOP; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
		}else{
			INBSPI(SC_MCR,pHWHead->pMCR);
			if(*pBufIn){ //Loop back mode initialized
				if ( OUTBSPI(SC_MCR, (pHWHead->MCR  | SERIAL_MCR_LOOP))) {	//Physical
					pHWHead->MCR |= SERIAL_MCR_LOOP; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
			else {	//Normal mode initialized
				if ( OUTBSPI(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_LOOP))) {	//Physical
					pHWHead->MCR &=  ~SERIAL_MCR_LOOP; // Virtual
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
			}
		}			
	    break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_CTS_RTS_INT_ENABLE |
        //				Device IO control routine to enable CTS and RTS interrupt
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_CTS_RTS_INT_ENABLE
        //	@parm PBYTE  | pBufIn | Byte of data, Non Zero Enable interrupts, Zero disable interrupts
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Ignored
        //	@parm DWORD  | dwLenOut | Ignored
        //	@parm PDWORD | pdwActualOut | Ignored
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_CTS_RTS_INT_ENABLE :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_CTS_RTS_INT_ENABLE\r\n")));

		if ( NULL == pBufIn ) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}

		if(!pHWHead->Interface){ 
			INB(SC_IER,pHWHead->pIER);
			if(*pBufIn){
				OUTB(SC_IER,pHWHead->IER | SERIAL_IER_RTS_ENABLE | SERIAL_IER_CTS_ENABLE ); // Enable interrupt 
				pHWHead->IER |= SERIAL_IER_RTS_ENABLE | SERIAL_IER_CTS_ENABLE;
			}else{
				OUTB(SC_IER,pHWHead->IER & ~SERIAL_IER_RTS_ENABLE & ~SERIAL_IER_CTS_ENABLE); // Enable interrupt 
				pHWHead->IER &= ~SERIAL_IER_RTS_ENABLE & ~SERIAL_IER_CTS_ENABLE;
			}
		}else{
			INBSPI(SC_IER,pHWHead->pIER );
			if(*pBufIn){
				OUTBSPI(SC_IER,pHWHead->IER | SERIAL_IER_RTS_ENABLE | SERIAL_IER_CTS_ENABLE); // Enable interrupt 
				pHWHead->IER |= SERIAL_IER_RTS_ENABLE | SERIAL_IER_CTS_ENABLE;
			}else{
				OUTBSPI(SC_IER,pHWHead->IER &  ~SERIAL_IER_RTS_ENABLE & ~SERIAL_IER_CTS_ENABLE); // Enable interrupt 
				pHWHead->IER &=  ~SERIAL_IER_RTS_ENABLE & ~SERIAL_IER_CTS_ENABLE;
			}
		}
		break;
		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_GET_DUMP_REGISTER |
        //				Device IO control routine to get the dump of all SC16IS7xx register dump
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_GET_DUMP_REGISTER
        //	@parm PBYTE  | pBufIn | Ignored
        //	@parm DWORD  | dwLenIn | Ignored
        //	@parm PBYTE  | pBufOut | Returned Data 
        //	@parm DWORD  | dwLenOut | 
        //	@parm PDWORD | pdwActualOut | 
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        //
    case IOCTL_SERIAL_GET_DUMP_REGISTER :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_GET_DUMP_REGISTER\r\n")));

       if ( (dwLenOut < 19) || (NULL == pBufOut) ||
             (NULL == pdwActualOut) ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }

		if(!pHWHead->Interface){ 
			//Read IER register
			INB(SC_IER,pBufOut++);

			//Read IIR register
			INB(SC_IIR,pBufOut++);

			//Read LCR register
			INB(SC_LCR,pBufOut++);

			//Read MCR register
			INB(SC_MCR,pBufOut++);

			//Read LSR register
			INB(SC_LSR,pBufOut++);

			//Read MSR register
			INB(SC_MSR,pBufOut++);

			//Read SPR register
			INB(SC_Scratch,pBufOut++);

			//Read TXLVL register
			INB(SC_TXLVL,pBufOut++); 

			//Read RXLVL register
			INB(SC_RXLVL,pBufOut++); 

			//Read IOCTRL register
			INB(SC_IOCTRL,pBufOut++);

			//Read IODIR register
			INB(SC_IODIR,pBufOut++);

			//Read IOSTATE register
			INB(SC_IOSTATE,pBufOut++);

			//Read IOINTENA register
			INB(SC_IOINTENA,pBufOut++);

			//Read EFCR register
			INB(SC_EFCR,pBufOut++);
			
			//Read EFR -- Make sure LCR = 0xBF to access it
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
			INB(SC_EFR,pBufOut++);	

			//Read XON1
			INB(SC_XON1,pBufOut++);

			//Read XON2
			INB(SC_XON2,pBufOut++);

			//Read XOFF1
			INB(SC_XOFF1,pBufOut++);

			//Read XOFF2
			INB(SC_XOFF2,pBufOut++);

			//Set LCR as original value
			OUTB(SC_LCR, pHWHead->LCR); 
		}
		else{
			//Read IER register
			INBSPI(SC_IER,pBufOut++);

			//Read IIR register
			INBSPI(SC_IIR,pBufOut++);

			//Read LCR register
			INBSPI(SC_LCR,pBufOut++);

			//Read MCR register
			INBSPI(SC_MCR,pBufOut++);

			//Read LSR register
			INBSPI(SC_LSR,pBufOut++);

			//Read MSR register
			INBSPI(SC_MSR,pBufOut++);

			//Read SPR register
			INBSPI(SC_Scratch,pBufOut++);

			//Read TXLVL register
			INBSPI(SC_TXLVL,pBufOut++); 

			//Read RXLVL register
			INBSPI(SC_RXLVL,pBufOut++); 

			//Read IOCTRL register
			INBSPI(SC_IOCTRL,pBufOut++);

			//Read IODIR register
			INBSPI(SC_IODIR,pBufOut++);

			//Read IOSTATE register
			INBSPI(SC_IOSTATE,pBufOut++);

			//Read IOINTENA register
			INBSPI(SC_IOINTENA,pBufOut++);

			//Read EFCR register
			INBSPI(SC_EFCR,pBufOut++);
			
			//Read EFR -- Make sure LCR = 0xBF to access it
			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
			INBSPI(SC_EFR,pBufOut++);	

			//Read XON1
			INBSPI(SC_XON1,pBufOut++);

			//Read XON2
			INBSPI(SC_XON2,pBufOut++);

			//Read XOFF1
			INBSPI(SC_XOFF1,pBufOut++);

			//Read XOFF2
			INBSPI(SC_XOFF2,pBufOut++);

			//Set LCR as original value
			OUTBSPI(SC_LCR, pHWHead->LCR); 

		}
		*pdwActualOut = 19;
		break;

		// ****************************************************************
        //	
        //	@func	BOOL | IOCTL_SERIAL_GET_SINGLE_REGISTER |
        //				Device IO control routine to get the dump of all SC16IS7xx register dump
        //
        //	@parm DWORD  | dwCode | IOCTL_SERIAL_GET_SINGLE_REGISTER
        //	@parm PBYTE  | pBufIn | Register value to be read
        //	@parm DWORD  | dwLenIn | One
        //	@parm PBYTE  | pBufOut | Returned Data 
        //	@parm DWORD  | dwLenOut | One
        //	@parm PDWORD | pdwActualOut | One 
        //
        //	@rdesc		Returns TRUE for success, FALSE for failure (and
        //				sets thread error code)
        // We consider all registers in sequence so numbers derived by sequentially
		// counting them. 0-7 for RHR to SPR, 8-TCR, 9-TLR, 10-17 TXLVL-EFCR 18-DLL, 19-DLH
		// 20-EFR 21-INVALID & 22-25 XOn1-Xoff2
    case IOCTL_SERIAL_GET_SINGLE_REGISTER :
        DEBUGMSG (ZONE_IOCTL, (TEXT(" IOCTL_SERIAL_GET_SINGLE_REGISTER\r\n")));

   		if ( NULL == pBufIn || *pBufIn == 21 || *pBufIn > 25) {
			SetLastError (ERROR_INVALID_PARAMETER);
			RetVal = FALSE;
			DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
			break;
		}

		if ((NULL == pBufOut) || (NULL == pdwActualOut) ) {
            SetLastError (ERROR_INVALID_PARAMETER);
            RetVal = FALSE;
            DEBUGMSG (ZONE_IOCTL, (TEXT(" Invalid parameter\r\n")));
            break;
        }
		// Pass value	0-7 for RHR to SPR
		//				8-17 for TCR to EFCR
		//				18-25 for DLL to Xoff2
		//       value 21 is invalid   
		switch(*pBufIn){

			case SC_RHR: // General register set
			case SC_IER:
			case SC_IIR:
			case SC_LCR:
			case SC_MCR:
			case SC_LSR:
				if(!pHWHead->Interface){ 
					INB(*pBufIn,pBufOut);
				}
				else{
					INBSPI(*pBufIn,pBufOut);
				}
				break;

			case SC_MSR:
			case SC_Scratch:
				if(!pHWHead->Interface){ 
					if((pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTB(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE)); // Disable TCR/TLR
					INB(*pBufIn ,pBufOut);
					if((pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); // Enable it
				}
				else{
					if((pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTBSPI(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE)); // Disable TCR/TLR
					INBSPI(*pBufIn ,pBufOut);
					if((pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); // Enable it
				}
				break;
			
			case SC_TCR+2:
			case SC_TLR+2:
				if(!pHWHead->Interface){ 
					if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)) {
						INB(SC_MCR,pHWHead->pMCR);	// Check for TCR/TLR enable
						OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); 
					}
					INB(*pBufIn - 2,pBufOut);
					if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTB(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE)); // Disable it
				}
				else{
					if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)) {
						INBSPI(SC_MCR,pHWHead->pMCR);	// Check for TCR/TLR enable
						OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); 
					}
					INBSPI(*pBufIn - 2,pBufOut);
					if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTBSPI(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE)); // Disable it
				}
				break;

			case SC_TXLVL+2:
			case SC_RXLVL+2:
			case SC_IODIR+2:
			case SC_IOSTATE+2:
			case SC_IOINTENA+2:
			case SC_IOCTRL+2:
			case SC_EFCR+2:
				if(!pHWHead->Interface){ 
					INB(*pBufIn-2,pBufOut);
				}
				else{
					INBSPI(*pBufIn-2,pBufOut);
				}
				break;
			case SC_DLL+18: // Special register set
			case SC_DLH+18: // LCR[7]=1 and != 0xBF to access
				if(!pHWHead->Interface){ 
					INB(SC_LCR,pHWHead->pLCR);
					OUTB(SC_LCR,(pHWHead->LCR | SERIAL_LCR_DLAB));
					INB(*pBufIn - 18,pBufOut);
					OUTB(SC_LCR,pHWHead->LCR);
				}
				else{
					INBSPI(SC_LCR,pHWHead->pLCR);
					OUTBSPI(SC_LCR,(pHWHead->LCR | SERIAL_LCR_DLAB));
					INBSPI(*pBufIn - 18,pBufOut);
					OUTBSPI(SC_LCR,pHWHead->LCR);
				}
				break;

			case SC_EFR+18 : // Enhanced register set
			case SC_XON1+18 :
			case SC_XON2+18 :
				if(!pHWHead->Interface){ 
					INB(SC_LCR,pHWHead->pLCR);
					OUTB(SC_LCR,SERIAL_LCR_ENHANCE_ACCESS);
					INB(*pBufIn - 18,pBufOut);
					OUTB(SC_LCR,pHWHead->LCR);
				}
				else{
					INBSPI(SC_LCR,pHWHead->pLCR);
					OUTBSPI(SC_LCR,SERIAL_LCR_ENHANCE_ACCESS);
					INBSPI(*pBufIn - 18,pBufOut);
					OUTBSPI(SC_LCR,pHWHead->LCR);
				}
				break;

			case SC_XOFF1+18 :
			case SC_XOFF2+18 :
				if(!pHWHead->Interface){ 
					if((pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTB(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE)); // Disable TCR/TLR
					INB(SC_LCR,pHWHead->pLCR);
					OUTB(SC_LCR,SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF to access Xoff1 & 2
					INB(*pBufIn - 18,pBufOut);
					OUTB(SC_LCR,pHWHead->LCR);
					if((pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); // Enable it
				}
				else{
					if((pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTBSPI(SC_MCR, (pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE)); // Disable TCR/TLR
					INBSPI(SC_LCR,pHWHead->pLCR);
					OUTBSPI(SC_LCR,SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF to access Xoff1 & 2
					INBSPI(*pBufIn - 18,pBufOut);
					OUTBSPI(SC_LCR,pHWHead->LCR);
					if((pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE))
						OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); // Enable it
				}
				break;
			default:
				break;

		}
		*pdwActualOut = 1;
		break;

	default:
        RetVal = FALSE;
        DEBUGMSG (ZONE_IOCTL, (TEXT(" Unsupported ioctl 0x%X\r\n"), dwCode));
        break;            
    }
    DEBUGMSG (ZONE_IOCTL, (TEXT("-SC_Ioctl 0x%X\r\n"), pHead));
    return(RetVal);
}

// @doc OEM
// @func    BOOL | SC_SetIRBaudRate | Perform IR baudrate setting
// 
// @rdesc    TRUE if successful

static BOOL SC_SetIRBaudRate( PSER_SC16IS_INFO   pHWHead,ULONG baud )
{
    DEBUGMSG (ZONE_INIT, (TEXT("Serial set IR Baud %d\r\n"),baud));
	return TRUE;
}


// @doc OEM
// @func   BOOL | SC_SetOutputMode | Perform Output mode setting
// NOTE : The caller should have set pHWHead->fIRMode.  It is not
// set here, since power on/off may need to temporarily disable
// the interfaces without actually overwriting the current recorded mode.
// @parm   BOOL Should we use IR interface
// @parm   BOOL Should we use Wire interface
// @rdesc  TRUE if successful

static void SC_SetOutputMode( PSER_SC16IS_INFO pHWHead,BOOL UseIR, BOOL Use9Pin )
{
     // TODO - here you need to set the interface to either IR mode
     // or normal serial. Note that it is possible for both BOOls to
     // be false (i.e. power down), but never for both to be TRUE.
}

// GetSerialObj : The purpose of this function is to allow multiple PDDs to be
// linked with a single MDD creating a multi-port driver.  In such a driver, the
// MDD must be able to determine the correct vtbl and associated parameters for
// each PDD.  Immediately prior to calling HWInit, the MDD calls GetSerialObject
// to get the correct function pointers and parameters.
//
PHWOBJ GetSerialObject( DWORD DeviceArrayIndex )
{
    PHWOBJ pSerObj;

    // Unlike many other serial samples, we do not have a statically allocated
    // array of HWObjs.  Instead, we allocate a new HWObj for each instance
    // of the driver.  The MDD will always call GetSerialObj/HWInit/HWDeinit in
    // that order, so we can do the alloc here and do any subsequent free in
    // HWDeInit.

    // Allocate space for the HWOBJ.
    pSerObj = (PHWOBJ)LocalAlloc( LMEM_ZEROINIT|LMEM_FIXED ,
                                  sizeof(HWOBJ) );
    if ( !pSerObj )
        return (NULL);

    // Fill in the HWObj structure that we just allocated.

    pSerObj->BindFlags = THREAD_AT_OPEN;     // Have MDD create thread when device is first opened.
    pSerObj->dwIntID = 0;                    // SysIntr is filled in at init time
    pSerObj->pFuncTbl = (HW_VTBL *) &SC16ISIoVTbl; // Return pointer to appropriate functions

    // Now return this structure to the MDD.
    return (pSerObj);
}


// Routine to clear any pending interrupts.  Called from Init and PostInit
// to make sure we start out in a known state.
VOID ClearPendingInts( PVOID   pHead )
{
    PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;


    EnterCriticalSection(&(pHWHead->RegCritSec));

    try {
		if(!pHWHead->Interface){ 
			INB(SC_IIR,pHWHead->pIIR); 
		}
		else{
			INBSPI(SC_IIR,pHWHead->pIIR); 
		}      
        // RX FIFO should be reset once to clear all errors, if any,
        // associated with bytes received other than the bottommost entry byte. 
        do {
            
            DEBUGMSG (ZONE_INIT, (TEXT("!!IIR %X\r\n"), pHWHead->IIR));

            // Reading LSR clears RLS interrupts.
            // Also, any error bits OE, PE, FE or BI that had been set in LSR are also cleared.
            ReadLSR( pHWHead );
            pHWHead->FCR |= SERIAL_FCR_RCVR_RESET;
			if(!pHWHead->Interface){ 
				// Reset RX FIFO to clear any old data remaining in it.
				OUTB(SC_FCR, pHWHead->FCR );
				pHWHead->FCR &= ~(SERIAL_FCR_RCVR_RESET);
			}
			else{
				// Reset RX FIFO to clear any old data remaining in it.
				OUTBSPI(SC_FCR, pHWHead->FCR );
				pHWHead->FCR &= ~(SERIAL_FCR_RCVR_RESET);
			}
			//Enable FIFO
			if(pHWHead->FIFOMode){
				pHWHead->FCR |= SERIAL_FCR_ENABLE;
				if(!pHWHead->Interface){ 
					OUTB(SC_FCR, pHWHead->FCR);
				}
				else{
					OUTBSPI(SC_FCR, pHWHead->FCR);
				}
			}
            // Reading MSR clears Modem Status interrupt
            ReadMSR( pHWHead );
			if(!pHWHead->Interface){ 
				// Simply reading IIR is sufficient to clear THRE
				INB(SC_IIR,pHWHead->pIIR); 
			}
			else{
				// Simply reading IIR is sufficient to clear THRE
				INBSPI(SC_IIR,pHWHead->pIIR); 
			}
        
        } while (!(pHWHead->IIR & SERIAL_IIR_NO_INTERRUPT_PENDING) );    
    }
    except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ?
            EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        DEBUGMSG (ZONE_INIT,(TEXT("-SC_PostInit, 0x%X - ERROR\r\n"), pHWHead));
        // Just fall through & release CritSec
    }
    LeaveCriticalSection(&(pHWHead->RegCritSec));
}
//
// @doc OEM 
// @func PVOID | Set_AUTO_RTS | 
// 
// @parm DWORD 

BOOL Set_AUTO_RTS(PVOID   pHead){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;
	if(!pHWHead->Interface){ 
		INB(SC_LCR,pHWHead->pLCR);
		OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

		INB(SC_EFR,pHWHead->pEFR);
		if (OUTB(SC_EFR,(pHWHead->EFR |SERIAL_EFR_AUTO_RTS_BAR))){
			pHWHead->EFR |= SERIAL_EFR_AUTO_RTS_BAR;
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}

		OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
	}
	else{
		INBSPI(SC_LCR,pHWHead->pLCR);
		OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

		INBSPI(SC_EFR,pHWHead->pEFR);
		if (OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_AUTO_RTS_BAR))){
			pHWHead->EFR |= SERIAL_EFR_AUTO_RTS_BAR;
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}
		OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
	}      
	return (RetVal);
}
//
// @doc OEM 
// @func PVOID | CLR_AUTO_RTS | 
// 
// @parm DWORD 

BOOL CLR_AUTO_RTS(PVOID   pHead){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;
		if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

			INB(SC_EFR,pHWHead->pEFR);
			if (OUTB(SC_EFR,(pHWHead->EFR & ~SERIAL_EFR_AUTO_RTS_BAR))){
				pHWHead->EFR &= ~SERIAL_EFR_AUTO_RTS_BAR;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}

			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

			INBSPI(SC_EFR,pHWHead->pEFR);
			if (OUTBSPI(SC_EFR,(pHWHead->EFR & ~SERIAL_EFR_AUTO_RTS_BAR))){
				pHWHead->EFR &= ~SERIAL_EFR_AUTO_RTS_BAR;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}      
		return (RetVal);
}

//
// @doc OEM 
// @func PVOID | Set_AUTO_CTS | 
// 
// @parm DWORD 

BOOL Set_AUTO_CTS(PVOID   pHead){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;

	if(!pHWHead->Interface){ 
		INB(SC_LCR,pHWHead->pLCR);
		OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

		INB(SC_EFR,pHWHead->pEFR);
		if (OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_AUTO_CTS_BAR))){
			pHWHead->EFR |= SERIAL_EFR_AUTO_CTS_BAR;
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}

		OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
	}
	else{
		INBSPI(SC_LCR,pHWHead->pLCR);
		OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

		INBSPI(SC_EFR,pHWHead->pEFR);
		if (OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_AUTO_CTS_BAR))){
			pHWHead->EFR |= SERIAL_EFR_AUTO_CTS_BAR;
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}
		OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
	}      
	return (RetVal);
}
//
// @doc OEM 
// @func PVOID | CLR_AUTO_CTS | 
// 
// @parm DWORD 

BOOL CLR_AUTO_CTS(PVOID   pHead){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;

	if(!pHWHead->Interface){ 
		INB(SC_LCR,pHWHead->pLCR);
		OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

		INB(SC_EFR,pHWHead->pEFR);
		if (OUTB(SC_EFR,(pHWHead->EFR & ~SERIAL_EFR_AUTO_CTS_BAR))){
			pHWHead->EFR &= ~SERIAL_EFR_AUTO_CTS_BAR;
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}

		OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
	}
	else{
		INBSPI(SC_LCR,pHWHead->pLCR);
		OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

		INBSPI(SC_EFR,pHWHead->pEFR);
		if (OUTBSPI(SC_EFR,(pHWHead->EFR & ~SERIAL_EFR_AUTO_CTS_BAR))){
			pHWHead->EFR &= ~SERIAL_EFR_AUTO_CTS_BAR;
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}
		OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
	}  
	return (RetVal);
}

//
// @doc OEM 
// @func PVOID | Set_TLR_FC | 
// 
// @parm DWORD 

BOOL Set_TLR_FC(PVOID   pHead,PBYTE buff){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;

    if((*buff & 0x0F) <= ((*buff & 0xF0)>>4)){
		SetLastError (ERROR_INVALID_PARAMETER);
        RetVal = FALSE;
	}

	//To access TCR, make MCR[2]=1 and EFR[4]=1
	//To access EFR, make LCR = 0xBF
	//To access MCR bit two, EFR[4] should be one.

	if(!pHWHead->Interface){ 
	
		if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
			INB(SC_EFR,pHWHead->pEFR);	
			OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
			pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}
		if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)) {
			INB(SC_MCR,pHWHead->pMCR);	// Check for TCR/TLR enable
			OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); 
		}
		if (OUTB(SC_TCR, *buff)) {	//Physical
			pHWHead->TCR  = *buff ;  
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}
	}
	else{
		if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
			INBSPI(SC_EFR,pHWHead->pEFR);	
			OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
			pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}
		if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)){
			INBSPI(SC_MCR,pHWHead->pMCR);	// Check for TCR/TLR enable
			OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); 
		}
		if (OUTBSPI(SC_TCR, *buff)) {	//Physical
			pHWHead->TCR  = *buff ;  
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}
	}

	return (RetVal);
}
//
// @doc OEM 
// @func PVOID | Set_Software_FC | 
// 
// @parm DWORD 

BOOL Set_Software_FC(PVOID   pHead,PBYTE buff){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;

	if(!pHWHead->Interface){ 
		INB(SC_LCR,pHWHead->pLCR);
		OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

		INB(SC_EFR,pHWHead->pEFR);
		if (OUTB(SC_EFR,((pHWHead->EFR & 0xF0) | (*buff & 0x0F)))){
			pHWHead->EFR &= 0xF0;
			pHWHead->EFR |= (*buff & 0x0F);
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}

		OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
	}
	else{
		INBSPI(SC_LCR,pHWHead->pLCR);
		OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 

		INBSPI(SC_EFR,pHWHead->pEFR);
		if (OUTBSPI(SC_EFR,((pHWHead->EFR & 0xF0) | (*buff & 0x0F)))){
			pHWHead->EFR &= 0xF0;
			pHWHead->EFR |= (*buff & 0x0F);
		} else {
			SetLastError (ERROR_TIMEOUT);
			RetVal = FALSE;
		}
		OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
	}      
	return TRUE;
}
//
// @doc OEM 
// @func PVOID | Set_XON1 | 
// 
// @parm DWORD 

BOOL Set_XON1(PVOID   pHead,PBYTE buff){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;
	if(!pHWHead->Interface){ 
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access Xon1 
			
			if (OUTB(SC_XON1, *buff)){
				pHWHead->XON1 = *buff;
        
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}
		else{
			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access Xon1 
			
			if (OUTBSPI(SC_XON1, *buff)){
				pHWHead->XON1 = *buff;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
			OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
		}      
		return (RetVal);
}
//
// @doc OEM 
// @func PVOID | Set_XON1 | 
// 
// @parm DWORD 

BOOL Set_XOFF1(PVOID   pHead,PBYTE buff){
	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;
		if(!pHWHead->Interface){ 
			INB(SC_MCR,pHWHead->pMCR);
			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE){
				OUTB(SC_MCR,pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE);
			}
			INB(SC_LCR,pHWHead->pLCR);
			OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access Xoff1 
			
			if (OUTB(SC_XOFF1, *buff)){
				pHWHead->XOFF1 = *buff;
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
			OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value

			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE){
				OUTB(SC_MCR,pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE);
			}
		}
		else{		
			INBSPI(SC_MCR,pHWHead->pMCR);
			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE){
				OUTBSPI(SC_MCR,pHWHead->MCR & ~SERIAL_MCR_TCR_TLR_ENABLE);
			}
			INBSPI(SC_LCR,pHWHead->pLCR);
			OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access Xoff1 
				
				if (OUTBSPI(SC_XOFF1,*buff )){
					pHWHead->XOFF1 = *buff;
					pHWHead->dcb.XoffChar = pHWHead->XOFF1;
				} else {
					SetLastError (ERROR_TIMEOUT);
					RetVal = FALSE;
				}
				OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value

			if(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE){
				OUTBSPI(SC_MCR,pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE);
			}
		}
		return (RetVal);
}
//
// @doc OEM 
// @func PVOID | Set_Trigger_level | 
// 
// @parm DWORD 

BOOL Set_TX_Trigger_level(PVOID   pHead,PBYTE buff){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;

		//To access TLR, make MCR[2]=1 and EFR[4]=1
		//To access EFR, make LCR = 0xBF
		//To access MCR bit two, EFR[4] should be one.

		//Set the default trigger level if FIFO mode is enable - Interface I2C
		if(pHWHead->FIFOMode && !pHWHead->Interface ){ 
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INB(SC_LCR,pHWHead->pLCR);
				OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INB(SC_EFR,pHWHead->pEFR);	
				OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}
			if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)){// Check for TCR/TLR enable
				INB(SC_MCR,pHWHead->pMCR);	// Read Value for update MCR register
				OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); 
			}
			INB(SC_TLR,pHWHead->pTLR);
			if (OUTB(SC_TLR, ((pHWHead->TLR  & 0xF0) | *buff/4))) {	//Physical
				pHWHead->TLR  = (pHWHead->TLR  & 0xF0) | *buff/4;  
			} 
		}
		//Set the default trigger level if FIFO mode is enable - Interface SPI
		if(pHWHead->FIFOMode && pHWHead->Interface ){ 
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INBSPI(SC_LCR,pHWHead->pLCR);
				OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INBSPI(SC_EFR,pHWHead->pEFR);	
				OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}
			if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)){// Check for TCR/TLR enable
				INBSPI(SC_MCR,pHWHead->pMCR);	// Read Value for update MCR register
				OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); 
			}
			INBSPI(SC_TLR,pHWHead->pTLR);
			if (OUTBSPI(SC_TLR, ((pHWHead->TLR  & 0xF0) | *buff/4))) {	//Physical
				pHWHead->TLR  = (pHWHead->TLR  & 0xF0) | *buff/4;  
			} 
		}
		return TRUE;
}
BOOL Set_RX_Trigger_level(PVOID   pHead,PBYTE buff){

	PSER_SC16IS_INFO pHWHead = (PSER_SC16IS_INFO)pHead;
	BOOL RetVal = TRUE;
		//To access TLR, make MCR[2]=1 and EFR[4]=1
		//To access EFR, make LCR = 0xBF
		//To access MCR bit two, EFR[4] should be one.
		if(!pHWHead->Interface){ 
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INB(SC_LCR,pHWHead->pLCR);
				OUTB(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INB(SC_EFR,pHWHead->pEFR);	
				OUTB(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTB(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}
			if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)) { // Check for TCR/TLR enable
				INB(SC_MCR,pHWHead->pMCR);	
				OUTB(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); 
			}
			INB(SC_TLR,pHWHead->pTLR);
			if (OUTB(SC_TLR, ((pHWHead->TLR  & 0x0F) | (*buff/4)<<4))) {	//Physical
				pHWHead->TLR  = (pHWHead->TLR  & 0x0F) | (*buff/4)<<4;  
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		else{
			if(!(pHWHead->EFR & SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS)){ //Check for enhance mode
				INBSPI(SC_LCR,pHWHead->pLCR);
				OUTBSPI(SC_LCR, SERIAL_LCR_ENHANCE_ACCESS); // LCR = 0xBF,to access EFR 
				INBSPI(SC_EFR,pHWHead->pEFR);	
				OUTBSPI(SC_EFR,(pHWHead->EFR | SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS));
				pHWHead->EFR |= SERIAL_EFR_ENABLE_ENHANCE_FUNCTIONS;
				OUTBSPI(SC_LCR, pHWHead->LCR); // Set LCR as original value
			}
			if(!(pHWHead->MCR & SERIAL_MCR_TCR_TLR_ENABLE)) {// Check for TCR/TLR enable
				INBSPI(SC_MCR,pHWHead->pMCR);	
				OUTBSPI(SC_MCR, (pHWHead->MCR | SERIAL_MCR_TCR_TLR_ENABLE)); 
			}
			INBSPI(SC_TLR,pHWHead->pTLR);
			if (OUTBSPI(SC_TLR, ((pHWHead->TLR  & 0x0F) | (*buff/4)<<4))) {	//Physical
				pHWHead->TLR  = (pHWHead->TLR  & 0x0F) | (*buff/4)<<4;  
			} else {
				SetLastError (ERROR_TIMEOUT);
				RetVal = FALSE;
			}
		}
		return RetVal;
}