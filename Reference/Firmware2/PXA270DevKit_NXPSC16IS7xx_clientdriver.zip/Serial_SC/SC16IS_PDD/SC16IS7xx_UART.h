/*
//==============================================================================
// COPYRIGHT (C)1997-2006 BSQUARE Corporation
//	ALL RIGHTS RESERVED
//
//	CONFIDENTIAL
//
//	This file is confidential and proprietary intellectual property
//	of BSQUARE Corporation.  No use, modification, duplication,
//	or distribution of any part of this file is permitted without
//	express written permission from BSQUARE Corporation.
//===============================================================================
//===============================================================================

	File name   : SC16IS7XX_16550.h 
	Description : Register defination of SC16IS7XX chip for serial port driver	

	History	    :
		ver 0.1	  8th November 2006	
			      Initial
    Author:
	    
*********************************************************************************
*/

#ifndef __SC16IS7xx_UART_H__
#define __SC16IS7xx_UART_H__
#include <ddkreg.h>
#ifdef __cplusplus
extern "C" {
#endif

    // We use a callback for serial events
    typedef VOID		(*EVENT_FUNC)(PVOID Arg1, ULONG Arg2);
	
	// The library has a default baud table, but this can be replaced
    typedef struct	__PAIRS {
        ULONG   Key;
        ULONG   AssociatedValue;
    } PAIRS, *PPAIRS;

    typedef struct __LOOKUP_TBL {
        ULONG   Size;
        PPAIRS  Table;
    } LOOKUP_TBL, *PLOOKUP_TBL;

	// @doc HWINTERNAL
	// @struct LS_SERIAL_INFO | Passed to serial lib routines.
	// 
    typedef struct __SER_INFO
    {
         // Store volatile pointers to each 16550 register 
        PUCHAR pData;           // @field RX data / Transmit Holding Reg
        PUCHAR pIER;            // @field Interrupt Enable
		PUCHAR pIIR;			// @field read IIR (Int ID) 
		PUCHAR pFCR;			// @field Write FCR (FIFO Ctrl)
        PUCHAR pLCR;            // @field Line Control
        PUCHAR pMCR;            // @field Modem Control
        PUCHAR pLSR;            // @field Line Status
        PUCHAR pMSR;            // @field Modem Status
        PUCHAR pScratch;        // @field Scratch Register

		//SC16IS7XX extra register
		PUCHAR pTCR;		//@field Tx control
		PUCHAR pTLR;		//@field Trigger level
		PUCHAR pTXLVL;		//@field Tx FIFO level
		PUCHAR pRXLVL;		//@field Rx FIFO level
		PUCHAR pIODIR;		//@field IO pin direction control
		PUCHAR pIOSTATE;	//@field IO pin states 
		PUCHAR pIOINTENA;	//@field IO interrupt enable
		PUCHAR pIOCTRL;	//@field IO pins control
		PUCHAR pEFCR;		//@field Extra features
		PUCHAR pEFR;		//@field Enahanced feature
		PUCHAR pXON1;		//@field Programmable flow ctrl ON1
		PUCHAR pXON2;		//@field Programmable flow ctrl ON2
		PUCHAR pXOFF1;		//@field Programmable flow ctrl OFF1
		PUCHAR pXOFF2;		//@field Programmable flow ctrl OFF2
		//
        //And we keep shadows of registers
		UCHAR		Data;			// @field THR and RHR 
        UCHAR		FCR;			// @field FIFO control state. 
        UCHAR		IIR;			// @field State of Interrupt Identification Register. 
        UCHAR		LSR;			// @field Line Status Register. 
        UCHAR		MSR;			// @field Modem Status Register. 
        //We wouldn't normally shadow these, except for power on/off
        UCHAR		IER;			// @field Interrupt Enable Register. 
        UCHAR		LCR;			// @field Line Control Register. 
        UCHAR		MCR;			// @field Modem Control Register. 
        UCHAR		Scratch;		// @field Scratch Register.
        
		//we keep shadows of many of the SC16IS7XX registers
		UCHAR		TCR;			// @field Transmission Control Register
		UCHAR		TLR;			// @field Triger Level Register
		UCHAR		TXLVL;			// @field Transmit FIFO Level Register
		UCHAR		RXLVL;			// @field Receive FIFO Level Register
		UCHAR		IODIR;			// @field I/O Pin Direction Register
		UCHAR		IOSTATE;		// @field I/O Pins State Register
		UCHAR		IOINTENA;		// @field I/O Interrupt Enable Register
		UCHAR		IOCTRL;			// @field I/O Pins Control Register
		UCHAR		EFCR;			// @field Extra Features Control Register
		UCHAR		EFR;			// @field Enhanced Features Register
		UCHAR		XON1;			// @field Xon1 Word Register
		UCHAR		XON2;			// @field Xon2 Word Register
		UCHAR		XOFF1;			// @field Xoff1 Word Register
		UCHAR		XOFF2;			// @field Xoff2 Word Register
		//

        //We have an event callback into the MDD
        EVENT_FUNC EventCallback; // This callback exists in MDD
        PVOID        pMddHead;  // This is the first parm to callback
        
         // Keep a copy of DCB since we rely on may of its parms
        DCB         dcb;        // @field Device Control Block (copy of DCB in MDD)
         // And the same thing applies for CommTimeouts
        COMMTIMEOUTS CommTimeouts;  // @field Copy of CommTimeouts structure
        
         // Misc fields used by ser16550 library
        ULONG		OpenCount;	    // @field Count of simultaneous opens. 
        PLOOKUP_TBL pBaudTable;     // @field Pointer to Baud Table
        ULONG		DroppedBytes;	// @field Number of dropped bytes 
        HANDLE		FlushDone;		// @field Handle to flush done event.
        BOOL		CTSFlowOff;		// @field Flag - CTS flow control state. 
        BOOL		DSRFlowOff;		// @field Flag - DSR flow control state. 
		BOOL		AddTXIntr;		// @field Flag - Fake a TX intr.
        COMSTAT		Status; 		// @field Bitfield representing Win32 comm status. 
        ULONG		CommErrors;		// @field Bitfield representing Win32 comm error status. 
        ULONG		ModemStatus;	// @field Bitfield representing Win32 modem status. 
        CRITICAL_SECTION	TransmitCritSec; // @field Protects UART Registers for non-atomic accesses
        CRITICAL_SECTION	RegCritSec; // @field Protects UART 
        BOOL		PowerDown;      // did we power down the chip
        BOOL		bSuspendResume; // Indicate Suspend/Resume happens
		BOOL		fIRMode;		// @field Boolean, are we running in IR mode?
        //
        // now hardware specific fields Duplicated Info
		PUCHAR		pBaseAddress;	// @field Start of serial registers
        DWORD       dwIOBase;       // @field Base Address - unmapped
        DWORD       dwIOLen;        // @field Length
        DWORD       dwIrq;          // IRQ field
        DWORD       dwSysIntr;       // @field System Interrupt number for this peripheral
		DWORD       dwDevIndex;     // @field Index of device

        PVOID       pVirtualStaticAddr;// Static Address.
 		DWORD		dwUnitIndex;	// @field Index of sub device
		DWORD		dwPortIndex;	// @field Index of sub device
		DWORD		dwSlaveAddress;	// @ Slave address of connected I2C device
		DWORD		Interface;		// @ Interface Slection: 0- I2C
									//						 1- SPI	
         TCHAR		IoEventName[50];	// GPIO interrupt signaling event name
        HANDLE 		IoInterrupt;

		DWORD       FIFOMode;		// @ FIFOMode:  0 - Disable[ Single Read and Single Write Interrupt cycle ]
									//				1 - Enable FIFO Mode.
		DWORD       ChipID;			// @ CHIPID:    0 - SC16IS752 - read from registry
									//				1 - SC16IS762 - read from registry
		BYTE		bRemainBuffer[64]; //@BUffer to store the FIFO Read Data
		BYTE        ucRxRemain;        // @field How many RX bytes remaining after an RXIntr.
		PBYTE		lpbRemainBufPtr;	

		PHWOBJ		pHWObj;         // @field Pointer to PDDs HWObj structure

		// And whatever else we need
        UINT8       cOpenCount;     // @field Count of concurrent opens
        COMMPROP	CommProp;	    // @field CommProp structure.

    } SER_SC16IS_INFO, *PSER_SC16IS_INFO;

	// Here is the callback for serial events
    typedef VOID (*PFN_SER_EVENT) (
        PVOID pHandle,              // PHW_INDEP_INFO, but pdd doesn't know it
        UINT32 events               // What events where encountered?
        );

/********************************************************************************
 Structure used for send and receive data
*********************************************************************************/
typedef struct {
	unsigned int Bus;				// SPI Bus number - SSP1 support only
	unsigned int Device;			// Device Number  - One slave device only
	unsigned int DataSize;			// bits of data for each data unit (typically 8-16)
	unsigned int FrameFormat;		// Frame format -- SPI_FRAME_FORMAT_SPI only
	unsigned int ClockRate;			// desired clock rate in HZ -- actual clock rate <= requested
	unsigned int Flags;				// misc flags -- see definition below
	unsigned int TimeOutMs;			// timeout used for any operations that require a timeout
	unsigned int DataUnitCount;		// number of data units to send in this transaction
} SPI_SERIAL_TRANSACTION, * PSPI_SERIAL_TRANSACTION;

/********************************************************************************
 CPU specific defines
 FRAME format defines -
	 The following macros are used with the FrameFormat field in the
	 SPI_TRANSACTION data structure

*********************************************************************************/

#define SPI_FRAME_FORMAT_SPI		0
#define SPI_FRAME_FORMAT_TISSP		1
#define SPI_FRAME_FORMAT_MICROWIRE	2

/********************************************************************************
 CPU independent transaction flags
*********************************************************************************/

// Note: when defining new flags make sure that they do not overlap
// the CPU dependent transaction flags

// When the SPI_FLAGS_8BIT_BUFFERS flag is set the transaction data buffers pointed to
// by pSendData and pRecvData to be treated as pointers to unsigned 8 bit data.
//
// Note: If this flag is set the transaction DataSize must be 8 or the transaction will fail.
// Note: When filling out the SPI_IOCTL_TRANSACTION and using pointers to 8 bit data 
//       you will need to cast the pointers as (unsigned short *) but the driver will 
//       cast them to (unsigned char *) before use.
#define SPI_FLAGS_8BIT_BUFFERS			(1 << 31)

/********************************************************************************
 CPU dependent transaction flags
*********************************************************************************/

#define SPI_FLAGS_INVERT_CLOCK_MASK		(1 << 0)	// set to 1 for active low clock
#define SPI_FLAGS_PHASE_MASK			(1 << 1)	// 0 -> SPI clock is inactive one
                                        	        //      cycle at start of frame and
													//      1/2 at end
													// 1 -> SPI clock is inactive 1/2 cycle
													//      at start of frame and one cycle
													//      at end
#define SPI_LOOPBACK_MODE_ENABLE    	(1 << 3)	// set to enable loopback mode -- for testing
#define SPI_POLLED_MODE_ONLY	    	(1 << 4)	// set to prevent driver from performing an 
													// interrupt driven transaction.  This flag 
													// has no effect if the driver is not 
													// configured to support SPI interrupts.



	// Here are the names of the values stored in the registry
    #define PC_REG_SYSINTR_VAL_NAME TEXT("SysIntr") 
    #define PC_REG_SYSINTR_VAL_LEN  sizeof( DWORD )

    #define PC_REG_IOBASE_VAL_NAME TEXT("IoBase") 
    #define PC_REG_IOBASE_VAL_LEN  sizeof( DWORD )
    #define PC_REG_IOLEN_VAL_NAME TEXT("IoLen") 
    #define PC_REG_IOLEN_VAL_LEN  sizeof( DWORD )

    #define PC_REG_DEVINDEX_VAL_NAME TEXT("DeviceArrayIndex") 
    #define PC_REG_DEVINDEX_VAL_LEN  sizeof( DWORD )

    #define PC_REG_UNITINDEX_VAL_NAME TEXT("UnitIndex") 
    #define PC_REG_UNITINDEX_VAL_LEN  sizeof( DWORD )
    #define PC_REG_PORTINDEX_VAL_NAME TEXT("PortIndex") 
    #define PC_REG_PORTINDEX_VAL_LEN  sizeof( DWORD )

    #define PC_REG_I2CSLAVE_VAL_NAME TEXT("SlaveAddress")
    #define PC_REG_I2CSLAVE_VAL_LEN  sizeof( DWORD )

    #define PC_REG_INTERFACE_VAL_NAME TEXT("Interface")
    #define PC_REG_INTERFACE_VAL_LEN  sizeof( DWORD )

    #define PC_REG_FIFOMODE_VAL_NAME TEXT("FIFOMode")
    #define PC_REG_FIFOMODE_VAL_LEN  sizeof( DWORD ) 

    #define PC_REG_IO_NAMED_EVENT_VAL_NAME TEXT("IoNamedEvent")
    #define PC_REG_IO_NAMED_EVENT_VAL_LEN  sizeof(CHAR)*50

    #define PC_REG_CHIPID_VAL_NAME TEXT("CHIPID")
    #define PC_REG_CHIPID_VAL_LEN  sizeof( DWORD ) 


	// All the function prototypes
	
	static PVOID SC_Init(ULONG Identifier, PVOID pMddHead, PHWOBJ pHWObj);
	static BOOL  SC_PostInit(PVOID pHead);
	static BOOL  SC_Deinit(PVOID pHead);
	static BOOL  SC_Open(PVOID pHead);
	static ULONG SC_Close(PVOID pHead);
	static INTERRUPT_TYPE SC_GetInterruptType(PVOID pHead);
	static ULONG SC_RxIntr(PVOID pHead, PUCHAR pRxBuffer, ULONG *pLength);
	static VOID  SC_TxIntr(PVOID pHead, PUCHAR pTxBuffer, ULONG *pLength);
	static VOID  SC_ModemIntr(PVOID pHead);
	static VOID  SC_LineIntr(PVOID pHead);
	static ULONG SC_GetRxBufferSize(PVOID pHead);
	static BOOL  SC_PowerOff(PVOID pHead);
	static BOOL  SC_PowerOn(PVOID pHead);
	static VOID  SC_ClearDTR(PVOID pHead);
	static VOID  SC_SetDTR(PVOID pHead);
	static VOID  SC_ClearRTS(PVOID pHead);
	static VOID  SC_SetRTS(PVOID pHead);
	static BOOL  SC_EnableIR(PVOID pHead, ULONG baudRate);
	static BOOL  SC_DisableIR(PVOID pHead);
	static VOID  SC_ClearBreak(PVOID pHead);
	static VOID  SC_SetBreak(PVOID pHead);
	static VOID  SC_Reset(PVOID pHead);
	static VOID  SC_GetModemStatus(PVOID pHead, ULONG *pModemStat);
	static BOOL  SC_XmitComChar(PVOID pHead, UCHAR ch);
	static ULONG SC_GetStatus(PVOID pHead, COMSTAT *pComStat);
	static VOID  SC_GetCommProperties(PVOID pHead, COMMPROP *pCommProp);
	static VOID  SC_PurgeComm(PVOID pHead, DWORD action);
	static BOOL  SC_SetDCB(PVOID pHead, DCB *pDCB);
	static ULONG SC_SetCommTimeouts(PVOID pHead, COMMTIMEOUTS *pCommTimeouts);
	static BOOL SC_Ioctl(PVOID pHead, DWORD dwCode,PBYTE pBufIn,DWORD dwLenIn,
         PBYTE pBufOut,DWORD dwLenOut,PDWORD pdwActualOut);
    static ULONG SC_GetByteNumber(PVOID pHead);
    static VOID  SC_DisableXmit(PVOID pHead );
    static VOID  SC_EnableXmit(PVOID pHead);
    static BOOL  SC_SetBaudRate(PVOID pHead,ULONG BaudRate);
    static PVOID SC_GetRxStart(PVOID pHead);
	static ULONG SC_PutBytes(PVOID pHead,PUCHAR pSrc,ULONG NumberOfBytes,PULONG pBytesSent);
    static VOID  SC_OtherIntr(PVOID pHead);
	static VOID  SC_TxIntrEx(PVOID pHead,PUCHAR pTxBuffer,ULONG *pBufflen);
	static BOOL	 SC_SetByteSize(PVOID pHead, ULONG ByteSize);
	static BOOL  SC_SetStopBits(PVOID pHead, ULONG StopBits);
	static BOOL  SC_SetParity(PVOID pHead, ULONG Parity);
	static void	 SC_SetOutputMode(PSER_SC16IS_INFO pHWHead,BOOL UseIR, BOOL Use9Pin);
	static BOOL  SC_SetIRBaudRate(PSER_SC16IS_INFO pHWHead,ULONG baud);
	static BOOL  SC_GetRegistryData(PSER_SC16IS_INFO pHWHead, LPCTSTR regKeyPath);

	VOID ClearPendingInts(PVOID pHead);

//*********************************************************
// Functions from the SC16IS7XX HW support file
//*********************************************************


extern BOOL I2C_Bus_Init(void);
extern BOOL I2C_Bus_Deinit(void);
extern BOOL I2C_Write_Register(UCHAR SlaveAddress,UCHAR Reg_address,UCHAR PortIndex, UCHAR Data);
extern BOOL I2C_Read_Register(UCHAR SlaveAddress,UCHAR Reg_address,UCHAR PortIndex, PUCHAR pData);

//SPI
extern DWORD SC_SpiBusInit(BOOL InPowerHandler);
extern void SPI_deinit(void);
extern DWORD SC_SpiBusConfig(PSPI_SERIAL_TRANSACTION,BOOL);
extern BOOL  SPI_Write_Register(UCHAR RegAddress,UCHAR data,UCHAR Channel);
extern BOOL  SPI_Read_Register(UCHAR RegAddress,PUCHAR Data,UCHAR Channel);
extern BOOL  SPI_FIFO_READ(PBYTE lpDataSrc,PBYTE lpbNrOfData,UCHAR Channel);
extern BOOL  SPI_FIFO_WRITE(PBYTE lpDataSrc,PBYTE lpbNrOfData,UCHAR Channel);

extern ISRInit();
extern IsrCloseHandles();

//
BOOL Set_TX_Trigger_level(PVOID   pHead,PBYTE buff);
BOOL Set_RX_Trigger_level(PVOID   pHead,PBYTE buff);
BOOL Set_XON1(PVOID   pHead,PBYTE buff);
BOOL Set_XOFF1(PVOID   pHead,PBYTE buff);
BOOL Set_Software_FC(PVOID   pHead,PBYTE buff);
BOOL Set_TLR_FC(PVOID   pHead,PBYTE buff);
BOOL Set_AUTO_RTS(PVOID   pHead);
BOOL CLR_AUTO_RTS(PVOID   pHead);
BOOL Set_AUTO_CTS(PVOID   pHead);
BOOL CLR_AUTO_CTS(PVOID   pHead);

//*********************************************************
// IOCTLs for EXTRA features
//*********************************************************

#define IOCTL_SERIAL_SET_IODIR			CTL_CODE(FILE_DEVICE_SERIAL_PORT,26,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_IOINTENA		CTL_CODE(FILE_DEVICE_SERIAL_PORT,27,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_IOLATCH		CTL_CODE(FILE_DEVICE_SERIAL_PORT,28,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_CLR_IOLATCH		CTL_CODE(FILE_DEVICE_SERIAL_PORT,29,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_MODEM_IO_PORTA		CTL_CODE(FILE_DEVICE_SERIAL_PORT,30,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_MODEM_IO_PORTB		CTL_CODE(FILE_DEVICE_SERIAL_PORT,31,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_RESET				CTL_CODE(FILE_DEVICE_SERIAL_PORT,32,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_TXITL			CTL_CODE(FILE_DEVICE_SERIAL_PORT,33,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_RXITL			CTL_CODE(FILE_DEVICE_SERIAL_PORT,34,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_WRITE_IOSTATE		CTL_CODE(FILE_DEVICE_SERIAL_PORT,35,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_READ_IOSTATE		CTL_CODE(FILE_DEVICE_SERIAL_PORT,36,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_GET_DUMP_REGISTER	CTL_CODE(FILE_DEVICE_SERIAL_PORT,37,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_SLEEP			CTL_CODE(FILE_DEVICE_SERIAL_PORT,38,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_SFCTL			CTL_CODE(FILE_DEVICE_SERIAL_PORT,39,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_HFCTL			CTL_CODE(FILE_DEVICE_SERIAL_PORT,40,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_ENABLE_TX			CTL_CODE(FILE_DEVICE_SERIAL_PORT,41,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_DISABLE_TX			CTL_CODE(FILE_DEVICE_SERIAL_PORT,42,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_ENABLE_RX			CTL_CODE(FILE_DEVICE_SERIAL_PORT,43,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_DISABLE_RX			CTL_CODE(FILE_DEVICE_SERIAL_PORT,44,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_XONANY			CTL_CODE(FILE_DEVICE_SERIAL_PORT,45,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_CLR_XONANY			CTL_CODE(FILE_DEVICE_SERIAL_PORT,46,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_XON1			CTL_CODE(FILE_DEVICE_SERIAL_PORT,47,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_XON2			CTL_CODE(FILE_DEVICE_SERIAL_PORT,48,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_XOFF1			CTL_CODE(FILE_DEVICE_SERIAL_PORT,49,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_XOFF2			CTL_CODE(FILE_DEVICE_SERIAL_PORT,50,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_AUTORTS		CTL_CODE(FILE_DEVICE_SERIAL_PORT,51,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_AUTOCTS		CTL_CODE(FILE_DEVICE_SERIAL_PORT,52,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_CLR_AUTORTS		CTL_CODE(FILE_DEVICE_SERIAL_PORT,53,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_CLR_AUTOCTS		CTL_CODE(FILE_DEVICE_SERIAL_PORT,54,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_SFCTRL_MODE	CTL_CODE(FILE_DEVICE_SERIAL_PORT,55,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_FCR_TXTL		CTL_CODE(FILE_DEVICE_SERIAL_PORT,56,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_FCR_RXTL		CTL_CODE(FILE_DEVICE_SERIAL_PORT,57,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_MODEM_LOOPBACK		CTL_CODE(FILE_DEVICE_SERIAL_PORT,58,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SPECIAL_CHAR		CTL_CODE(FILE_DEVICE_SERIAL_PORT,59,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_CTS_RTS_INT_ENABLE	CTL_CODE(FILE_DEVICE_SERIAL_PORT,60,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_IRDAMODE_FAST	CTL_CODE(FILE_DEVICE_SERIAL_PORT,61,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_SET_IRDAMODE_SLOW	CTL_CODE(FILE_DEVICE_SERIAL_PORT,62,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define IOCTL_SERIAL_GET_SINGLE_REGISTER CTL_CODE(FILE_DEVICE_SERIAL_PORT,63,METHOD_BUFFERED,FILE_ANY_ACCESS)

#ifdef __cplusplus
}
#endif

#endif __SC16IS7xx_UART_H__