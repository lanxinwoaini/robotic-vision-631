/*
//==============================================================================
// COPYRIGHT (C)1997-2006 BSQUARE Corporation
//	ALL RIGHTS RESERVED
//
//	CONFIDENTIAL
//
//	This file is confidential and proprietary intellectual property
//	of BSQUARE Corporation.  No use, modification, duplication,
//	or distribution of any part of this file is permitted without
//	express written permission from BSQUARE Corporation.
//===============================================================================
//===============================================================================
	File name   : SC16IS7XX_ISR.h 
	Description : This is header file for IST routine.
	History	    : Initial
    Author:
	    
*********************************************************************************
*/

#ifndef __SC16IS7xx_ISR_H__
#define __SC16IS7xx_ISR_H__
#ifdef __cplusplus
extern "C" {
#endif


#define SC_IIR 0x02 // IIR address used in I2C and SPI routine

extern BOOL  SPI_Read_Register(UCHAR RegAddress,PUCHAR Data,UCHAR Channel);
extern BOOL  I2C_Read_Register(UCHAR SlaveAddress,UCHAR Reg_address,UCHAR PortIndex, PUCHAR pData);

//Global area 
static HANDLE hEventPortA,hEventPortB;  // Handle for serial events
static HANDLE pDispatchThread;			// Thread handle
HANDLE hInterruptEvent;

extern BYTE ReadFlag0,ReadFlag1;

extern DWORD  Interface;
extern DWORD  Sysintr;
extern DWORD  I2CSlaveAdd;
extern BOOL  PORTAFLAG;
extern BOOL  PORTBFLAG;
extern PUCHAR IIR0;
extern PUCHAR IIR1;

#define PORTA_INDEX 0	// Port index is passed to interface functions
#define PORTB_INDEX 1

#define INTERRUPT_MASK	0x01	// Masking to know, whether interrupt is generated or not

#define DEFAULT_THREAD_PRIORITY 100 // Thread priority, default for noraml real time task


#ifdef __cplusplus
}
#endif

#endif __SC16IS7xx_ISR_H__