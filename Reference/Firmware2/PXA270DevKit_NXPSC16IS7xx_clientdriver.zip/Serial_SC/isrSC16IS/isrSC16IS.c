/*
//==============================================================================
// COPYRIGHT (C)1997-2006 BSQUARE Corporation
//	ALL RIGHTS RESERVED
//
//	CONFIDENTIAL
//
//	This file is confidential and proprietary intellectual property
//	of BSQUARE Corporation.  No use, modification, duplication,
//	or distribution of any part of this file is permitted without
//	express written permission from BSQUARE Corporation.
//===============================================================================
//===============================================================================
    Module name : isrSC16IS.lib
	File name   : isrSC16IS.c 
	Description : The funtions initalize the interrupt.It also 
				  creates two named event and interrupt thread.Interrupt thread 
				  will check the source of interrupt(PORTA or PORTB) and signal 
				  the mdd. mdd will do the further processing of interrupt.		
	History	    : Initial
    Author:
	    
*********************************************************************************
*/

/********************************************************************************
 Include Files
*********************************************************************************/
#include <windows.h>
#include <nkintr.h>
#include <ceddk.h>
#include "sc16is7xx_isr.h"

static	UCHAR  IIR_PORTA = INTERRUPT_MASK;
static	UCHAR  IIR_PORTB = INTERRUPT_MASK;


// **************************************************************************************
// Name : SC16IS7XXEventThread
//
//
// parameter : 
//		HANDLE  hEvent
//
// return values : 			
//		None.
//
// description : 		
//		  This is the main interrupt thread running at default windows ce thread priority.
//		  When interrupt generates either from PORTA or PORTB waiting object should get 
//		  unblocks and check the status of com PORTA , if COM PORTA is open then only it 
//		  read the IIR register of PORTA to find out the interrupt source.if interrupt is 
//		  identified then event will be signal to the mdd and mdd will do the further 
//		  processing.same process applies to COM PORTB.
// **************************************************************************************
DWORD WINAPI SC16IS7XXEventThread(HANDLE hEvent)
{
    ULONG       WaitReturn;

	while(TRUE ) 
    {
			WaitReturn = WaitForSingleObject(hEvent, INFINITE);
			if(WaitReturn == WAIT_OBJECT_0){

			//IF PORTA is opened and active
			if(PORTAFLAG == TRUE){
				// Check Interface .. I2C/SPI
				if(!Interface){	
						I2C_Read_Register((UCHAR)I2CSlaveAdd,(UCHAR)SC_IIR,PORTA_INDEX,(PUCHAR)&IIR_PORTA);
				}
				else{	
						//Read PORTA IIR register
						SPI_Read_Register((UCHAR)SC_IIR,(PUCHAR)&IIR_PORTA,PORTA_INDEX);
				}
				if(!(IIR_PORTA & INTERRUPT_MASK)){
						SetEvent(hEventPortA);
						*IIR0 = IIR_PORTA;
						 ReadFlag0 = FALSE;
				}
				else{
					if(PORTBFLAG == FALSE){
						SetEvent(hEventPortA);
						*IIR0 = IIR_PORTA;
						ReadFlag0 = FALSE;
					}
				}
			}
			if(PORTBFLAG == TRUE){
				if(!Interface){
						I2C_Read_Register((UCHAR)I2CSlaveAdd,(UCHAR)SC_IIR,PORTB_INDEX,(PUCHAR)&IIR_PORTB);
				}
				else // Reading of PORTB, use portindex is one
				{
						SPI_Read_Register((UCHAR)SC_IIR,(PUCHAR)&IIR_PORTB,PORTB_INDEX);
				}
				if(!(IIR_PORTB & INTERRUPT_MASK)){
						SetEvent(hEventPortB); 
						*IIR1 = IIR_PORTB;
						ReadFlag1 = FALSE;
				}
				else{
					if(PORTAFLAG == FALSE){
						SetEvent(hEventPortB);
						*IIR1= IIR_PORTB;
						ReadFlag1 = FALSE;
					}
				}
			}	
			if(((IIR_PORTB & INTERRUPT_MASK) == 0x01) && ((IIR_PORTA & INTERRUPT_MASK) == 0x01) ){
						SetEvent(hEventPortB);
						*IIR1= IIR_PORTB;
						ReadFlag1 = FALSE;
			}
		}
	}    
}
// Function Name : ISRInit
//
// parameter :		None.
// Return values : 	
//		This function returns the value 0 - FALSE	
//										1 - TRUE
// Description :
//		  This Function is called from the SC_Open() function and it should be called only one time.
//		  This function creates the following Event:
//						heventPortA		- Used to signale the MDD that interrupt from PORTA
//						heventPortB		- Used to signale the MDD that interrupt from PORTB
//						hInterruptEvent	- This Event should unblocks from the any waiting 
//						                  objects when interrupt is generated.
//		  This Function then initalize the interrupt using InterruptInitialize() function.
//		  This Function then creates the pDispatchThread used for interrupt processing.
//			and PORTB in mdd serialeventhandler.

BOOL ISRInit()
{
 	// Create named event for PORTA
	hEventPortA = CreateEvent( NULL, FALSE, FALSE,L"PortANamedEvent");
	if(hEventPortA == NULL){
		return FALSE;
	}
	// Create named event for PORTB
	hEventPortB = CreateEvent( NULL, FALSE, FALSE,L"PortBNamedEvent" );
	if(hEventPortB == NULL){
		return FALSE;
	}
	// Create our interrupt event.
    hInterruptEvent = CreateEvent(0,FALSE,FALSE,NULL);
	if(hInterruptEvent == NULL){
		return FALSE;
	}
	// Initialize Interrupt
    if ( !InterruptInitialize(Sysintr,
                              hInterruptEvent,
                              0,
                              0) ) 
    {
        return (FALSE);
    }
	InterruptDone(Sysintr);

	pDispatchThread = CreateThread(NULL,0, SC16IS7XXEventThread, hInterruptEvent,0,NULL);
    if ( pDispatchThread == NULL ) 
    {
        return (FALSE);
    }
	CeSetThreadPriority(pDispatchThread, DEFAULT_THREAD_PRIORITY);

    return TRUE;
}
// Function Name : IsrCloseHandles
//
// parameter : 
//				NONE
// Return values : 	
//				NONE
// Description : This function is called from PDD close function. And it will close thread handle 
//	
void IsrCloseHandles(void)
{
	CloseHandle(pDispatchThread); // Closing of thread 
    InterruptDone(Sysintr);	// Interrupt done and disable for closing serial port
    InterruptDisable(Sysintr);
}