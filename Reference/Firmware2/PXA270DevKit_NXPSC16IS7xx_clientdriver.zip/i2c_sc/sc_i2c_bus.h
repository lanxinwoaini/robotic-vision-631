/*
//==============================================================================
// COPYRIGHT (C)1997-2006 BSQUARE Corporation
//	ALL RIGHTS RESERVED
//
//	CONFIDENTIAL
//
//	This file is confidential and proprietary intellectual property
//	of BSQUARE Corporation.  No use, modification, duplication,
//	or distribution of any part of this file is permitted without
//	express written permission from BSQUARE Corporation.
//===============================================================================
//===============================================================================

	File name   : SC_I2C_BUS.h 
	Description : 

	History	    :
		ver 0.1	  16th November 2006	
			      Initial
    Author:
	
*********************************************************************************
*/

#ifndef _SC_I2C_BUS_H_
#define _SC_I2C_BUS_H_

#ifdef __cplusplus
extern "C" {
#endif



#define CPU_PERREGS_MAPPED				0x88400000
#define NONCACHED_NONBUFFERED_OFFSET	(0x20000000)

//----------------------------------------------------------------------------
//
// I2C bus related defiantions and export functions.
//
//----------------------------------------------------------------------------

// offset from base of peripheral registers
#define CPU_I2C_OFFSET						0x00301680
#define CPU_I2C_BASE		((CPU_PERREGS_MAPPED | NONCACHED_NONBUFFERED_OFFSET) + CPU_I2C_OFFSET)

// I2C ICR (control) register bit definitions
#define CPU_I2C_ICR_START					0x01
#define CPU_I2C_ICR_STOP					0x02
#define CPU_I2C_ICR_ACKNAK					0x04
#define CPU_I2C_ICR_TB						0x08
#define CPU_I2C_ICR_MA						0x10
#define CPU_I2C_ICR_SCLE					0x20
#define CPU_I2C_ICR_IUE						0x40
#define CPU_I2C_ICR_GCD						0x80
#define CPU_I2C_ICR_ITEIE					0x100
#define CPU_I2C_ICR_DRFIE					0x200
#define CPU_I2C_ICR_BEIE					0x400
#define CPU_I2C_ICR_SSDIE					0x800
#define CPU_I2C_ICR_ALDIE					0x1000
#define CPU_I2C_ICR_SADIE					0x2000
#define CPU_I2C_ICR_UR						0x4000
#define CPU_I2C_ICR_FM						0x8000

// I2C ISR (status) register bit definitions
#define CPU_I2C_ISR_RWM						0x01
#define CPU_I2C_ISR_ACKNAK					0x02
#define CPU_I2C_ISR_UB						0x04
#define CPU_I2C_ISR_IBB						0x08
#define CPU_I2C_ISR_SSD						0x10
#define CPU_I2C_ISR_ALD						0x20
#define CPU_I2C_ISR_ITE						0x40
#define CPU_I2C_ISR_IRF						0x80
#define CPU_I2C_ISR_GCAD					0x100
#define CPU_I2C_ISR_SAD						0x200
#define CPU_I2C_ISR_BED						0x400

typedef struct _cpu_i2cregs
{
	volatile unsigned int ibmr;				// 0x80
	unsigned int reserved1;
	volatile unsigned int idbr;				// 0x88
	unsigned int reserved2;
	volatile unsigned int icr;				// 0x90
	unsigned int reserved3;
	volatile unsigned int isr;				// 0x98
	unsigned int reserved4;
	volatile unsigned int isar;				// 0xA0
} CPU_I2CREGS;
typedef CPU_I2CREGS * PCPU_I2CREGS;


static PCPU_I2CREGS g_pController[2] = {
	(PVOID) CPU_I2C_BASE, 
};	
	
static PVOID pvControllerMapBase[2] = {
		NULL,
		NULL
	};


//----------------------------------------------------------------------------
//
// Timer related defiantions and export functions.
//
//----------------------------------------------------------------------------

#define CPU_OST_OFFSET						0x00A00000
#define CPU_OST_BASE	((CPU_PERREGS_MAPPED | NONCACHED_NONBUFFERED_OFFSET) + CPU_OST_OFFSET)

typedef struct _bulverde_ostregs
{
	volatile unsigned int filler[4];
	volatile unsigned int oscr0;

} CPU_OSTREGS;

typedef CPU_OSTREGS * PCPU_OSTREGS;

// This define will probably never be changed.
#define CRYSTAL_FREQUENCY_HZ	13000000
#define TIMER_FREQUENCY_HZ		(CRYSTAL_FREQUENCY_HZ / 4)

// These functions handle short period timestamps
typedef unsigned long TIMESTAMP;
typedef unsigned long * PTIMESTAMP;

TIMESTAMP GetTimeStamp(void);
TIMESTAMP GetTimeStampKernel(void);
DWORD GetTimeStampDeltaUs(TIMESTAMP newtimestamp, TIMESTAMP oldtimestamp);
void DelayMicroSeconds(DWORD dw_uSec);

//----------------------------------------------------------------------------
//
// Structure used for send and receive data 
//
//----------------------------------------------------------------------------

typedef struct {
    BYTE Bus;               // I2C Bus number (0 = first bus, 1 = second, etc.)
    BYTE * pAddress;        // Address of device (note many devices use bit zero of address as read/write bit)
    DWORD AddressLength;    // number of address bytes to send
    BYTE * pData;           // pointer to data buffer
    DWORD DataLength;       // number of bytes to send or receive
} I2C_IOCTL_TRANSACTION, * PI2C_IOCTL_TRANSACTION;

#define INPOWERHANDLERTRUE	1
#define INPOWERHANDLERFALSE	0
#define ZONE_ERROR		DEBUGZONE(15)
#define ZONE_FUNCTION	DEBUGZONE(13)

#define I2CBUS_RESULT_SUCCESS	0
#define I2CBUS_RESULT_FAILURE	1
#define I2CBUS_RESULT_BUS_NOT_IDLE	2

#define I2C_ADDRESS_LENGTH 2
#define I2C_DATA_LENGTH 1

BOOL I2C_Bus_Init(void); 
BOOL I2C_Bus_Deinit(void); 
BOOL I2C_Write_Register(UCHAR SlaveAddress,UCHAR Reg_address,UCHAR PortIndex, UCHAR Data);
BOOL I2C_Read_Register(UCHAR SlaveAddress,UCHAR Reg_address,UCHAR PortIndex, PUCHAR pData);

#endif // _SC_I2C_BUS_H_