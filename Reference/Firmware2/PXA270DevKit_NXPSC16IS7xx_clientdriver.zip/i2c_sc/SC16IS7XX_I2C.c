
/*/==============================================================================
// COPYRIGHT (C)1997-2006 BSQUARE Corporation
//	ALL RIGHTS RESERVED
//
//	CONFIDENTIAL
//
//	This file is confidential and proprietary intellectual property
//	of BSQUARE Corporation.  No use, modification, duplication,
//	or distribution of any part of this file is permitted without
//	express written permission from BSQUARE Corporation.
//===============================================================================
//===============================================================================
    Module name : SC_I2C.lib
	File name   : SC16IS7XX_I2C.c 
	Description : Functions to control I2C bus using CPU I2C controller
				  -> Configure the PXA270 I2C port
				  -> I2C interface function to read register and write register 	
					 of the SC16IS7XX chip. 	
				  -> Cpu bus init	
				 
	History	    :
		ver 0.1	  16th November 2006	
			      Initial
    Author:
	    
//===============================================================================*/

/********************************************************************************
 Include Files
*********************************************************************************/

#include <windows.h>
#include <types.h>
#include <ceddk.h>
#include <memory.h>
#include <nkintr.h>
#include "sc_i2c_bus.h"

static DWORD SendTimeoutUs[2] = {10000, 10000};
static DWORD ReceiveTimeoutUs[2] = {10000, 10000};

CRITICAL_SECTION	I2c_bus; // Making bus access atomic

static BOOL bPWR_I2C_ENABLED = FALSE;

#define I2C_DELAY(delay_us) 	DelayMicroSeconds(delay_us);

PCPU_OSTREGS v_pOstRegs = (PCPU_OSTREGS)CPU_OST_BASE;

/********************************************************************************
Function prototype
*********************************************************************************/

BOOL VirtualAllocMapMemory(PVOID * pvp, PVOID * pvpfree, PVOID address, DWORD size);

// ****************************************************************************
// Function Name : VirtualAllocMapMemory
// Description : 
//	pvp stands for pointer to void pointer, so that we can store the results in 
//	the	caller's variables
// ****************************************************************************
static BOOL VirtualAllocMapMemory(PVOID * pvp, PVOID * pvpfree, PVOID address, DWORD size)
{
	SYSTEM_INFO SysInfo;
	DWORD PageSize;
	int error_flag = 0;

	// Get the page size for the current CPU
	GetSystemInfo(&SysInfo);
	PageSize = SysInfo.dwPageSize;

	if (!(*pvpfree = VirtualAlloc(NULL, size + PageSize, MEM_RESERVE, PAGE_NOACCESS)))
		return FALSE;

	if (!VirtualCopy(*pvpfree, (PVOID)(((unsigned long) address) & ~(PageSize - 1)), size + PageSize, PAGE_READWRITE|PAGE_NOCACHE))
		goto fail;

	*pvp = (PVOID) (((PBYTE) *pvpfree) + (((unsigned long) address) & (PageSize - 1)));

	 return TRUE;

fail:
	VirtualFree(*pvpfree, 0, MEM_RELEASE);
	*pvpfree = NULL;
	 return FALSE;
}

static BOOL MapControllerRegs(void)
{
	if (!VirtualAllocMapMemory(&g_pController[0], &pvControllerMapBase[0], (PVOID)CPU_I2C_BASE, sizeof(CPU_I2CREGS)))
		return FALSE;
	return TRUE;
}

void UnmapControllerRegs(void)
{
	if (pvControllerMapBase[0] != NULL)
		VirtualFree(pvControllerMapBase[0], 0, MEM_RELEASE);
}


static BOOL InitializeController(PCPU_I2CREGS pController, BOOL InPowerHandler)
{
	pController->isar = 0;
	pController->icr = CPU_I2C_ICR_IUE | CPU_I2C_ICR_SCLE | CPU_I2C_ICR_GCD | CPU_I2C_ICR_FM;
	return TRUE;
}

static BOOL IsBusIdle(int Bus)
{
	return TRUE;
}

static BOOL WaitForTransferDone(PCPU_I2CREGS pController, DWORD TimeoutUs, BOOL bSending)
{
	TIMESTAMP Start;
	BOOL bLastChance = FALSE;
	
	DWORD DoneFlag = bSending ? CPU_I2C_ISR_ITE : CPU_I2C_ISR_IRF;

	#define FLAGS_TO_CLEAR		(CPU_I2C_ISR_BED | CPU_I2C_ISR_ALD | CPU_I2C_ISR_ITE | CPU_I2C_ISR_IRF)
	
	Start = GetTimeStamp();

	for ( ; ; )
	{
		DWORD Status = pController->isr;
		
		// check for arbitration loss detected
		if (Status & CPU_I2C_ISR_ALD)
		{
			// clear flag bits
			pController->isr = FLAGS_TO_CLEAR;
			// set control register to known state (may not be needed)
			pController->icr = CPU_I2C_ICR_IUE | CPU_I2C_ICR_SCLE | CPU_I2C_ICR_GCD | CPU_I2C_ICR_FM;

			DEBUGMSG(ZONE_ERROR, (TEXT("DRVLIB: I2C: arbitration loss detected!")));

			return FALSE;
		}		

		// check for transaction complete but bus error occured (missing NAK)
		if (Status & CPU_I2C_ISR_BED)
		{
			// check for unit busy (no stop bit sent)
			if (Status & CPU_I2C_ISR_UB)
			{
				// use Master Abort to send stop, clear BED, ALD and ITE bits
				pController->isr = FLAGS_TO_CLEAR | CPU_I2C_ICR_MA;
			} 
			else
			{
				// clear flag bits
				pController->isr = FLAGS_TO_CLEAR;
			}
			// set control register to known state (may not be needed)
			pController->icr = CPU_I2C_ICR_IUE | CPU_I2C_ICR_SCLE | CPU_I2C_ICR_GCD | CPU_I2C_ICR_FM;

			DEBUGMSG(ZONE_ERROR, (TEXT("DRVLIB: I2C: bus error detected (NAK)!")));

			return FALSE;
		}

		// check for transmit done
		if (Status & DoneFlag)
		{
			// clear flag bits
			pController->isr = FLAGS_TO_CLEAR;
			return TRUE;
		}
	
		if (TimeoutUs != INFINITE)
		{
			if (bLastChance)
			{
				// timeout and last chance failed, reset the controller
				DEBUGMSG(ZONE_FUNCTION, (TEXT("DRVLIB: I2C: timeout waiting for %s transfer complete!"), bSending ? TEXT("send") : TEXT("receive")));

				// place controller into reset
				pController->icr = CPU_I2C_ICR_UR;
				I2C_DELAY(100);

				// clear status flags
				pController->isr = FLAGS_TO_CLEAR;

				// take controller out of reset
				pController->icr = CPU_I2C_ICR_UR;
				I2C_DELAY(100);

				// re-init controller
				pController->isar = 0;
				pController->icr = CPU_I2C_ICR_IUE | CPU_I2C_ICR_SCLE | CPU_I2C_ICR_GCD | CPU_I2C_ICR_FM;
				I2C_DELAY(100);

				return FALSE;
			}

			// check for timeout
			if ((GetTimeStampDeltaUs(GetTimeStamp(), Start) >= TimeoutUs))
				bLastChance = TRUE;
		}
	}
}

static BOOL WaitForSendDone(PCPU_I2CREGS pController, DWORD TimeoutUs)
{
	return WaitForTransferDone(pController, TimeoutUs, TRUE);
}

static BOOL WaitForReceiveDone(PCPU_I2CREGS pController, DWORD TimeoutUs)
{
	return WaitForTransferDone(pController, TimeoutUs, FALSE);
}

static int SendData(int Bus, BYTE Data, BOOL bStart, BOOL bCheckAck, BOOL bStop)
{
	g_pController[Bus]->idbr = Data;
	g_pController[Bus]->icr = (bStart ? CPU_I2C_ICR_START : 0) | CPU_I2C_ICR_TB | (bStop ? CPU_I2C_ICR_STOP : 0) | CPU_I2C_ICR_IUE | CPU_I2C_ICR_SCLE | CPU_I2C_ICR_GCD | CPU_I2C_ICR_FM;

	if (!WaitForSendDone(g_pController[Bus], SendTimeoutUs[Bus]))
		return I2CBUS_RESULT_FAILURE;

	// set control register to known state (may not be needed)
	g_pController[Bus]->icr = CPU_I2C_ICR_IUE | CPU_I2C_ICR_SCLE | CPU_I2C_ICR_GCD | CPU_I2C_ICR_FM;

	// Note: This is redundant, CPU_I2C_ISR_BED is always checked in WaitForSendDone()
	if (bCheckAck)
	{
		//if (!(g_pController[Bus]->isr & CPU_I2C_ISR_ACKNAK))
		if (g_pController[Bus]->isr & CPU_I2C_ISR_BED)
		{
			return I2CBUS_RESULT_FAILURE;
		}
	}

	return I2CBUS_RESULT_SUCCESS;
}

static int ReceiveData(int Bus, PBYTE pData, BOOL bStart, BOOL bSendAck, BOOL bStop)
{
	// set RD/nWr bit
	// g_pController[Bus]->idbr = CPU_I2C_IDBR_READ;

	// start receive data operation
	g_pController[Bus]->icr = (bStart ? CPU_I2C_ICR_START : 0) | CPU_I2C_ICR_TB | (bSendAck ? 0: CPU_I2C_ICR_ACKNAK) | (bStop ? CPU_I2C_ICR_STOP : 0) | CPU_I2C_ICR_IUE | CPU_I2C_ICR_SCLE | CPU_I2C_ICR_GCD | CPU_I2C_ICR_FM;

	if (!WaitForReceiveDone(g_pController[Bus], ReceiveTimeoutUs[Bus]))
		return I2CBUS_RESULT_FAILURE;

	*pData = g_pController[Bus]->idbr;

	// set control register to known state (may not be needed)
	g_pController[Bus]->icr = CPU_I2C_ICR_IUE | CPU_I2C_ICR_SCLE | CPU_I2C_ICR_GCD | CPU_I2C_ICR_FM;

	return I2CBUS_RESULT_SUCCESS;
}
	
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//
// Public Functions (I2C_CONTROLLER_SELECT_ONCHIP)
//
//-------------------------------------------------------------------
//-------------------------------------------------------------------

BOOL _I2CBusInitialize(BOOL InPowerHandler)
{

	if (MapControllerRegs()){
	// Hardware init -- only done in bootloader or single threaded mode.
	// This is done so the driver does not clobber the I2C interface
	// if it is being used by the OAL during the driver load
		InitializeController(g_pController[0], INPOWERHANDLERTRUE);
			
		return TRUE;
	}
		UnmapControllerRegs();
		return FALSE;
}

int I2CBusSendBytes(int Bus, UCHAR * pAddress, DWORD AddressLength, UCHAR * pData, DWORD DataLength)
{
	//------------------------------------------------------------------------
	// Note: The I2C bus driver must support special operations where 
	//       pAddress == NULL and AddressLength is 0. These cycles allow data 
	//       to be transmitted/received using pData and DataLength without the 
	//       generation of a stop bit. Please do not disturb this functionality.
	//------------------------------------------------------------------------

	int Result = I2CBUS_RESULT_SUCCESS;
	BOOL bStart = TRUE;
	BOOL bStop = FALSE;
	BOOL bCheckAck = TRUE;

	if (Bus != 0 )
		return I2CBUS_RESULT_FAILURE;

	// can't start transaction unless bus is idle
	if ( !IsBusIdle(Bus) )
		return I2CBUS_RESULT_FAILURE;

	while (AddressLength)
	{
		// send stop bit after last byte if there is no data phase
		if (AddressLength == 1 && DataLength == 0)
			bStop = TRUE;

		if ( (Result = SendData(Bus, *pAddress, bStart, bCheckAck, bStop)) != I2CBUS_RESULT_SUCCESS )
			return Result;

		bStart = FALSE;

		AddressLength--;
		pAddress++;
	}
			
	while (DataLength)
	{
		// send stop on last byte unless pAddress was NULL, this is REQUIRED to allow combined format
		if (DataLength == 1 && pAddress != NULL)
			bStop = TRUE;

		if ( (Result = SendData(Bus, *pData, bStart, bCheckAck, bStop)) != I2CBUS_RESULT_SUCCESS )
			return Result;

		bStart = FALSE;

		DataLength--;
		pData++;
	}
			
	return Result;
}

int I2CBusReceiveBytes(int Bus, UCHAR * pAddress, DWORD AddressLength, UCHAR * pData, DWORD DataLength)
{
	//------------------------------------------------------------------------
	// Note: The I2C bus driver must support special operations where 
	//       pAddress == NULL and AddressLength is 0. These cycles allow data 
	//       to be transmitted/received using pData and DataLength without the 
	//       generation of a stop bit. Please do not disturb this functionality.
	//------------------------------------------------------------------------

	int Result = I2CBUS_RESULT_SUCCESS;
	BOOL bStart = TRUE;
	BOOL bStop = FALSE;
	BOOL bCheckAck = TRUE;
	BOOL bSendAck = TRUE;
	
	if (Bus != 0 )
		return I2CBUS_RESULT_FAILURE;

	// can't start transaction unless bus is idle
	if ( !IsBusIdle(Bus) )
		return I2CBUS_RESULT_FAILURE;

	while (AddressLength)
	{
		if ( (Result = SendData(Bus, *pAddress, bStart, bCheckAck, bStop)) != I2CBUS_RESULT_SUCCESS )
			return Result;

		bStart = FALSE;

		// send stop bit after last byte if there is no data phase
		if (AddressLength == 1 && DataLength == 0)
			bStop = TRUE;

		AddressLength--;
		pAddress++;
	}
			
	while (DataLength)
	{
		// send stop on last byte unless pAddress was NULL, this is REQUIRED to allow combined format
		if (DataLength == 1 && pAddress != NULL)
			bStop = TRUE;

		if (DataLength == 1)
		{
			bSendAck = FALSE;
			bStop = TRUE;
		}

		if ( (Result = ReceiveData(Bus, pData, bStart, bSendAck, bStop)) != I2CBUS_RESULT_SUCCESS )
			return Result;

		bStart = FALSE;

		DataLength--;
		pData++;
	}
			
	return Result;
}

// Wrapper functions around I2C bus low-level interface

//----------------------------------------------------------------------------
//
//	I2C_Write_Register(), Import functions for I2C access
//
//----------------------------------------------------------------------------

BOOL I2C_Write_Register(UCHAR SlaveAddress,UCHAR Reg_address,UCHAR PortIndex, UCHAR Data)
{

	BYTE Address[2];
    I2C_IOCTL_TRANSACTION i2cPacket;
	int result;
	EnterCriticalSection(&I2c_bus);
	//
    // write 1 byte of address and 2 bytes of data to I2C device
    //
    i2cPacket.Bus = 0;

    // Note: write and read address for most chips will be different (read will have BIT0 set)
	
    Address[0] = SlaveAddress;
	Address[1] = ( Reg_address << 3) | (PortIndex << 1); // bit 6:3, A[3:0] UART�s internal register select
    i2cPacket.pAddress = Address;
    i2cPacket.AddressLength = I2C_ADDRESS_LENGTH;

	i2cPacket.pData = &Data;

	i2cPacket.DataLength = I2C_DATA_LENGTH;

	result = I2CBusSendBytes(i2cPacket.Bus, i2cPacket.pAddress, i2cPacket.AddressLength, i2cPacket.pData, i2cPacket.DataLength);
	LeaveCriticalSection(&I2c_bus);
	if(result == I2CBUS_RESULT_FAILURE )
		return FALSE;

	return TRUE;	
}

//----------------------------------------------------------------------------
//
//	I2C_Read_Register(), Import functions for I2C access
//
//----------------------------------------------------------------------------

BOOL I2C_Read_Register(UCHAR SlaveAddress,UCHAR Reg_address,UCHAR PortIndex, PUCHAR pData)
{

   	BYTE Address[2];
    BYTE Data[3];
	I2C_IOCTL_TRANSACTION i2cPacket;
	int result;
	EnterCriticalSection(&I2c_bus);
    // <START> <write slave address (write mode) > <write reg address> 
    // Note: Because pAddress is NULL a STOP bit will note be generated

    i2cPacket.Bus = 0;

    i2cPacket.pAddress = NULL;
    i2cPacket.AddressLength = 0;

    i2cPacket.pData = Data;
	Data[0] = SlaveAddress;
	Data[1] = (Reg_address << 3 ) | (PortIndex << 1); // bit 6:3, A[3:0] UART�s internal register select

    i2cPacket.DataLength = I2C_ADDRESS_LENGTH;
	
	result = I2CBusSendBytes(i2cPacket.Bus, i2cPacket.pAddress, i2cPacket.AddressLength, i2cPacket.pData, i2cPacket.DataLength);

	if(result == I2CBUS_RESULT_FAILURE )
		return FALSE;

    // <START> <write slave address (read mode) > <read data byte 0> <STOP>
    // Note: Because pAddress is not NULL a STOP bit will be generated

    i2cPacket.Bus = 0;

    Address[0] = SlaveAddress | 0x01; //Set last bit as READ operation
    i2cPacket.pAddress = Address;
    i2cPacket.AddressLength = 1;

    i2cPacket.pData = pData;
    i2cPacket.DataLength = I2C_DATA_LENGTH;

	result = I2CBusReceiveBytes(i2cPacket.Bus, i2cPacket.pAddress, i2cPacket.AddressLength, i2cPacket.pData, i2cPacket.DataLength);

	LeaveCriticalSection(&I2c_bus);
	if(result == I2CBUS_RESULT_FAILURE )
		return FALSE;

	return TRUE;	
}


//----------------------------------------------------------------------------
//
// I2C_Bus_Init() Initialize of I2C bus
//
//----------------------------------------------------------------------------


BOOL I2C_Bus_Init(void)
{

	BOOL result = FALSE;
	InitializeCriticalSection(&I2c_bus);
	EnterCriticalSection(&I2c_bus);
	result = _I2CBusInitialize(FALSE);
	LeaveCriticalSection(&I2c_bus);
	return result;
}
//-----------------------------------------------------------------------------------
//
// I2C_Bus_Deinit() Deinitialize of I2C bus, delete critical sectiona and free memory
//
//------------------------------------------------------------------------------------
BOOL I2C_Bus_Deinit(void)
{
	DeleteCriticalSection(&I2c_bus);
	UnmapControllerRegs();
	return TRUE;
}

DWORD GetTimeStampDeltaUs(TIMESTAMP new, TIMESTAMP old)
{
	DWORD delta, time;

	// return delta in microseconds
	delta = new - old;

	// floating point formula would be: time in us = delta / (TIMER_FREQUENCY_HZ/1000000)

	if (delta < (DWORD) TIMER_FREQUENCY_HZ)
	{
		time = (delta * (1024000000 / TIMER_FREQUENCY_HZ)) / 1024;
	}
	else
	{
		time = (delta / (TIMER_FREQUENCY_HZ / 100)) * 10000;
	}

	return time;
}

//----------------------------------------------------------------------------
//
// GetTimeStamp()
//
//----------------------------------------------------------------------------

// Returns a microsecond resolution timestamp, that will not repeat for many 
// seconds (about 1165 seconds). DriverSleepInit() must be called before first use.

TIMESTAMP GetTimeStamp(void)
{
	#if !BUILDING_BOOTLOADER && !BUILDING_OAL && !BUILDING_KITL
		ASSERT(v_pOstRegs != NULL);
	#endif

	return v_pOstRegs->oscr0;
}


//----------------------------------------------------------------------------
//
// DelayMicroSeconds() - Busy wait, takes time in microseconds, makes no OS calls
//
//----------------------------------------------------------------------------

/*
 *  implement a busy-wait delay, for use by drivers
 *  for short delays during normal operation or inside 
 *  power handler functions. Note that we may get swapped
 *  out and the delay could be much longer than specified.
 * 
 */
void DelayMicroSeconds(DWORD dw_uSec)
{
	DWORD starttime;
	DWORD endtime;

	#if !BUILDING_BOOTLOADER && !BUILDING_OAL && !BUILDING_KITL
		ASSERT(v_pOstRegs != NULL);
	#endif

	starttime = v_pOstRegs->oscr0;
	// 26624 / 8192 = 3.25, oscr0 runs at 3.25MHz
	endtime = starttime + ((dw_uSec * 26624) >> 13);

	// Check for wrapping on the counter
	if (endtime < starttime)
		while (v_pOstRegs->oscr0 > starttime);

	while (v_pOstRegs->oscr0 < endtime);
}